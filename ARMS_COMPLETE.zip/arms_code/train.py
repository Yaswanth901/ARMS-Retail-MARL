import os
BASE = os.path.dirname(os.path.abspath(__file__))  # save/load next to this script, works on any OS
import numpy as np
import pandas as pd
from retail_env import RetailEnv, PRICE_ACTIONS, INV_ACTIONS
from agents import rule_based_policy, SingleAgentQLearner, TwoAgentQLearner, discretize

N_EPISODES = 1500
HORIZON = 60
SEED = 42

def run_rule_based(n_episodes=200):
    rows = []
    for ep in range(n_episodes):
        env = RetailEnv(horizon=HORIZON, seed=SEED + ep)
        s = env.reset()
        ep_reward, ep_revenue, ep_waste, ep_stockout, inv_sum, ep_demand = 0, 0, 0, 0, 0, 0
        for _ in range(HORIZON):
            price_a, inv_a = rule_based_policy(s)
            s, (rp, ri), done, info = env.step(price_a, inv_a)
            ep_reward += rp + ri
            ep_revenue += info["revenue"]
            ep_waste += info["wastage"]
            ep_stockout += info["stockout"]
            ep_demand += info["demand"]
            inv_sum += info["stock_after"]
        rows.append(dict(episode=ep, total_reward=ep_reward, revenue=ep_revenue,
                          wastage=ep_waste, stockout=ep_stockout, avg_inventory=inv_sum / HORIZON,
                          demand=ep_demand, fill_rate=(ep_demand - ep_stockout) / max(ep_demand, 1)))
    return pd.DataFrame(rows)


def run_single_agent(n_episodes=N_EPISODES):
    agent = SingleAgentQLearner()
    rows = []
    for ep in range(n_episodes):
        env = RetailEnv(horizon=HORIZON, seed=SEED + ep)
        s = env.reset()
        ep_reward, ep_revenue, ep_waste, ep_stockout, inv_sum, ep_demand = 0, 0, 0, 0, 0, 0
        for _ in range(HORIZON):
            s_disc = discretize(s)
            idx, (price_a, inv_a) = agent.act(s)
            s_next, (rp, ri), done, info = env.step(price_a, inv_a)
            joint_r = rp + ri
            agent.update(s_disc, idx, joint_r, discretize(s_next), done)
            s = s_next
            ep_reward += joint_r
            ep_revenue += info["revenue"]
            ep_waste += info["wastage"]
            ep_stockout += info["stockout"]
            ep_demand += info["demand"]
            inv_sum += info["stock_after"]
        agent.decay()
        rows.append(dict(episode=ep, total_reward=ep_reward, revenue=ep_revenue,
                          wastage=ep_waste, stockout=ep_stockout, avg_inventory=inv_sum / HORIZON,
                          demand=ep_demand, fill_rate=(ep_demand - ep_stockout) / max(ep_demand, 1)))
    return pd.DataFrame(rows), agent


def run_two_agent(n_episodes=N_EPISODES):
    agent = TwoAgentQLearner()
    rows = []
    for ep in range(n_episodes):
        env = RetailEnv(horizon=HORIZON, seed=SEED + ep)
        s = env.reset()
        ep_reward, ep_revenue, ep_waste, ep_stockout, inv_sum, ep_demand = 0, 0, 0, 0, 0, 0
        for _ in range(HORIZON):
            (s_disc, p_idx, i_idx), (price_a, inv_a) = agent.act(s)
            s_next, (rp, ri), done, info = env.step(price_a, inv_a)
            agent.update(s_disc, p_idx, i_idx, rp, ri, discretize(s_next), done)
            s = s_next
            ep_reward += rp + ri
            ep_revenue += info["revenue"]
            ep_waste += info["wastage"]
            ep_stockout += info["stockout"]
            ep_demand += info["demand"]
            inv_sum += info["stock_after"]
        agent.decay()
        rows.append(dict(episode=ep, total_reward=ep_reward, revenue=ep_revenue,
                          wastage=ep_waste, stockout=ep_stockout, avg_inventory=inv_sum / HORIZON,
                          demand=ep_demand, fill_rate=(ep_demand - ep_stockout) / max(ep_demand, 1)))
    return pd.DataFrame(rows), agent


if __name__ == "__main__":
    np.random.seed(SEED)
    print("Running rule-based control...")
    df_rule = run_rule_based(200)
    print("Training single-agent Q-learning...")
    df_single, single_agent = run_single_agent()
    print("Training two-agent independent Q-learning...")
    df_two, two_agent = run_two_agent()

    df_rule.to_csv(os.path.join(BASE, "results_rule_based.csv"), index=False)
    df_single.to_csv(os.path.join(BASE, "results_single_agent.csv"), index=False)
    df_two.to_csv(os.path.join(BASE, "results_two_agent.csv"), index=False)

    import pickle
    with open(os.path.join(BASE, "trained_two_agent.pkl"), "wb") as f:
        pickle.dump(two_agent, f)
    print("done")
