"""Shows the simulated demand data the whole project runs on, and saves a sample as a CSV.
Run:  python show_simulation.py"""
import numpy as np, csv
from retail_env_v2 import BASE_DEMAND, DEMAND_LIFT, WEEKDAY_MULT

DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
rng = np.random.default_rng(7)

print("HOW THE DATA IS MADE (retail_env_v2.py, lines 78-79)")
print("  expected demand = BASE_DEMAND x DEMAND_LIFT[price] x WEEKDAY_MULT[weekday]")
print("  customers wanted = Poisson(expected demand)      <- a random whole number each day")
print(f"  BASE_DEMAND = {BASE_DEMAND}   WEEKDAY_MULT = {WEEKDAY_MULT} (Sat and Sun +15%)")
print(f"  DEMAND_LIFT = {DEMAND_LIFT}   (assumed, not measured)\n")

print("14 SIMULATED DAYS (regular price, seed 7)")
print(f"{'Day':>3} {'Weekday':>7} {'Expected':>9} {'Customers wanted':>17}   with 15% off (expected)")
rows = []
for d in range(60):
    mult = WEEKDAY_MULT[d % 7]
    exp = BASE_DEMAND * DEMAND_LIFT["REGULAR_PRICE"] * mult
    wanted = int(rng.poisson(exp))
    rows.append((d + 1, DAYS[d % 7], round(exp, 2), wanted, round(BASE_DEMAND * DEMAND_LIFT["MODERATE_DISCOUNT"] * mult, 2)))
for r in rows[:14]:
    print(f"{r[0]:>3} {r[1]:>7} {r[2]:>9.2f} {r[3]:>17d}   {r[4]:.2f}")

print("\nCHECK: Poisson means mean = variance (20,000 simulated days each)")
for name, mean in [("weekday, regular price", 12.0), ("weekend, regular price", 13.8), ("weekday, 15% off", 13.8)]:
    x = rng.poisson(mean, 20000)
    print(f"  {name:24s} expected {mean:5.1f} | simulated mean {x.mean():5.2f} | variance {x.var():5.2f}")

print("\nSHAPE OF A WEEKDAY (1,000 days, expected 12):")
x = rng.poisson(12, 1000); lo, hi = int(x.min()), int(x.max())
for v in range(lo, hi + 1):
    c = int((x == v).sum()); print(f"  {v:3d} | {'#' * (c // 4)} {c}")

with open("simulated_demand_sample.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["day", "weekday", "expected_demand", "customers_wanted", "expected_if_15pct_off"]); w.writerows(rows)
print("\nSaved 60 simulated days to simulated_demand_sample.csv (open it in Excel).")
print("Remember: all of this is SIMULATED from assumed numbers, not real store data.")
