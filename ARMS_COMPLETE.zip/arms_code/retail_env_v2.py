"""
Retail environment v2 - real profit economics.

v1 rewarded revenue only, so reordering looked free. v2 charges what a real
store pays:
  - UNIT_COST      : what the store pays per unit (so a sale earns margin, not revenue)
  - wastage        : expired units are a real loss (the unit cost is gone)
  - HOLD_COST      : cost of keeping each unit on the shelf for a day
  - ORDER_FIXED    : fixed cost of placing any order (transport, handling)
  - LAMBDA_S       : stock-out penalty = lost margin + a little customer goodwill

Every number below is an ASSUMPTION for the simulation, not measured data.
Change them to match a real store; the code does not depend on the exact values.

Reward split (role-specific, as in the proposal):
  R_price     = units_sold * (price - UNIT_COST) - UNIT_COST * wastage
  R_inventory = - HOLD_COST * stock_after - ORDER_FIXED * (order placed) - LAMBDA_S * stockout
Reported business profit (exact, excludes the goodwill part of the stock-out penalty):
  profit = R_price + R_inventory + LAMBDA_S * stockout
"""
import numpy as np

PRICE_ACTIONS = ["REGULAR_PRICE", "MODERATE_DISCOUNT", "CLEARANCE_DISCOUNT"]
PRICE_MULTIPLIER = {"REGULAR_PRICE": 1.0, "MODERATE_DISCOUNT": 0.85, "CLEARANCE_DISCOUNT": 0.65}
DEMAND_LIFT = {"REGULAR_PRICE": 1.0, "MODERATE_DISCOUNT": 1.15, "CLEARANCE_DISCOUNT": 1.3}
INV_ACTIONS = ["NO_REORDER", "SMALL_REORDER", "FULL_REORDER"]
REORDER_QTY = {"NO_REORDER": 0, "SMALL_REORDER": 10, "FULL_REORDER": 25}

BASE_PRICE = 50.0      # Rs per unit at regular price
UNIT_COST = 35.0       # Rs per unit paid to the supplier (30% gross margin at regular price)
HOLD_COST = 0.6        # Rs per unit per day
ORDER_FIXED = 40.0     # Rs per order placed
LAMBDA_S = 20.0        # Rs per unit of unmet demand (lost margin Rs 15 + goodwill Rs 5)
BASE_DEMAND = 12.0
SHELF_LIFE_DAYS = 4
MAX_STOCK = 45         # shelf/storage capacity used by the safety guardrails
# Demand multiplier for each day of the week (Mon..Sun). Default = the original assumption
# (weekend +15%). calibrate_favorita.py can replace it with a pattern measured from real sales.
WEEKDAY_MULT = [1.0, 1.0, 1.0, 1.0, 1.0, 1.15, 1.15]


class RetailEnvV2:
    def __init__(self, horizon=60, seed=None):
        self.horizon = horizon
        self.rng = np.random.default_rng(seed)
        self.reset()

    def reset(self):
        self.day = 0
        self.batches = [[20, SHELF_LIFE_DAYS]]
        self.history = []
        self.ema = BASE_DEMAND          # smoothed demand estimate
        return self._state()

    def _stock(self):
        return sum(b[0] for b in self.batches)

    def _days_to_nearest_expiry(self):
        return min((b[1] for b in self.batches), default=SHELF_LIFE_DAYS)

    def _state(self, price_action=None, expected_demand=None):
        seasonality = WEEKDAY_MULT[self.day % 7]
        s = {
            "stock": self._stock(),
            "days_to_expiry": self._days_to_nearest_expiry(),
            "recent_demand": self.history[-1]["demand"] if self.history else BASE_DEMAND,
            "seasonality": seasonality,
            "demand_ema": self.ema,       # smoothed demand (used by the richer-state agent only)
            "expiring": sum(b[0] for b in self.batches if b[1] <= 1),   # units that expire at the end of today
        }
        if price_action is not None:
            s["selected_price"] = price_action
            s["expected_demand"] = expected_demand
        return s

    def step(self, price_action, inventory_action):
        seasonality = WEEKDAY_MULT[self.day % 7]
        expected_demand = BASE_DEMAND * DEMAND_LIFT[price_action] * seasonality
        demand = max(0, self.rng.poisson(expected_demand))
        self.ema = 0.7 * self.ema + 0.3 * demand

        units_sold, remaining = 0, demand
        for b in self.batches:
            if remaining <= 0:
                break
            take = min(b[0], remaining)
            b[0] -= take
            units_sold += take
            remaining -= take
        stockout = max(0, demand - units_sold)

        price = BASE_PRICE * PRICE_MULTIPLIER[price_action]

        wastage = 0
        kept = []
        for b in self.batches:
            b[1] -= 1
            if b[1] <= 0:
                wastage += b[0]
            elif b[0] > 0:
                kept.append(b)
        self.batches = kept

        qty = REORDER_QTY[inventory_action]
        if qty > 0:
            self.batches.append([qty, SHELF_LIFE_DAYS])
        stock_after = self._stock()

        r_price = units_sold * (price - UNIT_COST) - UNIT_COST * wastage
        r_inv = -HOLD_COST * stock_after - (ORDER_FIXED if qty > 0 else 0.0) - LAMBDA_S * stockout
        profit = r_price + r_inv + LAMBDA_S * stockout

        info = {
            "day": self.day, "demand": demand, "units_sold": units_sold, "price": price,
            "wastage": wastage, "stockout": stockout, "stock_after": stock_after,
            "below_cost_units": units_sold if price < UNIT_COST else 0,
            "over_capacity": 1 if stock_after > MAX_STOCK else 0,
            "profit": profit, "r_price": r_price, "r_inventory": r_inv,
        }
        self.history.append(info)
        self.day += 1
        done = self.day >= self.horizon
        return self._state(price_action, expected_demand), (r_price, r_inv), done, info
