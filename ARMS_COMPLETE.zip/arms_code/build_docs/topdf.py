from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(); pg.goto("file:///tmp/rep/report.html"); pg.wait_for_timeout(800)
    pg.pdf(path="/tmp/rep/ARMS_Final_Report.pdf", format="A4", print_background=True, margin=dict(top="14mm", bottom="14mm", left="13mm", right="13mm"), display_header_footer=True, header_template="<div></div>",
           footer_template="<div style='font-size:8px;color:#666;width:100%;text-align:center;font-family:serif'>ARMS final report | page <span class='pageNumber'></span> of <span class='totalPages'></span></div>"); b.close()
