"""
LEARNING THE OFFER (a bandit: one-step reinforcement learning).
Each evening some units would expire. The shop can try one of six actions ("arms"): do nothing, 15% off, 35% off, or a free unit with a bill of Rs 75 / 100 / 150.
How customers respond is NOT known in advance. The learner tries arms, sees that day's result, and gradually concentrates on the arm that earns most.
This is what a real pilot with offers on different days would do, done automatically. The worlds below are SIMULATED, with different hidden customer behaviour.
Run:  python offer_bandit.py        (about 1 minute)
"""
import numpy as np, pandas as pd
import features_core as F

ARMS = ["No offer", "15% off", "35% off", "Free unit, bill Rs 75+", "Free unit, bill Rs 100+", "Free unit, bill Rs 150+"]
THRESH = {3: 75, 4: 100, 5: 150}

class OfferWorld:
    """Evening leftovers and bills come from the shop data; customer response (accept15, accept35, q) is hidden from the learner."""
    def __init__(self, accept15, accept35, q, take_free=0.8):
        sales, stock = F.load_shop(); s = sales.assign(hour=sales.time.str[:2].astype(int))
        bills = s.groupby("bill_id").agg(value=("line_amount", "sum"), hour=("hour", "first"))
        self.evening = bills[bills.hour >= 17].value.values; self.eve_n = len(self.evening) / sales.date.nunique()
        self.leftover = stock.expired.sum() / stock.date.nunique(); self.price = float(s[s.category == "perishable"].unit_price.mean())
        self.am = float(s[s.category == "add-on"].line_margin.sum() / s[s.category == "add-on"].line_amount.sum())
        self.a15, self.a35, self.q, self.take = accept15, accept35, q, take_free

    def day(self, arm, rng):
        """Returns (cash earned from the units that would have expired, units saved from waste)."""
        L = rng.poisson(self.leftover); nb = rng.poisson(self.eve_n)
        if arm == 0 or L == 0: return 0.0, 0
        if arm in (1, 2):
            n = min(L, rng.binomial(nb, self.a15 if arm == 1 else self.a35)); return n * self.price * (0.85 if arm == 1 else 0.65), n
        T, gift, extra, left = THRESH[arm], 0, 0.0, L
        for x in rng.choice(self.evening, nb):
            if left == 0: break
            if x >= T:
                if rng.random() < self.take: left -= 1; gift += 1
            elif x >= T - 50 and rng.random() < self.q: extra += (T - x) * self.am; left -= 1; gift += 1
        return extra, gift

    def true_values(self, waste_value, days=4000, seed=1):
        rng = np.random.default_rng(seed); out = []
        for a in range(6):
            r = np.array([self.day(a, rng) for _ in range(days)]); out.append(float(r[:, 0].mean() + waste_value * r[:, 1].mean()))
        return np.array(out)

class EpsGreedy:
    def __init__(self, eps=0.3, decay=0.96): self.n = np.zeros(6); self.m = np.zeros(6); self.eps, self.decay = eps, decay
    def choose(self, rng, t):
        if self.n.min() == 0 and rng.random() < 0.5: return int(np.argmin(self.n))          # try every arm at least once
        return int(rng.integers(6)) if rng.random() < self.eps else int(np.argmax(self.m))
    def learn(self, a, r): self.n[a] += 1; self.m[a] += (r - self.m[a]) / self.n[a]; self.eps = max(0.03, self.eps * self.decay)

class UCB:
    def __init__(self, c=0.8): self.n = np.zeros(6); self.m = np.zeros(6); self.c = c; self.scale = 1.0; self.t = 0
    def choose(self, rng, t):
        if self.n.min() == 0: return int(np.argmin(self.n))
        return int(np.argmax(self.m + self.c * self.scale * np.sqrt(np.log(self.t + 1) / self.n)))
    def learn(self, a, r): self.t += 1; self.n[a] += 1; self.m[a] += (r - self.m[a]) / self.n[a]; self.scale = max(self.scale, abs(r), 1.0)

def run(world, learner_cls, waste_value, days=90, runs=60, seed=0):
    true = world.true_values(waste_value); best = int(np.argmax(true)); rng = np.random.default_rng(seed); share, regret, picked = [], [], np.zeros(6)
    for _ in range(runs):
        lr = learner_cls(); chosen = []
        for t in range(days):
            a = lr.choose(rng, t); cash, saved = world.day(a, rng); lr.learn(a, cash + waste_value * saved); chosen.append(a)
        chosen = np.array(chosen); share.append(np.mean(chosen[-30:] == best)); regret.append(float((true[best] - true[chosen]).sum())); picked += np.bincount(chosen[-30:], minlength=6)
    return best, true, float(np.mean(share)), float(np.mean(regret)), picked / picked.sum()

WORLDS = {"Customers love discounts (35% off accepted by 20% of evening bills)": (0.08, 0.20, 0.10),
          "Customers respond to bundles (60% add items; 3% accept discounts)": (0.01, 0.03, 0.60),
          "Nobody responds much": (0.005, 0.01, 0.03),
          "Our earlier assumption (10% accept 35% off; 30% add items)": (0.04, 0.10, 0.30)}

if __name__ == "__main__":
    rows = []
    for waste_value in (0.0, 15.0):
        print(f"\nValue placed on each unit saved from waste: Rs {waste_value:.0f}")
        for name, (a15, a35, q) in WORLDS.items():
            w = OfferWorld(a15, a35, q)
            for lname, cls in (("epsilon-greedy", EpsGreedy), ("UCB", UCB)):
                best, true, share, regret, dist = run(w, cls, waste_value)
                rows.append(dict(waste_value=waste_value, world=name, learner=lname, best_arm=ARMS[best], share_of_last_30_days_on_best=round(share, 2), regret_vs_best_Rs=round(regret)))
                print(f"  {name[:62]:62s} {lname:14s} best arm: {ARMS[best]:24s} chosen {share:4.0%} of last 30 days; total regret Rs {regret:6,.0f}")
            rnd = float(np.mean([(true.max() - true[np.random.default_rng(s).integers(6, size=90)]).sum() for s in range(60)]))
            rows.append(dict(waste_value=waste_value, world=name, learner="random arms (no learning)", best_arm=ARMS[best], share_of_last_30_days_on_best=round(1 / 6, 2), regret_vs_best_Rs=round(rnd)))
    pd.DataFrame(rows).to_csv("results_offer_bandit.csv", index=False)
    print("\nSaved results_offer_bandit.csv. Regret = money lost over 90 days compared with always using the best arm (lower is better).")
