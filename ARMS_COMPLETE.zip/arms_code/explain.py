"""
Lightweight decision-level explainability layer.
Addresses Section 7's "limited decision-level explainability" gap and
Section 13's "simple decision-level records showing the state information
associated with pricing and reorder actions."

No black-box attribution model needed here: with only 3 state features
driving each discrete decision, the policy's own Q-values already tell you
*why* - we just render that as a sentence instead of leaving it in a table.
"""
import os
BASE = os.path.dirname(os.path.abspath(__file__))  # save/load next to this script, works on any OS
from retail_env import PRICE_ACTIONS, INV_ACTIONS
from agents import discretize


def explain_decision(state, price_action, inv_action, two_agent):
    s = discretize(state)
    p_idx = PRICE_ACTIONS.index(price_action)
    qp_row = two_agent.Qp.get(s)
    qi_row = two_agent.Qi.get((s, p_idx))

    reasons = []
    if state["days_to_expiry"] <= 1 and price_action != "REGULAR_PRICE":
        reasons.append(f"stock expires in {state['days_to_expiry']} day(s), discounting to clear it")
    elif price_action == "CLEARANCE_DISCOUNT":
        reasons.append("policy favours clearance pricing here - the demand lift it buys currently "
                        "outweighs the lower margin under the trained reward weights")
    elif price_action == "MODERATE_DISCOUNT":
        reasons.append("moderate demand lift judged worth the smaller margin cut")
    else:
        reasons.append("no discount needed at this demand/expiry level")

    if state["stock"] < 10 and inv_action in ("SMALL_REORDER", "FULL_REORDER"):
        reasons.append(f"stock is low ({state['stock']} units), reordering to avoid a stock-out")
    elif inv_action == "FULL_REORDER":
        reasons.append("policy reorders aggressively here - the stock-out penalty (\u03bbs) "
                        "currently dominates the excess-inventory penalty (\u03bbe)")
    elif inv_action == "NO_REORDER" and price_action != "REGULAR_PRICE":
        reasons.append("a discount is already expected to clear stock, so reorder is held off")
    elif inv_action == "NO_REORDER":
        reasons.append("stock judged sufficient for now")

    confidence = ""
    if qp_row is not None:
        gap = qp_row.max() - qp_row.min()
        confidence = "high" if gap > 50 else "moderate" if gap > 10 else "low"

    return (f"Day state: stock={state['stock']}, days_to_expiry={state['days_to_expiry']}, "
            f"demand={state['recent_demand']:.1f} -> Pricing: {price_action}, "
            f"Inventory: {inv_action}. Reason: {', '.join(reasons)}."
            + (f" (policy confidence: {confidence})" if confidence else ""))


if __name__ == "__main__":
    from retail_env import RetailEnv
    import numpy as np
    import pickle

    # Use the ACTUAL agent trained in train.py (1500 episodes), not a fresh one -
    # explanations below reflect genuinely learned behaviour, not default/random acts.
    with open(os.path.join(BASE, "trained_two_agent.pkl"), "rb") as f:
        agent = pickle.load(f)
    agent.eps = 0.0  # greedy / deployed behaviour, no exploration noise

    np.random.seed(7)
    env = RetailEnv(horizon=14, seed=7)  # two simulated weeks
    s = env.reset()
    print(f"{'='*90}\nDecision log - trained two-agent policy, greedy deployment, 14-day run\n{'='*90}")
    for day in range(14):
        (s_disc, p_idx, i_idx), (price_a, inv_a) = agent.act(s)
        print(explain_decision(s, price_a, inv_a, agent))
        s, (rp, ri), done, info = env.step(price_a, inv_a)
