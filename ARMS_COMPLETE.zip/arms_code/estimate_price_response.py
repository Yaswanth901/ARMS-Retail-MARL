"""Measures how demand responds to price from a sales file (one row per day: date, price, units_sold).
Model: units ~ Poisson( exp(a + b*log(price/regular price) + c*weekend) ), fitted by Newton's method; elasticity = -b.
A 90% interval comes from resampling days 400 times.   Run:  python estimate_price_response.py [--file SIMULATED_price_test.csv]
Writes price_response.json (used by experiments_v3.py pricing). Caveat: needs prices that were varied independently of demand (a test, not just history)
and days without stock-outs, because empty shelves hide demand."""
import argparse, json, os, numpy as np, pandas as pd
ap = argparse.ArgumentParser(); ap.add_argument("--file", default="SIMULATED_price_test.csv"); ap.add_argument("--regular", type=float, default=50.0); a = ap.parse_args()
d = pd.read_csv(a.file, parse_dates=["date"]); y = d.units_sold.values.astype(float)
X = np.column_stack([np.ones(len(d)), np.log(d.price.values / a.regular), (d.date.dt.weekday.values >= 5).astype(float)])

def fit(X, y):
    beta = np.zeros(X.shape[1]); beta[0] = np.log(max(y.mean(), 1e-6))
    for _ in range(60):
        mu = np.exp(X @ beta); step = np.linalg.solve(X.T @ (X * mu[:, None]), X.T @ (y - mu)); beta += step
        if np.abs(step).max() < 1e-9: break
    return beta
b = fit(X, y); eps = -b[1]; rng = np.random.default_rng(0)
boot = [-fit(X[i], y[i])[1] for i in (rng.integers(0, len(y), len(y)) for _ in range(400))]
lo, hi = np.percentile(boot, [5, 95])
print(f"Measured price response from {len(d)} days: elasticity {eps:.2f} (90% interval {lo:.2f} to {hi:.2f}); weekend effect x{np.exp(b[2]):.2f}")
print(f"  meaning: a 10% price cut raises demand by about {((0.9) ** (-eps) - 1):.0%}; a 20% cut by about {((0.8) ** (-eps) - 1):.0%}")
print(f"  for a discount to raise PROFIT on normal stock, elasticity must exceed about {50/ (50-35):.1f}  (price 50, cost 35); below that, discounts only help stock that would expire")
if os.path.exists("price_test_truth.json") and "SIMULATED" in a.file:
    t = json.load(open("price_test_truth.json"))["true_elasticity"]; print(f"  CHECK against the true value used to make the data: true {t:.2f}, measured {eps:.2f}, inside the interval: {lo <= t <= hi}")
json.dump(dict(elasticity=round(float(eps), 3), ci_low=round(float(lo), 3), ci_high=round(float(hi), 3), n_days=int(len(d)), source=os.path.basename(a.file)), open("price_response.json", "w"), indent=2)
