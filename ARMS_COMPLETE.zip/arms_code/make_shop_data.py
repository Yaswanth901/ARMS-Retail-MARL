"""Creates ONE MONTH of SIMULATED shop data (bill lines), so the new tools can be demonstrated without real data.
It is synthetic: nothing here is a real shop. The true settings are saved in shop_month_truth.json so we can check
that calibrate_from_sales.py recovers them.
Run:  python make_shop_data.py"""
import json, numpy as np, pandas as pd
from datetime import date, timedelta

rng = np.random.default_rng(2026)
START, DAYS = date(2026, 9, 1), 30
WK = [1.0, 1.0, 1.0, 1.0, 1.0, 1.15, 1.15]                  # Mon..Sun traffic multiplier (true value)
BILLS_PER_DAY = 42                                           # mean bills on a weekday (true value)
# product: (category, price, cost, shelf_life_days, probability of being on a bill, qty values, qty probs)
P = {"Milk packet": ("perishable", 50, 35, 4, 0.26, [1, 2], [0.9, 0.1]),
     "Curd cup":    ("perishable", 35, 24, 5, 0.15, [1, 2], [0.75, 0.25]),
     "Bread":       ("perishable", 40, 30, 4, 0.22, [1, 2], [0.8, 0.2]),
     "Biscuits":    ("add-on", 30, 18, None, 0.25, [1, 2, 3], [0.7, 0.25, 0.05]),
     "Chips":       ("add-on", 25, 14, None, 0.18, [1, 2, 3], [0.7, 0.25, 0.05]),
     "Juice":       ("add-on", 45, 28, None, 0.12, [1, 2], [0.8, 0.2]),
     "Chocolate":   ("add-on", 70, 40, None, 0.08, [1, 2], [0.85, 0.15])}
AFFINITY = {("Milk packet", "Bread"): 1.6, ("Milk packet", "Biscuits"): 1.5, ("Curd cup", "Chips"): 1.3}
ORDER_UP_TO = {"Milk packet": 40, "Curd cup": 24, "Bread": 36}     # this shop slightly over-stocks, so some stock expires
HOUR_W = {7: 6, 8: 10, 9: 8, 10: 4, 11: 3, 12: 3, 13: 3, 14: 2, 15: 3, 16: 4, 17: 8, 18: 10, 19: 9, 20: 5, 21: 2}
hours = np.array(list(HOUR_W)); hw = np.array(list(HOUR_W.values()), float); hw /= hw.sum()

def make_items(r):
    items = []
    for k in ("Milk packet", "Curd cup"):
        if r.random() < P[k][4]: items.append(k)
    for k in ("Bread", "Biscuits", "Chips", "Juice", "Chocolate"):
        pr = P[k][4]
        for (a, b), f in AFFINITY.items():
            if b == k and a in items: pr = min(0.9, pr * f)
        if r.random() < pr: items.append(k)
    if not items: items = ["Milk packet"] if r.random() < 0.5 else ["Bread"]
    return items

batches = {k: [] for k in ORDER_UP_TO}                      # per product: list of [expiry_date, units]
lines, stock_rows, bill_id = [], [], 0
for d in range(DAYS):
    day = START + timedelta(days=d); wd = day.weekday()
    opening = {}
    for k, level in ORDER_UP_TO.items():                     # morning delivery tops the shelf up to the level
        have = sum(u for _, u in batches[k]); deliver = max(0, level - have)
        if deliver: batches[k].append([day + timedelta(days=P[k][3]), deliver])
        opening[k] = have + deliver
    sold = {k: 0 for k in ORDER_UP_TO}; unmet = {k: 0 for k in ORDER_UP_TO}
    n_bills = rng.poisson(BILLS_PER_DAY * WK[wd])
    for t in sorted(rng.choice(hours, n_bills, p=hw) * 60 + rng.integers(0, 60, n_bills)):
        bill_id += 1
        for k in make_items(rng):
            cat, price, cost, shelf, _, qv, qp = P[k]; qty = int(rng.choice(qv, p=qp)); exp = ""
            if cat == "perishable":
                got = 0; bl = sorted(batches[k]); fresh = rng.random() < 0.7        # most customers pick the freshest
                for b in (bl[::-1] if fresh else bl):
                    take = min(qty - got, b[1]); b[1] -= take; got += take
                    if take and not exp: exp = b[0].isoformat()
                    if got == qty: break
                batches[k] = [b for b in batches[k] if b[1] > 0]
                unmet[k] += qty - got; sold[k] += got; qty = got
                if qty == 0: continue
            lines.append(dict(date=day.isoformat(), weekday=day.strftime("%a"), time=f"{int(t)//60:02d}:{int(t)%60:02d}", bill_id=bill_id,
                              product=k, category=cat, qty=qty, unit_price=price, unit_cost=cost, line_amount=qty * price,
                              line_margin=qty * (price - cost), expiry_date=exp, promo="none"))
    for k in ORDER_UP_TO:                                    # end of day: remove expired units, age the rest
        expired = sum(u for e, u in batches[k] if e <= day + timedelta(days=1))
        batches[k] = [b for b in batches[k] if b[0] > day + timedelta(days=1)]
        stock_rows.append(dict(date=day.isoformat(), product=k, opening_stock=opening[k], sold=sold[k], unmet=unmet[k],
                               expired=expired, closing_stock=sum(u for _, u in batches[k])))
sales = pd.DataFrame(lines); stock = pd.DataFrame(stock_rows)
sales.to_csv("SIMULATED_shop_month_sales.csv", index=False); stock.to_csv("SIMULATED_shop_month_stock.csv", index=False)
chk = np.random.default_rng(1); mc = [make_items(chk) for _ in range(100000)]          # true effective probability per bill
eff = {k: round(sum(k in it for it in mc) / len(mc), 3) for k in P}
json.dump(dict(weekday_mult=WK, bills_per_weekday=BILLS_PER_DAY, product_probability=eff,
               note="True settings used to generate the SIMULATED data"), open("shop_month_truth.json", "w"), indent=2)
print(f"SIMULATED one-month shop data written: {len(sales)} bill lines, {sales.bill_id.nunique()} bills, {DAYS} days")
print(f"  SIMULATED_shop_month_sales.csv ({len(sales)} rows)   SIMULATED_shop_month_stock.csv ({len(stock)} rows)   shop_month_truth.json")
print(f"  total sales Rs {sales.line_amount.sum():,.0f}   total margin Rs {sales.line_margin.sum():,.0f}   expired perishable units {int(stock.expired.sum())}   unmet units {int(stock.unmet.sum())}")
