"""NEAR-EXPIRY OFFER PROTOTYPE: "free packet with a bigger bill" versus a plain discount versus doing nothing.
Uses the real bill sizes and waste from the one-month shop data (run make_shop_data.py first).
IMPORTANT: how customers respond (the numbers marked ASSUMED) is NOT measured; a pilot is needed to measure them.
Run:  python offer_sim.py"""
import numpy as np, pandas as pd
rng = np.random.default_rng(5)
s = pd.read_csv("SIMULATED_shop_month_sales.csv"); st = pd.read_csv("SIMULATED_shop_month_stock.csv")
cost = {"Milk packet": 35, "Curd cup": 24, "Bread": 30}
leftover_per_day = st.expired.sum() / st.date.nunique()                      # units that would be thrown away each day (from data)
unit_cost = sum(r.expired * cost[r["product"]] for _, r in st.iterrows()) / st.expired.sum()
price = float(s[s.category == "perishable"].unit_price.mean())               # average price of those items
s["hour"] = s.time.str[:2].astype(int)
bills = s.groupby("bill_id").agg(value=("line_amount", "sum"), hour=("hour", "first"))
evening = bills[bills.hour >= 17].value.values                               # bill sizes in the evening (from data)
eve_bills_per_day = len(evening) / s.date.nunique()
addon_margin_rate = float(s[s.category == "add-on"].line_margin.sum() / s[s.category == "add-on"].line_amount.sum())
print(f"FROM THE SHOP DATA: {leftover_per_day:.1f} units a day expire (worth Rs {leftover_per_day*unit_cost:,.0f} a day at cost, "
      f"Rs {leftover_per_day*unit_cost*30:,.0f} a month); {eve_bills_per_day:.0f} evening bills a day, average Rs {evening.mean():.0f}; add-on margin {addon_margin_rate:.0%}\n")

ACCEPT = {"15% off": 0.04, "35% off": 0.10}      # ASSUMED: chance an evening bill takes a discounted near-expiry unit
TAKE_FREE = 0.80                                  # ASSUMED: chance an eligible bill takes the free unit
def day(policy, T=None, q=0.0, d=None):
    L = rng.poisson(leftover_per_day); nb = rng.poisson(eve_bills_per_day); v = rng.choice(evening, nb)
    if policy == "nothing" or L == 0: return 0.0, 0
    if policy == "discount":
        n = min(L, rng.binomial(nb, ACCEPT[d])); return n * price * (0.85 if d == "15% off" else 0.65), n
    gift, extra, left = 0, 0.0, L                                            # free-with-bill offer
    for x in v:
        if left == 0: break
        if x >= T:
            if rng.random() < TAKE_FREE: left -= 1; gift += 1
        elif x >= T - 50 and rng.random() < q:                              # customer adds items to reach the bill size
            extra += (T - x) * addon_margin_rate; left -= 1; gift += 1
    return extra, gift
def avg(policy, **kw):
    r = np.array([day(policy, **kw) for _ in range(4000)]); return r[:, 0].mean(), r[:, 1].mean()

print(f"{'Policy (evening, units that would expire)':46s} {'Rs per day':>10s} {'Rs per month':>12s} {'Waste avoided /day':>19s}")
base = [("Do nothing", "nothing", {}), ("Plain discount 15%", "discount", dict(d="15% off")), ("Plain discount 35%", "discount", dict(d="35% off"))]
for name, pol, kw in base:
    m, n = avg(pol, **kw); print(f"{name:46s} {m:10.1f} {m*30:12.0f} {n:19.2f}")
print("\nFree unit with a bill of Rs T or more. q = chance that a customer just below T adds items to qualify (ASSUMED):")
print(f"{'T':>5s} " + " ".join(f"{'q='+str(q):>10s}" for q in (0.0, 0.1, 0.2, 0.3, 0.5)) + "     (Rs per day extra margin)")
for T in (75, 100, 150):
    print(f"{T:5d} " + " ".join(f"{avg('offer', T=T, q=q)[0]:10.1f}" for q in (0.0, 0.1, 0.2, 0.3, 0.5)))
print("\nWHAT A PILOT MUST MEASURE: for the offer to earn as much cash as a plain 35% discount, how few evening bills may accept the discount?")
print(f"{'q (customers who add items)':30s} {'offer earns (Rs/day)':>21s} {'discount acceptance at break-even':>34s}")
for q in (0.2, 0.3, 0.5):
    o = avg("offer", T=100, q=q)[0]; found = None
    for a_ in np.arange(0.005, 0.30, 0.005):
        ACCEPT["35% off"] = a_
        rr = np.array([day("discount", d="35% off") for _ in range(1500)])[:, 0].mean()
        if rr >= o: found = a_; break
    ACCEPT["35% off"] = 0.10
    print(f"{q:<30.1f} {o:21.1f} {('%.1f%% of evening bills' % (found*100)) if found else 'above 30%':>34s}")
n_gift = avg("offer", T=100, q=0.3)[1]; n_disc = avg("discount", d="35% off")[1]
print(f"\nWaste avoided per day: free-with-bill offer {n_gift:.1f} units vs 35% discount {n_disc:.1f} units.")
print("READ THIS: with these ASSUMED responses the offer earns less cash than a 35% discount but avoids more waste and builds bigger bills.")
print("It wins on cash only if few customers would take the discounted packet. That is exactly what a pilot must measure.")
