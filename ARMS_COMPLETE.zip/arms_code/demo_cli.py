"""
PowerShell demo - same engine as the Streamlit app, no browser needed.

  python demo_cli.py                          # 14-day replay, Two-Agent RL + guardrails
  python demo_cli.py --method rule            # rule | single | two | guarded | fallback
  python demo_cli.py --days 30 --seed 3
  python demo_cli.py --spike-day 5 --spike-len 4 --spike-mult 2.5   # demand shock
  python demo_cli.py --demand 18 --shelf-life 3                     # different store
  python demo_cli.py --compare                # all 5 methods on the same demand
  python demo_cli.py --batch 30               # 30 test episodes, mean +/- std
  python demo_cli.py --policy                 # what the trained agent chooses
  python demo_cli.py --stress                 # all methods in 6 harder scenarios (about 1 minute)
"""
import argparse
import os
import sys
import numpy as np
import json
import app_core as C
import agents_multi as AM
import retail_env_multi as RM

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def show_episode(df, title):
    print("\n" + title)
    print("=" * 108)
    print(f"{'Day':>3} {'Stock':>5} {'Exp':>3} {'Dem':>4}  {'Price tier':<10} {'Reorder':<10} "
          f"{'Sold':>4} {'Waste':>5} {'Unmet':>5} {'Profit(Rs)':>10}")
    print("-" * 108)
    for _, r in df.iterrows():
        print(f"{int(r['Day']):>3} {int(r['Stock']):>5} {int(r['Days to expiry']):>3} {int(r['Demand']):>4}  "
              f"{r['Price tier']:<10} {r['Reorder']:<10} {int(r['Sold']):>4} {int(r['Wasted']):>5} "
              f"{int(r['Unmet']):>5} {float(r['Profit (Rs)']):>10.1f}")
        print("      -> " + str(r["Situation"]))
    print("-" * 108)
    print(f"TOTAL profit Rs {df['Profit (Rs)'].sum():.0f} | wasted {int(df['Wasted'].sum())} units | "
          f"unmet demand {int(df['Unmet'].sum())} units")


def main():
    ap = argparse.ArgumentParser(description="ARMS PowerShell demo")
    ap.add_argument("--method", default="guarded", choices=list(C.METHOD_KEYS))
    ap.add_argument("--days", type=int, default=14)
    ap.add_argument("--seed", type=int, default=7, help="random seed for demand")
    ap.add_argument("--demand", type=float, default=12.0, help="average daily demand")
    ap.add_argument("--shelf-life", type=int, default=4)
    ap.add_argument("--spike-day", type=int, default=0, help="1-based day a demand shock starts (0 = none)")
    ap.add_argument("--spike-len", type=int, default=5)
    ap.add_argument("--spike-mult", type=float, default=2.0)
    ap.add_argument("--gap", type=float, default=C.CONFIDENCE_GAP, help="fallback confidence threshold")
    ap.add_argument("--compare", action="store_true")
    ap.add_argument("--batch", type=int, default=0, help="number of 60-day test episodes")
    ap.add_argument("--policy", action="store_true")
    ap.add_argument("--stress", action="store_true")
    ap.add_argument("--store", action="store_true", help="three-product store (milk, curd, bread) sharing one shelf")
    ap.add_argument("--store-method", default="tuned", choices=["rule", "tuned", "rl"])
    ap.add_argument("--stress-n", type=int, default=15, help="episodes per stress scenario")
    ap.add_argument("--profile", action="store_true",
                    help="use the weekly demand pattern measured from Favorita (needs demand_profile.json)")
    a = ap.parse_args()

    if a.store:
        pa, pt = os.path.join(C.BASE, "trained_store3_agents.json"), os.path.join(C.BASE, "store3_tuned_targets.json")
        if not (os.path.exists(pa) and os.path.exists(pt)):
            print("Store agents not found. Run:  python multi_experiment.py")
            sys.exit(1)
        with open(pt) as f:
            targets = json.load(f)["targets"]
        pols = {"rule": ("Original rule", AM.policy_original), "tuned": ("Tuned order-up-to rule", AM.policy_tuned(targets)),
                "rl": ("RL (per-product agents)", AM.policy_rl(AM.load_agents(pa)))}
        u3 = np.random.default_rng(a.seed).random((a.days, RM.N))
        shocks3 = C.make_shocks(a.spike_day, a.spike_len, a.spike_mult)
        label, pol = pols[a.store_method]
        df = AM.run_episode(pol, u3, a.days, shocks3)
        print(f"ARMS three-product store | shelf capacity {RM.CAPACITY} units | {label} | demand seed {a.seed}")
        print("=" * 100)
        print(f"{'Day':>3} {'Product':<6} {'Stock':>5} {'Exp':>3} {'Dem':>4}  {'Price tier':<10} {'Reorder':<10} {'Sold':>4} {'Waste':>5} {'Unmet':>5} {'Profit':>8}")
        for day, g in df.groupby("day"):
            for _, r in g.iterrows():
                print(f"{int(r['day']):>3} {r['product']:<6} {int(r['stock_start']):>5} {int(r['expiry']):>3} {int(r['demand']):>4}  "
                      f"{C.SHORT_PRICE[r['price_tier']]:<10} {C.SHORT_INV[r['reorder']]:<10} {int(r['sold']):>4} {int(r['wasted']):>5} {int(r['unmet']):>5} {r['profit']:>8.1f}")
            print(f"    shelf after orders: {int(g['shelf_used'].iloc[0])}/{RM.CAPACITY}" + ("  (some orders cut to fit)" if g['cut'].sum() else ""))
        print("-" * 100)
        print("ALL METHODS ON THE SAME DEMAND:")
        for name, p_ in pols.values():
            dd = AM.run_episode(p_, u3, a.days, shocks3)
            print(f"  {name:<26} profit Rs {dd['profit'].sum():8.0f} | wasted {int(dd['wasted'].sum()):3d} | unmet {int(dd['unmet'].sum()):4d} | orders cut {int(dd['cut'].sum()):3d}")
        print("One demand trace can favour any method; the saved 100-episode results are in store3_results.csv.")
        return

    agents = C.load_agents()
    if agents is None:
        print("No trained agents found. Run:  python train_for_app.py   (about 2 minutes)")
        sys.exit(1)

    wm = None
    if a.profile:
        prof = C.load_profile()
        if prof is None:
            print("No demand_profile.json yet. Run calibrate_favorita.py first (see HOW_TO_RUN.md).")
            sys.exit(1)
        wm = prof["weekday_mult"]
        print("using real-data weekly pattern (Mon-Sun):", ", ".join(f"{x:.2f}" for x in wm))
    shocks = C.make_shocks(a.spike_day, a.spike_len, a.spike_mult)
    uniforms = np.random.default_rng(a.seed).random(a.days)
    print("ARMS demo | simulated milk-packet store (bought Rs 35, sold Rs 50, demand and costs are assumptions)")
    print(f"scenario: avg demand {a.demand}, shelf life {a.shelf_life} days, demand seed {a.seed}"
          + (f", demand x{a.spike_mult} for {a.spike_len} days from day {a.spike_day}" if a.spike_day else ""))

    with C.scenario(a.demand, a.shelf_life, wm):
        if a.stress:
            print("\nStress test: every method was built for demand 12 / shelf life 4 and is NOT retrained. "
                  f"Mean profit (Rs per 60-day episode, {a.stress_n} episodes):")
            sdf = C.stress_test(agents, n=a.stress_n, gap=a.gap)
            sdf.to_csv(os.path.join(C.BASE, "stress_test_results.csv"), index=False)
            short = {C.METHODS[0]: "Rule", C.METHODS[1]: "1-Agent", C.METHODS[2]: "2-Agent",
                     C.METHODS[3]: "2-Agent+guard", C.METHODS[4]: "2-Ag+guard+fb", C.METHODS[5]: "OrderUpTo",
                     C.METHODS[6]: "(s,S) rule", C.METHODS[7]: "MAPPO"}
            print(C.stress_pivot(sdf).rename(columns=short).to_string())
            print("\nNo method wins everywhere. Wasted units:")
            print(C.stress_pivot(sdf, "Wasted").rename(columns=short).to_string())
        elif a.policy:
            print("\nWhat the trained Two-Agent policy (trained with guardrails) chooses:")
            print(C.policy_table(agents["two_g"]).to_string())
            print("\nNote: the agent's state is coarse (3 stock bins) and cannot see how many units are about to expire.")
        elif a.batch:
            print(f"\nRunning {a.batch} test episodes x 5 methods (60 days each)...")
            b = C.batch_eval(agents, a.batch, 60, shocks, a.gap)
            print(C.summarize_batch(b).to_string(index=False))
            print("\nThese agents were trained once, with one seed. The 5-seed v2 test found no significant winner.")
        elif a.compare:
            res = C.compare_methods(agents, uniforms, a.days, shocks, a.gap)
            print("\nAll methods on the SAME demand trace:")
            print(C.totals(res).to_string(index=False))
            print("\nOne trace can favour any method; use --batch for a fairer view.")
        else:
            method = C.METHOD_KEYS[a.method]
            df = C.run_episode(method, agents, uniforms, a.days, shocks, a.gap)
            show_episode(df, f"{method}  |  {a.days}-day replay")


if __name__ == "__main__":
    main()
