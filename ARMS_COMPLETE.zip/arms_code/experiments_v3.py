"""
Research extensions. Each experiment appends its results to a CSV as it goes.
  python experiments_v3.py ablation     # does MAPPO's edge come from learning or from extra inputs? does stock-by-age help?
  python experiments_v3.py delays       # random supplier delays: does seeing the units on order help?
  python experiments_v3.py pricing      # finer discounts + a MEASURED price response: does the pricing agent learn to clear expiring stock?
Options: --seeds 5  --iters 120   (MAPPO training seeds and PPO iterations)
All agents train on episodes they never see again at test time; the rules are tuned on separate tuning episodes.
"""
import argparse, json, os, time
import numpy as np, pandas as pd
import mappo_v3 as W
from retail_env_v3 import FINE_LEVELS, LEGACY_LEVELS

HERE = os.path.dirname(os.path.abspath(__file__))
def have(name):
    """(method, seed) pairs already saved, so an interrupted run can simply be started again."""
    p = os.path.join(HERE, name)
    if not os.path.exists(p): return set()
    d = pd.read_csv(p); return set(zip(d["method"], d["seed"].astype(str))) | set((m, "any") for m in d["method"])

def save(rows, name, first):
    df = pd.DataFrame(rows); p = os.path.join(HERE, name)
    df.to_csv(p, mode="w" if first else "a", header=first, index=False)

def rule_ss_position(thr):                       # reorder point on stock + units already on order
    return lambda s: (0, 2 if s["stock"] + s["on_order"] <= thr else 0)

def tune_generic(make_rule, env_kw, grid=range(8, 56, 2), n=30, seed0=500000):
    best = max(((t, W.evaluate(make_rule(t), env_kw, n, seed0)["profit"]) for t in grid), key=lambda x: x[1])
    return best[0]

def ablation(seeds, iters):
    scen = {"Normal shop (12 a day, 4-day shelf)": {}, "Quiet shop (7 a day)": {"base_demand": 7.0}, "Short shelf life (2 days)": {"shelf": 2}}
    rows, first = [], not os.path.exists(os.path.join(HERE, "results_ablation.csv")); done = have("results_ablation.csv")
    for sname, kw in scen.items():
        for mname, pol in (("Tuned (s,S) rule", W.rule_ss(26)), ("Adaptive (s,S) rule, uses smoothed demand", W.rule_ss_adaptive())):
            if (mname, "-") not in done: rows.append(dict(scenario=sname, method=mname, seed="-", **W.evaluate(pol, kw, 40)))
    for feat in ("basic", "extras", "age"):
        for sd in range(seeds):
            if (f"MAPPO inputs: {feat}", str(sd)) in done: continue
            if rows: save(rows, "results_ablation.csv", first); first = False; rows = []
            t0 = time.time(); ag, _ = W.train(seed=300 + sd, iterations=iters, feat=feat)
            for sname, kw in scen.items():
                rows.append(dict(scenario=sname, method=f"MAPPO inputs: {feat}", seed=sd, **W.evaluate(ag.policy(), kw, 40)))
            print(f"[ablation] {feat} seed {sd} done in {time.time()-t0:.0f}s", flush=True); save(rows, "results_ablation.csv", first); first = False; rows = []
    if rows: save(rows, "results_ablation.csv", first)

def delays(seeds, iters):
    kw = {"delay": (0.6, 0.3, 0.1)}; rows, first = [], not os.path.exists(os.path.join(HERE, "results_delays.csv")); done = have("results_delays.csv")
    thr = tune_generic(W.rule_ss, kw); thr_pos = tune_generic(rule_ss_position, kw, grid=range(10, 70, 2))
    print(f"[delays] tuned thresholds: stock-only {thr}, stock+on-order {thr_pos}", flush=True)
    if ("Tuned (s,S) rule (re-tuned for delays)", "-") not in done:
        rows.append(dict(method="Tuned (s,S) rule (re-tuned for delays)", seed="-", **W.evaluate(W.rule_ss(thr), kw, 60)))
        rows.append(dict(method="Tuned rule on stock + units on order", seed="-", **W.evaluate(rule_ss_position(thr_pos), kw, 60)))
    for feat in ("extras", "pipe", "full"):
        for sd in range(seeds):
            if (f"MAPPO inputs: {feat}", str(sd)) in done: continue
            if rows: save(rows, "results_delays.csv", first); first = False; rows = []
            t0 = time.time(); ag, _ = W.train(seed=400 + sd, iterations=iters, feat=feat, env_kw=kw)
            rows.append(dict(method=f"MAPPO inputs: {feat}", seed=sd, **W.evaluate(ag.policy(), kw, 60)))
            print(f"[delays] {feat} seed {sd} done in {time.time()-t0:.0f}s", flush=True); save(rows, "results_delays.csv", first); first = False; rows = []
    if rows: save(rows, "results_delays.csv", first)

def pricing(seeds, iters):
    path = os.path.join(HERE, "results_pricing.csv"); pj = os.path.join(HERE, "price_response.json")
    eps_hat = json.load(open(pj))["elasticity"] if os.path.exists(pj) else 2.0
    print(f"[pricing] measured elasticity used: {eps_hat:.2f}", flush=True)
    existing = pd.read_csv(path) if os.path.exists(path) else pd.DataFrame(columns=["elasticity", "method", "seed"]); first = not os.path.exists(path)
    def done(eps, method, sd): return bool(((existing.elasticity.astype(float) == float(eps)) & (existing.method == method) & (existing.seed.astype(str) == str(sd))).any())
    def flush(rows):
        nonlocal first, existing
        if rows: save(rows, "results_pricing.csv", first); first = False; existing = pd.concat([existing, pd.DataFrame(rows)], ignore_index=True)
    for eps in (1.0, round(eps_hat, 2)):
        kw = {"levels": FINE_LEVELS, "elasticity": eps}; rows = []
        if not done(eps, "Regular price + tuned (s,S)", "-"):
            rows.append(dict(elasticity=eps, method="Regular price + tuned (s,S)", seed="-", **W.evaluate(W.rule_ss(26), kw, 60)))
            rows.append(dict(elasticity=eps, method="Manual markdown: 30% off when 2+ units expire today", seed="-", **W.evaluate(W.rule_markdown(FINE_LEVELS), kw, 60)))
            flush(rows)
        for feat in ("extras", "age"):
            for sd in range(seeds):
                if done(eps, f"MAPPO inputs: {feat}", sd): continue
                t0 = time.time(); ag, _ = W.train(seed=500 + sd, iterations=iters, feat=feat, env_kw=kw); rows = []
                rows.append(dict(elasticity=eps, method=f"MAPPO inputs: {feat}", seed=sd, **W.evaluate(ag.policy(), kw, 60)))
                if feat == "age": rows.append(dict(elasticity=eps, method="MAPPO inputs: age, price forced to regular", seed=sd, **W.evaluate(ag.policy(force_price=0), kw, 60)))
                flush(rows); print(f"[pricing] elasticity {eps} {feat} seed {sd} done in {time.time()-t0:.0f}s", flush=True)

def longer(seeds, iters):
    """Fairness check: are the conclusions the same when the agents with more inputs train 2.5x longer (300 iterations)?"""
    path = os.path.join(HERE, "results_longer.csv"); existing = pd.read_csv(path) if os.path.exists(path) else pd.DataFrame(columns=["experiment", "method", "seed"]); first = not os.path.exists(path)
    scen = {"Normal shop (12 a day, 4-day shelf)": {}, "Quiet shop (7 a day)": {"base_demand": 7.0}, "Short shelf life (2 days)": {"shelf": 2}}
    jobs = [("ablation", "extras", {}), ("ablation", "age", {}), ("delays", "pipe", {"delay": (0.6, 0.3, 0.1)}), ("delays", "full", {"delay": (0.6, 0.3, 0.1)})]
    for exp, feat, kw in jobs:
        for sd in range(seeds):
            if ((existing.experiment == exp) & (existing.method == f"MAPPO inputs: {feat} (300 iterations)") & (existing.seed.astype(str) == str(sd))).any(): continue
            t0 = time.time(); ag, _ = W.train(seed=600 + sd, iterations=iters, feat=feat, env_kw=kw); rows = []
            for sname, skw in (scen.items() if exp == "ablation" else [("Supplier delays", kw)]):
                rows.append(dict(experiment=exp, scenario=sname, method=f"MAPPO inputs: {feat} ({iters} iterations)", seed=sd, **W.evaluate(ag.policy(), skw, 40)))
            save(rows, "results_longer.csv", first); first = False; existing = pd.concat([existing, pd.DataFrame(rows)], ignore_index=True)
            print(f"[longer] {exp} {feat} seed {sd} done in {time.time()-t0:.0f}s", flush=True)

def pricing_waste(seeds, iters):
    """Does pricing start to matter when a lot of stock expires? A quiet shop (7 a day) with a measured price response."""
    pj = os.path.join(HERE, "price_response.json"); eps_hat = round(json.load(open(pj))["elasticity"], 2) if os.path.exists(pj) else 2.0
    kw = {"levels": FINE_LEVELS, "elasticity": eps_hat, "base_demand": 7.0}; path = os.path.join(HERE, "results_pricing_waste.csv")
    existing = pd.read_csv(path) if os.path.exists(path) else pd.DataFrame(columns=["method", "seed"]); first = not os.path.exists(path)
    thr = tune_generic(W.rule_ss, kw); print(f"[pricing_waste] elasticity {eps_hat}, tuned reorder point for a quiet shop: {thr}", flush=True)
    def has(m, sd): return bool(((existing.method == m) & (existing.seed.astype(str) == str(sd))).any())
    def flush(rows):
        nonlocal first, existing
        save(rows, "results_pricing_waste.csv", first); first = False; existing = pd.concat([existing, pd.DataFrame(rows)], ignore_index=True)
    if not has("Regular price + re-tuned (s,S)", "-"):
        flush([dict(method="Regular price + re-tuned (s,S)", seed="-", **W.evaluate(W.rule_ss(thr), kw, 60)),
               dict(method="Manual markdown: 30% off when 2+ units expire today", seed="-", **W.evaluate(W.rule_markdown(FINE_LEVELS, thr=thr), kw, 60))])
    for sd in range(seeds):
        if has("MAPPO inputs: age", sd): continue
        t0 = time.time(); ag, _ = W.train(seed=800 + sd, iterations=iters, feat="age", env_kw=kw)
        flush([dict(method="MAPPO inputs: age", seed=sd, **W.evaluate(ag.policy(), kw, 60)),
               dict(method="MAPPO inputs: age, price forced to regular", seed=sd, **W.evaluate(ag.policy(force_price=0), kw, 60))])
        print(f"[pricing_waste] seed {sd} done in {time.time()-t0:.0f}s", flush=True)

def sensitivity(seeds, iters):
    """How sensitive is MAPPO to its main settings? One setting changed at a time, 3 scenarios, fresh test episodes."""
    path = os.path.join(HERE, "results_sensitivity.csv"); existing = pd.read_csv(path) if os.path.exists(path) else pd.DataFrame(columns=["method", "seed"]); first = not os.path.exists(path)
    scen = {"Normal shop (12 a day, 4-day shelf)": {}, "Quiet shop (7 a day)": {"base_demand": 7.0}, "Short shelf life (2 days)": {"shelf": 2}}
    configs = [("baseline (learning rate 1e-3, clip 0.2, gamma 0.97)", {}), ("learning rate 3e-4", {"lr": 3e-4}), ("learning rate 3e-3", {"lr": 3e-3}),
               ("clip 0.1", {"clip": 0.1}), ("clip 0.3", {"clip": 0.3}), ("gamma 0.90", {"gamma": 0.90}), ("gamma 0.99", {"gamma": 0.99})]
    for name, hp in configs:
        for sd in range(seeds):
            if ((existing.method == name) & (existing.seed.astype(str) == str(sd))).any(): continue
            t0 = time.time(); ag, _ = W.train(seed=900 + sd, iterations=iters, feat="extras", **hp)
            rows = [dict(scenario=sn, method=name, seed=sd, **W.evaluate(ag.policy(), skw, 40)) for sn, skw in scen.items()]
            save(rows, "results_sensitivity.csv", first); first = False; existing = pd.concat([existing, pd.DataFrame(rows)], ignore_index=True)
            print(f"[sensitivity] {name} seed {sd} done in {time.time()-t0:.0f}s", flush=True)

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("exp", choices=["ablation", "delays", "pricing", "pricing_waste", "longer", "sensitivity"]); ap.add_argument("--seeds", type=int, default=5); ap.add_argument("--iters", type=int, default=120)  # use --iters 300 --seeds 3 for the "longer" check
    a = ap.parse_args(); {"ablation": ablation, "delays": delays, "pricing": pricing, "pricing_waste": pricing_waste, "longer": longer, "sensitivity": sensitivity}[a.exp](a.seeds, a.iters); print("done", a.exp)
