"""
Three baselines matching Section 12.1 of the proposal:
  1. Rule-based control (fixed thresholds)
  2. Single-Agent RL (one Q-table, joint action space of 9 combos)
  3. Two-Agent MARL (independent Q-learning, Pricing acts first, Inventory conditioned on it)
"""
import numpy as np
from retail_env import PRICE_ACTIONS, INV_ACTIONS

def discretize(state):
    """Collapse the continuous state into small bins for a tabular Q-table."""
    stock = state["stock"]
    stock_bin = 0 if stock < 10 else (1 if stock < 25 else 2)          # low/med/high
    expiry_bin = min(state["days_to_expiry"], 3)                        # 0..3 (0 = expires today)
    demand_bin = 0 if state["recent_demand"] < 9 else (1 if state["recent_demand"] < 16 else 2)
    return (stock_bin, expiry_bin, demand_bin)


# ---------------------------------------------------------------- Rule-based
def rule_based_policy(state):
    stock, expiry = state["stock"], state["days_to_expiry"]
    if expiry <= 1 and stock > 5:
        price = "CLEARANCE_DISCOUNT"
    elif expiry <= 2:
        price = "MODERATE_DISCOUNT"
    else:
        price = "REGULAR_PRICE"
    if stock < 10:
        inv = "FULL_REORDER"
    elif stock < 20:
        inv = "SMALL_REORDER"
    else:
        inv = "NO_REORDER"
    return price, inv


# ---------------------------------------------------------- Single-agent RL
class SingleAgentQLearner:
    """One agent, one Q-table over the 3x3=9 joint action space."""
    JOINT_ACTIONS = [(p, i) for p in PRICE_ACTIONS for i in INV_ACTIONS]

    def __init__(self, alpha=0.15, gamma=0.95, eps=1.0, eps_decay=0.995, eps_min=0.05):
        self.Q = {}
        self.alpha, self.gamma = alpha, gamma
        self.eps, self.eps_decay, self.eps_min = eps, eps_decay, eps_min

    def _row(self, s):
        return self.Q.setdefault(s, np.zeros(len(self.JOINT_ACTIONS)))

    def act(self, state):
        s = discretize(state)
        if np.random.rand() < self.eps:
            idx = np.random.randint(len(self.JOINT_ACTIONS))
        else:
            idx = int(np.argmax(self._row(s)))
        return idx, self.JOINT_ACTIONS[idx]

    def update(self, s_disc, idx, reward, s_next_disc, done):
        q = self._row(s_disc)
        target = reward if done else reward + self.gamma * np.max(self._row(s_next_disc))
        q[idx] += self.alpha * (target - q[idx])

    def decay(self):
        self.eps = max(self.eps_min, self.eps * self.eps_decay)


# ------------------------------------------------------- Two-agent MARL
class TwoAgentQLearner:
    """Independent Q-learning: Pricing acts first; Inventory's state includes Pricing's action."""

    def __init__(self, alpha=0.15, gamma=0.95, eps=1.0, eps_decay=0.995, eps_min=0.05):
        self.Qp = {}  # pricing Q-table: state -> 3 values
        self.Qi = {}  # inventory Q-table: (state, price_action) -> 3 values
        self.alpha, self.gamma = alpha, gamma
        self.eps, self.eps_decay, self.eps_min = eps, eps_decay, eps_min

    def _rowp(self, s):
        return self.Qp.setdefault(s, np.zeros(len(PRICE_ACTIONS)))

    def _rowi(self, s, p_idx):
        key = (s, p_idx)
        return self.Qi.setdefault(key, np.zeros(len(INV_ACTIONS)))

    def act(self, state):
        s = discretize(state)
        if np.random.rand() < self.eps:
            p_idx = np.random.randint(len(PRICE_ACTIONS))
        else:
            p_idx = int(np.argmax(self._rowp(s)))
        price_action = PRICE_ACTIONS[p_idx]

        if np.random.rand() < self.eps:
            i_idx = np.random.randint(len(INV_ACTIONS))
        else:
            i_idx = int(np.argmax(self._rowi(s, p_idx)))
        inv_action = INV_ACTIONS[i_idx]
        return (s, p_idx, i_idx), (price_action, inv_action)

    def update(self, s, p_idx, i_idx, r_price, r_inventory, s_next, done):
        qp = self._rowp(s)
        target_p = r_price if done else r_price + self.gamma * np.max(self._rowp(s_next))
        qp[p_idx] += self.alpha * (target_p - qp[p_idx])

        qi = self._rowi(s, p_idx)
        target_i = r_inventory if done else r_inventory + self.gamma * np.max(self._rowi(s_next, p_idx))
        qi[i_idx] += self.alpha * (target_i - qi[i_idx])

    def decay(self):
        self.eps = max(self.eps_min, self.eps * self.eps_decay)
