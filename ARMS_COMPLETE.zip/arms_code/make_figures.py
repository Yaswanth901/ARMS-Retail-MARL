"""Turns perf_*.csv into madam's metrics, tables and figures.   python make_figures.py
Writes figures/*.png and perf_summary.json (every number used by the report and the presentation)."""
import json, os
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
HERE = os.path.dirname(os.path.abspath(__file__)); FIG = os.path.join(HERE, "figures"); os.makedirs(FIG, exist_ok=True)
ORDER = ["Q-learning (tabular, two agents)", "DQN", "Double DQN", "PPO (single agent)", "MAPPO (ours)"]
RULES = ["Tuned (s,S) rule", "Tuned order-up-to rule", "Original rule", "Random (masked)"]
COL = {"Q-learning (tabular, two agents)": "#8C8C8C", "DQN": "#2E75B6", "Double DQN": "#2A9D8F", "PPO (single agent)": "#E0A100", "MAPPO (ours)": "#B60345",
       "Tuned (s,S) rule": "#333333", "Tuned order-up-to rule": "#6A4C93", "Original rule": "#9E9E9E", "Random (masked)": "#C0C0C0"}
SHORT = {"Tuned (s,S) rule": "(s,S) rule", "Tuned order-up-to rule": "Order-up-to rule", "Original rule": "Original rule", "Random (masked)": "Random", "Q-learning (tabular, two agents)": "Q-learning", "PPO (single agent)": "PPO", "MAPPO (ours)": "MAPPO", "DQN": "DQN", "Double DQN": "Double DQN"}
GTH, K, SEEN = 7500.0, 2, "Seen: normal shop"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.alpha": 0.25, "figure.dpi": 100, "savefig.dpi": 200})
rd = lambda n: pd.read_csv(os.path.join(HERE, n)) if os.path.exists(os.path.join(HERE, n)) else None
cur, fin, eps, comp, abl = rd("perf_curves.csv"), rd("perf_final.csv"), rd("perf_episodes.csv"), rd("perf_compute.csv"), rd("perf_ablation.csv")
S = {}; seeded = lambda df: df[df.seed.astype(str) != "-"]
methods = [m for m in ORDER if cur is not None and m in set(cur.method)]
rule_val = {r: float(fin[(fin.method == r) & (fin.scenario == SEEN)].ret.iloc[0]) for r in RULES if fin is not None and ((fin.method == r) & (fin.scenario == SEEN)).any()}

# ------------------------------------------------ 1 learning curves (mean evaluation return, +-1 sd over seeds)
c = seeded(cur); fig, ax = plt.subplots(figsize=(8.2, 4.6))
for m in methods:
    g = c[c.method == m].groupby("steps").eval_return.agg(["mean", "std"]).fillna(0); x = g.index.values / 1000
    ax.plot(x, g["mean"], color=COL[m], lw=2.2, marker="o", ms=3.5, label=m); ax.fill_between(x, g["mean"] - g["std"], g["mean"] + g["std"], color=COL[m], alpha=0.14)
for r, ls in (("Tuned (s,S) rule", "--"), ("Tuned order-up-to rule", "-."), ("Random (masked)", ":")):
    if r in rule_val: ax.axhline(rule_val[r], color=COL[r], ls=ls, lw=1.4, label=r + " (no learning)")
ax.axhline(GTH, color="#B60345", ls=":", lw=1, alpha=0.6); ax.text(1, GTH - 650, f"convergence threshold Rs {GTH:,.0f}", fontsize=8, color="#B60345"); ax.set_ylim(-1500, 9700); ax.set_xscale("symlog", linthresh=10); ax.set_xlim(0, 125)
ax.set_xticks([0, 2, 5, 10, 20, 50, 100]); ax.set_xticklabels(["0", "2", "5", "10", "20", "50", "100"]); ax.set_xlabel("Environment steps (thousands; log scale beyond 10)"); ax.set_ylabel("Mean evaluation return (designed reward, Rs per episode)"); ax.set_title("Learning curves: mean over 5 seeds, band = 1 standard deviation", fontsize=11)
ax.legend(fontsize=8, ncol=2, loc="lower right"); fig.tight_layout(); fig.savefig(f"{FIG}/learning_curve.png"); plt.close(fig)

# ------------------------------------------------ 2 convergence speed and sample efficiency
rows = []
for m in methods:
    reach, auc, early = [], [], []
    for sd, g in c[c.method == m].groupby("seed"):
        g = g.sort_values("steps"); v = g.eval_return.values; st = g.steps.values; ok = [i for i in range(len(v) - K + 1) if all(v[i:i + K] >= GTH)]
        reach.append(st[ok[0]] if ok else np.nan); auc.append(float(np.trapezoid(v, st) / (st[-1] - st[0]))); early.append(float(np.interp(0.25 * st[-1], st, v)))
    rows.append(dict(method=m, steps_to_threshold=float(np.nanmean(reach)) if not np.all(np.isnan(reach)) else None, seeds_reaching=int(np.sum(~np.isnan(reach))), n_seeds=len(reach), auc=float(np.mean(auc)), return_at_25pct=float(np.mean(early))))
S["convergence"] = rows
fig, ax = plt.subplots(figsize=(6.4, 3.6)); vals = [r["steps_to_threshold"] / 1000 if r["steps_to_threshold"] is not None else 0 for r in rows]
ax.bar([r["method"].split(" (")[0] for r in rows], vals, color=[COL[r["method"]] for r in rows])
for i, r in enumerate(rows): ax.text(i, vals[i] + 2, "not reached" if r["steps_to_threshold"] is None else f'{vals[i]:.0f}k\n({r["seeds_reaching"]}/{r["n_seeds"]} seeds)', ha="center", fontsize=8)
ax.set_ylabel("Steps to reach the threshold (thousands)"); ax.set_title(f"Convergence speed: Rs {GTH:,.0f} for {K} evaluations in a row", fontsize=10); ax.set_ylim(0, max(vals + [1]) * 1.3 + 5)
fig.tight_layout(); fig.savefig(f"{FIG}/convergence.png"); plt.close(fig)

# ------------------------------------------------ 3 final performance table (seen shop) and success rate with a 95% interval
sf = seeded(fin[fin.scenario == SEEN]); tab = []
for m in methods:
    g = sf[sf.method == m]; p = float(g.success.mean()); n = len(g) * 100; ci = 1.96 * np.sqrt(max(p * (1 - p), 1e-9) / n)
    tab.append(dict(method=m, mean=float(g.ret.mean()), sd=float(g.ret.std(ddof=1)) if len(g) > 1 else 0.0, median=float(g.ret.median()), profit=float(g.profit.mean()), success=p, success_ci=float(ci), fill=float(g.fill_rate.mean()), waste=float(g.waste_rate.mean()),
                    wasted=float(g.wasted.mean()), unmet=float(g.unmet.mean()), cv=float(g.ret.std(ddof=1) / g.ret.mean()) if len(g) > 1 else 0.0, below_cost=float(g.below_cost_days.mean()), overflow=float(g.overflow_days.mean())))
for r in RULES:
    g = fin[(fin.method == r) & (fin.scenario == SEEN)]
    if len(g): g = g.iloc[0]; tab.append(dict(method=r, mean=float(g.ret), sd=0.0, median=float(g.ret), profit=float(g.profit), success=float(g.success), success_ci=0.0, fill=float(g.fill_rate), waste=float(g.waste_rate), wasted=float(g.wasted), unmet=float(g.unmet), cv=0.0, below_cost=float(g.below_cost_days), overflow=float(g.overflow_days)))
S["final"] = tab

# ------------------------------------------------ 4 cumulative regret against the best known rule (tuned (s,S)), same test episodes
reg = {}
if eps is not None and "Tuned (s,S) rule" in set(eps.method):
    ref = eps[eps.method == "Tuned (s,S) rule"].set_index("episode").ret
    fig, ax = plt.subplots(figsize=(6.6, 3.9))
    for m in methods:
        per = [np.cumsum((ref - g.set_index("episode").ret).sort_index().values) for _, g in eps[eps.method == m].groupby("seed")]
        mu = np.mean(per, axis=0); reg[m] = float(mu[-1]); ax.plot(range(1, len(mu) + 1), mu, color=COL[m], lw=2, label=f"{m.split(' (')[0]}  ({mu[-1]:,.0f})")
    ax.axhline(0, color="#333333", ls="--", lw=1.4, label="Tuned (s,S) rule = reference (0)"); ax.set_xlabel("Evaluation episode"); ax.set_ylabel("Cumulative regret (Rs)"); ax.set_title("Cumulative regret against the best known rule (lower is better)", fontsize=10)
    ax.legend(fontsize=8); fig.tight_layout(); fig.savefig(f"{FIG}/regret.png"); plt.close(fig)
S["regret"] = reg

# ------------------------------------------------ 5 generalization gap and robustness
unseen = [s for s in sorted(set(fin.scenario)) if s.startswith("Unseen")]; noisy = [s for s in set(fin.scenario) if s.startswith("Noisy")]
gen = []
for m in methods + RULES:
    g = fin[fin.method == m]
    if not len(g): continue
    seen = float(g[g.scenario == SEEN].ret.mean()); row = dict(method=m, seen=seen, unseen=float(g[g.scenario.isin(unseen)].groupby("scenario").ret.mean().mean()))
    for s_ in unseen + noisy: row[s_] = float(g[g.scenario == s_].ret.mean())
    row["gap"] = row["seen"] - row["unseen"]; gen.append(row)
S["generalization"] = gen; S["scenarios"] = unseen + noisy
fig, ax = plt.subplots(figsize=(8.6, 4.2)); names = [SHORT.get(r["method"], r["method"]) for r in gen]; xs = np.arange(len(gen)); w = 0.38
ax.bar(xs - w / 2, [r["seen"] for r in gen], w, color="#1f77b4", label="Seen: normal shop"); ax.bar(xs + w / 2, [r["unseen"] for r in gen], w, color="#ff7f0e", label="Unseen: mean of 4 shifted shops")
for i, r in enumerate(gen): ax.text(i, max(r["seen"], r["unseen"]) + 250, f"{r['gap']:,.0f}", ha="center", fontsize=8, color="#333333")
ax.set_xticks(xs); ax.set_xticklabels(names, rotation=18, ha="right", fontsize=8); ax.set_ylabel("Mean return (designed reward, Rs per episode)"); ax.set_title("Generalization gap = seen minus unseen (number above bars; smaller is better)", fontsize=10); ax.set_ylim(top=max(max(r["seen"], r["unseen"]) for r in gen) * 1.18); ax.legend(fontsize=8)
fig.tight_layout(); fig.savefig(f"{FIG}/generalization.png"); plt.close(fig)

# ------------------------------------------------ 6 compute
if comp is not None:
    cc = comp.assign(seed=comp.seed.astype(str)).groupby("method").agg(train_seconds=("train_seconds", "mean"), inference_ms=("inference_ms", "mean"), parameters=("parameters", "mean")).reset_index(); S["compute"] = cc.to_dict("records")

# ------------------------------------------------ 7 ablation
if abl is not None:
    sc = {"Seen: normal shop": "Normal shop", "Unseen: quiet shop (7 a day)": "Quiet shop", "Unseen: 2-day shelf life": "2-day shelf life"}
    a = abl[abl.scenario.isin(sc)].copy(); a["sc"] = a.scenario.map(sc); g = a.groupby(["method", "sc"]).agg(ret=("ret", "mean"), sd=("ret", "std"), profit=("profit", "mean"), unmet=("unmet", "mean"), below=("below_cost_days", "mean"), over=("overflow_days", "mean"), n=("seed", "nunique")).reset_index()
    S["ablation"] = g.to_dict("records")
    LAB = [("MAPPO (ours)", "MAPPO (ours)"), ("No role-specific rewards (shared team reward)", "Shared team reward"), ("Pricing critic sees its own action (earlier design)", "Critic sees own action"), ("No safety action masks", "No safety masks"), ("Basic inputs only (no smoothed demand, no units expiring)", "Basic inputs only"), ("Default entropy bonus 0.01 (no tuning)", "Entropy 0.01 (untuned)")]
    LAB = [(k, v) for k, v in LAB if k in set(g.method)]; fig, ax = plt.subplots(figsize=(8.4, 4.2)); w = 0.8 / 3
    for k, sname in enumerate(("Normal shop", "Quiet shop", "2-day shelf life")):
        d = g[g.sc == sname].set_index("method").reindex([a_ for a_, _ in LAB]); ax.bar(np.arange(len(LAB)) + (k - 1) * w, d.ret, w, yerr=d.sd.fillna(0), capsize=2, label=sname)
    ax.set_xticks(range(len(LAB))); ax.set_xticklabels([b_.replace(" ", "\n", 1) if len(b_) > 14 else b_ for _, b_ in LAB], fontsize=8.5); ax.axhline(0, color="#333333", lw=0.8); ax.set_ylabel("Mean return (designed reward, Rs per episode)")
    ax.set_title("Ablation: one component removed at a time (mean over 3 seeds, bar = 1 sd)", fontsize=10.5); ax.legend(fontsize=8.5); fig.tight_layout(); fig.savefig(f"{FIG}/ablation.png"); plt.close(fig)
json.dump(S, open(os.path.join(HERE, "perf_summary.json"), "w"), indent=1, default=float); print("figures:", sorted(os.listdir(FIG)), "| summary keys:", list(S))
