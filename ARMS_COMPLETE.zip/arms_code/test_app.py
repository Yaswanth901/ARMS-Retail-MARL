"""Runs the whole app (app.py) against a stand-in for Streamlit and reports any error. No browser needed.
   python test_app.py            checks every tab with default settings
   python test_app.py --buttons  also presses every button except the slow retraining ones"""
import sys, types, runpy, time, contextlib
PRESS = "--buttons" in sys.argv
LOG = []

class Fake:
    def __init__(self, name="st"): self._name = name
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def __getattr__(self, n):
        if n.startswith("__"): raise AttributeError(n)
        def f(*a, **k): LOG.append((n, str(a[0])[:60] if a else "")); return Fake(n)
        return f
    def slider(self, label, *a, **k):
        if "value" in k: return k["value"]
        return a[2] if len(a) >= 3 else (a[0] if a else 0)
    number_input = slider
    def checkbox(self, label, value=False, **k): return value
    def selectbox(self, label, options, index=0, **k): return list(options)[index]
    def radio(self, label, options, **k): return list(options)[0]
    def button(self, label, **k): return PRESS and not ("Retrain" in label or "Train agents" in label)
    def columns(self, n, **k): return [Fake() for _ in range(n if isinstance(n, int) else len(n))]
    def tabs(self, names): LOG.append(("tabs", len(names))); return [Fake() for _ in names]
    def expander(self, *a, **k): return Fake()
    def spinner(self, *a, **k): return Fake()
    def cache_resource(self, f=None, **k): return f if f else (lambda g: g)
    def error(self, msg, *a, **k): LOG.append(("ERROR", str(msg)[:200])); return Fake()
    def stop(self): raise SystemExit("st.stop() called")

class State(dict):
    def __getattr__(self, k): return self.get(k)
st = Fake(); st.sidebar = Fake("sidebar"); st.session_state = State()
mod = types.ModuleType("streamlit"); mod.__dict__.update({k: getattr(st, k) for k in dir(Fake) if not k.startswith("_")})
mod.sidebar, mod.session_state = st.sidebar, st.session_state
for n in ("set_page_config", "markdown", "title", "caption", "warning", "info", "success", "write", "dataframe", "line_chart", "bar_chart", "metric", "progress", "subheader", "header", "download_button"):
    setattr(mod, n, (lambda nm: (lambda *a, **k: LOG.append((nm, str(a[0])[:60] if a else "")) or Fake()))(n))
sys.modules["streamlit"] = mod
t0 = time.time(); err = None
try: runpy.run_path("app.py", run_name="__main__")
except SystemExit as e: err = f"stopped: {e}"
except Exception as e: err = f"{type(e).__name__}: {e}"
errors = [c for c in LOG if c[0] == "ERROR"]
print(f"app run {'with buttons pressed' if PRESS else 'with defaults'}: {len(LOG)} screen calls in {time.time()-t0:.0f}s | exception: {err or 'none'} | page errors: {errors or 'none'}")
print("tables shown:", sum(1 for c in LOG if c[0] == "dataframe"), "| charts:", sum(1 for c in LOG if "chart" in c[0]), "| metrics:", sum(1 for c in LOG if c[0] == "metric"))
sys.exit(1 if (err or errors) else 0)
