import os
BASE = os.path.dirname(os.path.abspath(__file__))  # save/load next to this script, works on any OS
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

rule = pd.read_csv(os.path.join(BASE, "results_rule_based.csv"))
single = pd.read_csv(os.path.join(BASE, "results_single_agent.csv"))
two = pd.read_csv(os.path.join(BASE, "results_two_agent.csv"))

def smooth(x, w=30):
    return pd.Series(x).rolling(w, min_periods=1).mean()

# ---------------------------------------------------------------- Figure 1: learning curves
fig, axes = plt.subplots(1, 3, figsize=(15, 4.2))

axes[0].plot(smooth(single['total_reward']), label='Single-Agent Q-learning', color='#6C8EBF')
axes[0].plot(smooth(two['total_reward']), label='Two-Agent MARL (ours)', color='#B85450')
axes[0].axhline(rule['total_reward'].mean(), color='#82B366', linestyle='--', label='Rule-based (no learning)')
axes[0].set_title('Total reward per episode (30-ep rolling avg)')
axes[0].set_xlabel('Episode'); axes[0].set_ylabel('Total reward (Rs)')
axes[0].legend(fontsize=8)

axes[1].plot(smooth(single['stockout']), label='Single-Agent', color='#6C8EBF')
axes[1].plot(smooth(two['stockout']), label='Two-Agent MARL (ours)', color='#B85450')
axes[1].axhline(rule['stockout'].mean(), color='#82B366', linestyle='--', label='Rule-based')
axes[1].set_title('Stock-out units per episode')
axes[1].set_xlabel('Episode'); axes[1].set_ylabel('Units')
axes[1].legend(fontsize=8)

axes[2].plot(smooth(single['wastage']), label='Single-Agent', color='#6C8EBF')
axes[2].plot(smooth(two['wastage']), label='Two-Agent MARL (ours)', color='#B85450')
axes[2].axhline(rule['wastage'].mean(), color='#82B366', linestyle='--', label='Rule-based')
axes[2].set_title('Wastage (expired units) per episode')
axes[2].set_xlabel('Episode'); axes[2].set_ylabel('Units')
axes[2].legend(fontsize=8)

plt.tight_layout()
plt.savefig(os.path.join(BASE, "learning_curves.png"), dpi=200, facecolor='white')
plt.close()

# ---------------------------------------------------------------- Metrics table (Section 12 format)
def summarize(df, n_tail=100):
    d = df.tail(n_tail)
    return {
        'Cumulative reward / simulated profit': f"{d['total_reward'].mean():,.0f}",
        'Wastage rate (units/episode)': f"{d['wastage'].mean():.2f}",
        'Stock-out rate (units/episode)': f"{d['stockout'].mean():.2f}",
        'Fill rate / service level': f"{d['fill_rate'].mean()*100:.1f}%",
        'Average inventory (units/day)': f"{d['avg_inventory'].mean():.1f}",
    }

table = pd.DataFrame({
    'Rule-based control': summarize(rule, n_tail=200),
    'Single-Agent RL (Q-learning)': summarize(single, n_tail=100),
    'Two-Agent MARL (ours)': summarize(two, n_tail=100),
})
table.to_csv(os.path.join(BASE, "metrics_summary.csv"))
print(table.to_string())

# ---------------------------------------------------------------- % improvement, two-agent vs single-agent
s_tail, t_tail = single.tail(100), two.tail(100)
print("\nTwo-agent vs single-agent (last 100 episodes):")
print(f"  Reward:   {(t_tail['total_reward'].mean()/s_tail['total_reward'].mean()-1)*100:+.1f}%")
print(f"  Stockout: {(t_tail['stockout'].mean()/s_tail['stockout'].mean()-1)*100:+.1f}%")
print(f"  Wastage:  {(t_tail['wastage'].mean()/s_tail['wastage'].mean()-1)*100:+.1f}%")
