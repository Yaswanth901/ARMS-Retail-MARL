"""MULTI-AGENT METRICS (madam's list): individual reward, coordination, role utilization, communication cost, cross-play / new-team generalization.
Trains 5 MAPPO teams (same seeds and budget as the comparison suite), then:
  individual reward  : each agent's own episodic reward and the team total
  cross-play         : pricing actor of team i with inventory actor of team j (independently trained teammates)
  coordination       : team vs inventory agent blind to the price vs pricing forced to regular
  role utilization   : discount days, order days, share of full (25) and half (10) orders
Writes ma_metrics.json and figures/crossplay.png.   python multiagent_metrics.py   (about 4 minutes)"""
import json, os, numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
import sys, mappo_numpy as M, mappo_v3 as W, baselines_rl as B, retail_env_v2 as V
from retail_env_v3 import RetailEnvV3, FINE_LEVELS
QUIET = len(sys.argv) > 1 and sys.argv[1] == "quiet"
KW = {"levels": FINE_LEVELS, "elasticity": 2.0, "base_demand": 7.0} if QUIET else {}
FEAT = "age" if QUIET else "extras"
HERE = os.path.dirname(os.path.abspath(__file__)); N, EP = 5, 40
def compose(ap, ai, blind=False, force_regular=False):
    def f(s):
        x = np.array(ap.f(s))[None]; pp = M.masked_probs(ap.actor_p.forward(x)[0], W.price_mask(s, ap.levels))[0]; a_p = 0 if force_regular else int(np.argmax(pp))
        seen = 0 if blind else a_p; xi = np.concatenate([np.array(ai.f(s)), np.eye(ai.nP)[seen]])[None]
        a_i = int(np.argmax(M.masked_probs(ai.actor_i.forward(xi)[0], M.inv_mask(s))[0])); return a_p, a_i
    return f
def run(policy, n=EP, seed0=900000):
    rows = []
    for k in range(n):
        env = RetailEnvV3(60, seed=seed0 + k, **KW); s = env.reset(); rp = ri = 0.0; um = disc = orders = full = half = 0
        for _ in range(60):
            p, i = policy(s); s, _, _, info = env.step(p, i); rp += info["r_price"]; ri += info["r_inventory"]; um += info["stockout"]; disc += int(p > 0); orders += int(i > 0); full += int(i == 2); half += int(i == 1)
        rows.append((rp, ri, rp + ri, disc, orders, full, half))
    return np.mean(rows, axis=0)
teams = []
for sd in range(N): teams.append(W.train(seed=800 + sd, iterations=120, feat=FEAT, env_kw=KW)[0] if QUIET else B.train_mappo(sd, 1920, 1920, lambda p: 0.0)[0]); print("trained team", sd, flush=True)
self_play = [run(compose(t, t)) for t in teams]
indiv = dict(pricing_reward=float(np.mean([r[0] for r in self_play])), inventory_reward=float(np.mean([r[1] for r in self_play])), team_return=float(np.mean([r[2] for r in self_play])), team_sd=float(np.std([r[2] for r in self_play], ddof=1)))
cross = np.zeros((N, N))
for i in range(N):
    for j in range(N): cross[i, j] = self_play[i][2] if i == j else run(compose(teams[i], teams[j]))[2]
off = cross[~np.eye(N, dtype=bool)]
coord = dict(team=float(np.mean([r[2] for r in self_play])), inventory_blind_to_price=float(np.mean([run(compose(t, t, blind=True))[2] for t in teams])), pricing_forced_regular=float(np.mean([run(compose(t, t, force_regular=True))[2] for t in teams])))
roles = dict(discount_days=float(np.mean([r[3] for r in self_play])), order_days=float(np.mean([r[4] for r in self_play])), full_orders=float(np.mean([r[5] for r in self_play])), half_orders=float(np.mean([r[6] for r in self_play])))
out = dict(individual=indiv, crossplay=dict(matrix=cross.tolist(), self_play=float(np.mean(np.diag(cross))), cross_play=float(off.mean()), worst=float(off.min()), drop_pct=float((np.mean(np.diag(cross)) - off.mean()) / abs(np.mean(np.diag(cross))) * 100)), coordination=coord, roles=roles,
           communication="one categorical message per day (the chosen price tier, 3 options); no other communication")
json.dump(out, open(os.path.join(HERE, "ma_metrics_quiet.json" if QUIET else "ma_metrics.json"), "w"), indent=1)
fig, ax = plt.subplots(figsize=(4.6, 3.9)); im = ax.imshow(cross, cmap="RdYlGn", vmin=cross.min() - 100, vmax=cross.max() + 20)
for i in range(N):
    for j in range(N): ax.text(j, i, f"{cross[i, j]:,.0f}", ha="center", va="center", fontsize=8)
ax.set_xticks(range(N)); ax.set_yticks(range(N)); ax.set_xticklabels([f"inv {j}" for j in range(N)], fontsize=8); ax.set_yticklabels([f"price {i}" for i in range(N)], fontsize=8)
ax.set_title("Cross-play: pricing agent of team i with inventory agent of team j\n(return; diagonal = own teammate)", fontsize=8.5); fig.tight_layout(); fig.savefig(os.path.join(HERE, "figures", "crossplay_quiet.png" if QUIET else "crossplay.png"), dpi=200)
print(json.dumps(out, indent=1)[:1500])
