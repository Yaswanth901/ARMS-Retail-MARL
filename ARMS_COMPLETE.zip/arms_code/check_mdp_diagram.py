"""Checks every field drawn in the MDP diagrams against the CODE, and tests the MDP rules (reward formula, Markov property of the observation).
   python check_mdp_diagram.py"""
import copy, numpy as np
import retail_env_v2 as V, retail_env_v3 as E3, mappo_v3 as W, mappo_numpy as M
OK = []
def chk(name, cond, detail=""): OK.append(bool(cond)); print(f"[{'PASS' if cond else 'FAIL'}] {name}" + (f"   ({detail})" if detail else ""))
print("A. FIELDS IN THE DIAGRAM EQUAL THE CODE\n")
chk("unit cost 35, price 50", V.UNIT_COST == 35 and V.BASE_PRICE == 50)
chk("shelf life 4 days, shelf capacity 45 units", V.SHELF_LIFE_DAYS == 4 and V.MAX_STOCK == 45)
chk("price tiers: regular, 15% off, 35% off", [round(V.PRICE_MULTIPLIER[a], 2) for a in V.PRICE_ACTIONS] == [1.0, 0.85, 0.65], str([V.PRICE_MULTIPLIER[a] for a in V.PRICE_ACTIONS]))
chk("reorder sizes 0, 10, 25", [V.REORDER_QTY[a] for a in V.INV_ACTIONS] == [0, 10, 25])
chk("demand lift 1.00 / 1.15 / 1.30; base demand 12; weekend factor 1.15", [V.DEMAND_LIFT[a] for a in V.PRICE_ACTIONS] == [1.0, 1.15, 1.3] and V.BASE_DEMAND == 12 and V.WEEKDAY_MULT[5] == V.WEEKDAY_MULT[6] == 1.15 and V.WEEKDAY_MULT[:5] == [1.0] * 5)
chk("holding 0.6, order cost 40, unmet penalty 20", V.HOLD_COST == 0.6 and V.ORDER_FIXED == 40 and V.LAMBDA_S == 20)
chk("episode length 60 days", W.HORIZON == 60)
e = E3.RetailEnvV3(60, seed=1); s0 = e.reset()
chk("initial state: 20 units, all with 4 days left, day 0 is Monday", s0["stock"] == 20 and s0["days_to_expiry"] == 4 and s0["weekday"] == 0 and s0["seasonality"] == 1.0)
chk("observation has 6 numbers (stock, days to expiry, weekday effect, last demand, smoothed demand, units expiring)", len(W.f_extras(s0)) == 6 and W.FEATURES["extras"][1] == 6)
chk("discount: MAPPO 0.97, tabular Q-learning 0.95", abs(W.MAPPOv3(0).gamma - 0.97) < 1e-12 and abs(__import__("agents").TwoAgentQLearner().gamma - 0.95) < 1e-12)
chk("reward scale 1/100 for training", W.REWARD_SCALE == 0.01)
st = dict(s0, days_to_expiry=3); pm = W.price_mask(st, E3.LEGACY_LEVELS); pm1 = W.price_mask(dict(st, days_to_expiry=1), E3.LEGACY_LEVELS)
chk("mask: 35% off (below cost) only when <= 1 day is left", pm.tolist() == [1, 1, 0] and pm1.tolist() == [1, 1, 1], f"{pm.tolist()} and {pm1.tolist()}")
im = M.inv_mask(dict(s0, stock=30)).tolist(); chk("mask: a 25-unit order is not allowed when it would overfill the 45-unit shelf", im == [1.0, 1.0, 0.0], str(im))
print("\nB. THE MDP RULES\n")
rng = np.random.default_rng(0); worst = 0.0; e = E3.RetailEnvV3(60, seed=7); e.reset()
for _ in range(60):
    p, i = int(rng.integers(3)), int(rng.integers(3)); _, (rp, ri), _, info = e.step(p, i); qty = V.REORDER_QTY[V.INV_ACTIONS[i]]
    exp_p = info["units_sold"] * (info["price"] - V.UNIT_COST) - V.UNIT_COST * info["wastage"]; exp_i = -(V.HOLD_COST * info["stock_after"] + (V.ORDER_FIXED if qty > 0 else 0) + V.LAMBDA_S * info["stockout"])
    worst = max(worst, abs(exp_p - rp), abs(exp_i - ri))
chk("reward formulas r_p and r_i in the diagram equal the simulator's rewards on a random 60-day episode", worst < 1e-9, f"largest difference {worst:.1e}")
chk("team reward r_p + r_i = profit - 20 x unmet (so the two-agent game is cooperative with a single team objective)", abs((rp + ri) - (info["profit"] - V.LAMBDA_S * info["stockout"])) < 1e-9)
e1 = E3.RetailEnvV3(60, seed=3); e1.reset(); e2 = E3.RetailEnvV3(60, seed=3); e2.reset(); e1.day, e2.day = 4, 0       # Friday and Monday: same weekday effect today (1.0)
o1, o2 = e1._state(), e2._state(); same = all(o1[k] == o2[k] for k in ("stock", "days_to_expiry", "seasonality", "recent_demand", "demand_ema", "expiring"))
n1, n2 = e1.step(0, 0)[0], e2.step(0, 0)[0]
print(f"[INFO] two situations with the SAME 6-number observation (Friday and Monday) have different next weekday effects: {n1['seasonality']} vs {n2['seasonality']}")
chk("the 6-number observation is NOT fully Markov (the weekday is hidden), so it must be described as an approximation", same and n1["seasonality"] != n2["seasonality"])
chk("adding the weekday (13 numbers) makes tomorrow's weekday effect a function of the observation", W.FEATURES["markov"][1] == 13 and "weekday" in s0)
print(f"\nSUMMARY: {sum(OK)} of {len(OK)} checks passed")
