"""
Retail environment v3: the v2 store plus four realism options (all OFF by default, so v3 reproduces v2 exactly):
  - stock by age   : the state lists how many units have 1, 2, 3, 4, 5 days left ("age")
  - supplier delay : an order may arrive 0, 1 or 2 extra days late (probabilities in `delay`); the state shows units on order
  - price response : demand = base x price_multiplier ** (-elasticity); the elasticity can be MEASURED (estimate_price_response.py)
  - finer discounts: any list of discount levels, e.g. 0%, 10%, 20%, 30%, 40%
Actions are INDICES: price index into `levels`, inventory index 0/1/2 = order 0 / 10 / 25 units.
All money numbers are the v2 assumptions (retail_env_v2.py).
"""
import numpy as np
import retail_env_v2 as V

NO_DELAY = (1.0, 0.0, 0.0)
LEGACY_LEVELS, LEGACY_LIFTS = (0.0, 0.15, 0.35), (1.0, 1.15, 1.3)
FINE_LEVELS = (0.0, 0.10, 0.20, 0.30, 0.40)
AGE_BINS = 5


class RetailEnvV3:
    def __init__(self, horizon=60, seed=None, levels=LEGACY_LEVELS, lifts=LEGACY_LIFTS, elasticity=None,
                 delay=NO_DELAY, shelf=None, base_demand=None, rng=None):
        self.horizon = horizon
        self.rng = rng if rng is not None else np.random.default_rng(seed)
        self.levels = tuple(levels); self.mult = [1.0 - l for l in self.levels]
        self.lifts, self.elasticity, self.delay = lifts, elasticity, tuple(delay)
        self.shelf = V.SHELF_LIFE_DAYS if shelf is None else shelf
        self.base = V.BASE_DEMAND if base_demand is None else base_demand
        self.reset()

    def reset(self):
        self.day = 0
        self.batches = [[20, self.shelf]]          # [units, days left]
        self.pipeline = []                          # [days until delivery, units]
        self.history = []
        self.ema = self.base
        return self._state()

    def lift(self, j):
        return self.lifts[j] if self.elasticity is None else self.mult[j] ** (-self.elasticity)

    def _stock(self):
        return sum(b[0] for b in self.batches)

    def _state(self):
        age = [0] * AGE_BINS
        for u, d in self.batches:
            if 1 <= d <= AGE_BINS: age[d - 1] += u
        return {"stock": self._stock(), "days_to_expiry": min((b[1] for b in self.batches), default=self.shelf),
                "recent_demand": self.history[-1]["demand"] if self.history else self.base,
                "seasonality": V.WEEKDAY_MULT[self.day % 7], "weekday": self.day % 7, "demand_ema": self.ema,
                "expiring": sum(u for u, d in self.batches if d <= 1), "age": age,
                "on_order": sum(q for _, q in self.pipeline)}

    def step(self, p_idx, i_idx):
        expected = self.base * self.lift(p_idx) * V.WEEKDAY_MULT[self.day % 7]
        demand = max(0, self.rng.poisson(expected))
        self.ema = 0.7 * self.ema + 0.3 * demand
        sold, remaining = 0, demand
        for b in self.batches:                      # oldest stock sold first
            if remaining <= 0: break
            take = min(b[0], remaining); b[0] -= take; sold += take; remaining -= take
        stockout = max(0, demand - sold)
        price = V.BASE_PRICE * self.mult[p_idx]
        wastage, kept = 0, []
        for b in self.batches:                      # age the stock, throw away expired units
            b[1] -= 1
            if b[1] <= 0: wastage += b[0]
            elif b[0] > 0: kept.append(b)
        self.batches = kept
        still = []
        for t, q in self.pipeline:                  # late deliveries arrive
            t -= 1
            if t <= 0: self.batches.append([q, self.shelf])
            else: still.append([t, q])
        self.pipeline = still
        qty = V.REORDER_QTY[V.INV_ACTIONS[i_idx]]
        if qty > 0:
            d = 0 if self.delay == NO_DELAY else int(self.rng.choice(3, p=self.delay))
            if d == 0: self.batches.append([qty, self.shelf])
            else: self.pipeline.append([d, qty])
        stock_after = self._stock()
        r_price = sold * (price - V.UNIT_COST) - V.UNIT_COST * wastage
        r_inv = -V.HOLD_COST * stock_after - (V.ORDER_FIXED if qty > 0 else 0.0) - V.LAMBDA_S * stockout
        info = {"day": self.day, "demand": demand, "units_sold": sold, "price": price, "p_idx": p_idx, "wastage": wastage,
                "stockout": stockout, "stock_after": stock_after, "on_order": sum(q for _, q in self.pipeline),
                "profit": r_price + r_inv + V.LAMBDA_S * stockout, "r_price": r_price, "r_inventory": r_inv}
        self.history.append(info); self.day += 1
        return self._state(), (r_price, r_inv), self.day >= self.horizon, info
