"""Reproduces the results table shown on the Demo slide: 5 methods on the same 100 fresh simulated 60-day episodes.
Run:  python demo_table.py        (takes about 1 minute)
Each method is evaluated greedily (no exploration) with train_v2.evaluate; the rule rows use no learning."""
import numpy as np, pandas as pd
import app_core as C, train_v2 as T, mappo_numpy as M
from tune_sS import make_sS

ag = C.load_agents()                                   # saved Q-learning agents (trained_v2_agents.json)
g = pd.read_csv("tuned_sS_grid.csv").iloc[0]           # best (s,S) setting found by the grid search
methods = [
    ("Original rule (hand-set)",              T.rule_policy,                                   False),
    ("Q-learning, two agents + guardrails",   T.greedy_policy(ag["two_g"]),                    True),
    ("Tuned order-up-to rule (grid search)",  lambda s: C.TUNED_RULE(s),                       False),
    ("MAPPO (saved agent, seed 6)",           M.MAPPO.load("mappo_weights/seed6.npz", 6).policy(), False),
    ("Tuned (s,S) rule (grid search)",        make_sS(int(g.s), g.order, int(g.mod_exp)),      False),
]
print(f"{'Method':40s} {'Profit':>8s} {'Wasted':>8s} {'Unmet':>8s}")
for name, pol, guard in methods:
    d = T.evaluate(pol, guard=guard)
    print(f"{name:40s} {d['profit'].mean():8.0f} {d['wastage'].mean():8.1f} {d['stockout'].mean():8.1f}")
mp = pd.read_csv("mappo_results_all.csv")
print(f"\nMAPPO mean over {len(mp)} training seeds: {mp.profit.mean():.0f}   (file: mappo_results_all.csv)")
