"""
Shared logic for the Streamlit app (app.py) and the PowerShell demo (demo_cli.py).
Everything the screen shows comes from the real RL code in this folder - nothing is mocked.

Fair comparison: all methods are replayed against the SAME random numbers ("common random
numbers"), so differences between methods are due to the decisions, not to lucky demand.
"""
import os
BASE = os.path.dirname(os.path.abspath(__file__))
import json
from contextlib import contextmanager
import numpy as np
import pandas as pd
from scipy.stats import poisson

import retail_env_v2 as E
from retail_env_v2 import RetailEnvV2, PRICE_ACTIONS, INV_ACTIONS
from agents import SingleAgentQLearner, TwoAgentQLearner, rule_based_policy
from guardrails import apply_guardrails, greedy_with_fallback, CONFIDENCE_GAP
from agents import discretize
import train_v2 as T
from tune_baseline import make_policy as _make_rule
from tune_sS import make_sS as _make_sS

AGENT_FILE = os.path.join(BASE, "trained_v2_agents.json")
PROFILE_FILE = os.path.join(BASE, "demand_profile.json")   # written by calibrate_favorita.py

METHODS = ["Rule-based", "Single-Agent RL", "Two-Agent RL",
           "Two-Agent RL + guardrails", "Two-Agent RL + guardrails + fallback",
           "Tuned order-up-to rule (no learning)", "Tuned (s,S) rule (no learning)", "MAPPO (neural policy)"]
METHOD_KEYS = {"rule": METHODS[0], "single": METHODS[1], "two": METHODS[2],
               "guarded": METHODS[3], "fallback": METHODS[4], "tuned": METHODS[5], "ss": METHODS[6], "mappo": METHODS[7]}
# Best setting found by tune_baseline.py (grid search on tuning seeds): order up to 42 units,
# no clearance tier, moderate discount only when 1 day is left.
TUNED_RULE = _make_rule(42, 0, 5, 1)
# Best (s,S)-type rule found by tune_sS.py: order a full batch (25) when stock <= 26; no discounting except never.
SS_RULE = _make_sS(26, "FULL_REORDER", 0)

_MAPPO = {}


def get_mappo(seed=6):
    """MAPPO agent trained by mappo_numpy.py (seed 6 = the median-performing of the 10 saved seeds)."""
    if seed not in _MAPPO:
        import mappo_numpy as MN
        path = os.path.join(BASE, "mappo_weights", f"seed{seed}.npz")
        _MAPPO[seed] = MN.MAPPO.load(path, seed) if os.path.exists(path) else None
    return _MAPPO[seed]
SHORT_PRICE = {"REGULAR_PRICE": "Regular", "MODERATE_DISCOUNT": "Moderate", "CLEARANCE_DISCOUNT": "Clearance"}
SHORT_INV = {"NO_REORDER": "None", "SMALL_REORDER": "Small (10)", "FULL_REORDER": "Full (25)"}


# ------------------------------------------------------------------ scenario + shared demand
def load_profile(path=PROFILE_FILE):
    """Demand profile measured from real data by calibrate_favorita.py (None if not created yet)."""
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as f:
        return json.load(f)


@contextmanager
def scenario(base_demand=None, shelf_life=None, weekday_mult=None):
    """Temporarily change average demand / shelf life / weekly pattern, then restore."""
    old = (E.BASE_DEMAND, E.SHELF_LIFE_DAYS, list(E.WEEKDAY_MULT))
    if base_demand is not None:
        E.BASE_DEMAND = float(base_demand)
    if shelf_life is not None:
        E.SHELF_LIFE_DAYS = int(shelf_life)
    if weekday_mult is not None:
        E.WEEKDAY_MULT = [float(x) for x in weekday_mult]
    try:
        yield
    finally:
        E.BASE_DEMAND, E.SHELF_LIFE_DAYS, E.WEEKDAY_MULT = old[0], old[1], old[2]


class TraceRNG:
    """Replaces the env's random generator so every method sees the same demand randomness.
    Demand on day d = Poisson quantile of a pre-drawn uniform number u_d, with an optional
    demand multiplier (shock) for that day."""

    def __init__(self, uniforms, shocks=None):
        self.u = uniforms
        self.shocks = shocks or {}
        self.i = 0

    def poisson(self, lam):
        mult = self.shocks.get(self.i, 1.0)
        u = float(min(max(self.u[self.i], 1e-9), 1 - 1e-9))
        self.i += 1
        return int(poisson.ppf(u, lam * mult))


def make_shocks(day, length, mult):
    """Shock schedule: demand x mult for `length` days starting at 1-based `day`. day=0 means no shock."""
    if not day:
        return {}
    return {d: float(mult) for d in range(day - 1, day - 1 + length)}


def make_env(horizon, uniforms, shocks=None):
    env = RetailEnvV2(horizon, seed=0)
    env.rng = TraceRNG(uniforms, shocks)
    return env


# ------------------------------------------------------------------ decisions
def _greedy(agent, state):
    old = agent.eps
    agent.eps = 0.0
    out = agent.act(state)
    agent.eps = old
    return out[1]          # (price_action, inventory_action) for both agent types


def decide(method, agents, state, gap=CONFIDENCE_GAP):
    notes = {"guardrail": "", "fallback": False}
    if method == METHODS[0]:
        p, i = rule_based_policy(state)
        return p, i, notes
    if method == METHODS[5]:
        p, i, _ = TUNED_RULE(state)
        return p, i, notes
    if method == METHODS[6]:
        p, i, _ = SS_RULE(state)
        return p, i, notes
    if method == METHODS[7]:
        m = get_mappo()
        if m is None:
            raise FileNotFoundError("mappo_weights/seed6.npz not found. Run: python mappo_numpy.py")
        a_p, a_i = m.act(state, greedy=True)
        return PRICE_ACTIONS[a_p], INV_ACTIONS[a_i], notes
    if method == METHODS[1]:
        p, i = _greedy(agents["single"], state)
        return p, i, notes
    if method == METHODS[2]:
        p, i = _greedy(agents["two"], state)
        return p, i, notes
    if method == METHODS[3]:
        p, i = _greedy(agents["two_g"], state)
    else:
        p, i, fb = greedy_with_fallback(agents["two_g"], state, gap=gap)
        notes["fallback"] = bool(fb)
    p2, i2, fired = apply_guardrails(state, p, i)
    if fired["price_floor"]:
        notes["guardrail"] += f"price raised {SHORT_PRICE[p]}->{SHORT_PRICE[p2]} (below cost); "
    if fired["reorder_cap"]:
        notes["guardrail"] += f"order cut {SHORT_INV[i]}->{SHORT_INV[i2]} (shelf capacity); "
    return p2, i2, notes


def explain(state, p, i, notes):
    """A plain-language reading of the situation and the action. It describes context;
    it is not a look inside the agent's internals."""
    stock, exp = state["stock"], state["days_to_expiry"]
    bits = [f"{stock} in stock, {exp} day(s) to expiry"]
    if p == "REGULAR_PRICE":
        bits.append("no discount")
    elif exp <= 2:
        bits.append("discounting while expiry is close")
    else:
        bits.append("discounting to lift demand")
    if i == "NO_REORDER":
        bits.append("no reorder" + (" (discount should clear stock)" if p != "REGULAR_PRICE" else ""))
    elif stock < 10:
        bits.append("stock is low, reordering")
    else:
        bits.append("reordering to stay covered")
    if notes["fallback"]:
        bits.append("agent unsure, so the rule-based policy decided")
    if notes["guardrail"]:
        bits.append("GUARDRAIL: " + notes["guardrail"].strip("; "))
    return "; ".join(bits)


# ------------------------------------------------------------------ simulation
def run_episode(method, agents, uniforms, horizon, shocks=None, gap=CONFIDENCE_GAP):
    env = make_env(horizon, uniforms, shocks)
    s = env.reset()
    rows = []
    for d in range(horizon):
        p, i, notes = decide(method, agents, s, gap)
        s_next, _, _, info = env.step(p, i)
        rows.append({
            "Day": d + 1, "Stock": s["stock"], "Days to expiry": s["days_to_expiry"],
            "Demand": info["demand"], "Price tier": SHORT_PRICE[p], "Price (Rs)": round(info["price"], 1),
            "Reorder": SHORT_INV[i], "Sold": info["units_sold"], "Wasted": info["wastage"],
            "Unmet": info["stockout"], "Profit (Rs)": round(info["profit"], 1),
            "Guardrail": notes["guardrail"].strip("; "), "Fallback": notes["fallback"],
            "Situation": explain(s, p, i, notes),
        })
        s = s_next
    df = pd.DataFrame(rows)
    df["Cumulative profit"] = df["Profit (Rs)"].cumsum()
    return df


def compare_methods(agents, uniforms, horizon, shocks=None, gap=CONFIDENCE_GAP):
    return {m: run_episode(m, agents, uniforms, horizon, shocks, gap) for m in METHODS}


def totals(results):
    rows = []
    for m, df in results.items():
        rows.append({"Method": m, "Profit (Rs)": round(df["Profit (Rs)"].sum()),
                     "Wasted (units)": int(df["Wasted"].sum()), "Unmet demand (units)": int(df["Unmet"].sum()),
                     "Guardrail fires": int((df["Guardrail"] != "").sum()),
                     "Fallback decisions": int(df["Fallback"].sum())})
    return pd.DataFrame(rows)


def batch_eval(agents, n=30, horizon=60, shocks=None, gap=CONFIDENCE_GAP, seed0=777000):
    rows = []
    for k in range(n):
        uniforms = np.random.default_rng(seed0 + k).random(horizon)
        for m in METHODS:
            df = run_episode(m, agents, uniforms, horizon, shocks, gap)
            rows.append({"episode": k, "Method": m, "profit": df["Profit (Rs)"].sum(),
                         "wasted": df["Wasted"].sum(), "unmet": df["Unmet"].sum()})
    return pd.DataFrame(rows)


def summarize_batch(df):
    piv = df.pivot(index="episode", columns="Method", values="profit")
    out = []
    for m in METHODS:
        sub = df[df["Method"] == m]
        beats = "-" if m == METHODS[0] else f"{(piv[m] > piv[METHODS[0]]).mean() * 100:.0f}%"
        beats_t = "-" if m == METHODS[5] else f"{(piv[m] > piv[METHODS[5]]).mean() * 100:.0f}%"
        out.append({"Method": m, "Mean profit (Rs)": round(sub["profit"].mean()),
                    "Std dev": round(sub["profit"].std(ddof=1)),
                    "Mean wasted": round(sub["wasted"].mean(), 1),
                    "Mean unmet": round(sub["unmet"].mean(), 1),
                    "Episodes beating rule-based": beats,
                    "Episodes beating tuned rule": beats_t})
    return pd.DataFrame(out)


# ------------------------------------------------------------------ what the agent learned
def policy_table(agent):
    """Greedy choice of the trained two-agent policy for each (stock level, days to expiry),
    at average demand. The agent's state has only 3 stock bins, so this table is coarse by design."""
    tag_p = {"REGULAR_PRICE": "Regular", "MODERATE_DISCOUNT": "Moderate", "CLEARANCE_DISCOUNT": "Clearance"}
    tag_i = {"NO_REORDER": "no order", "SMALL_REORDER": "order 10", "FULL_REORDER": "order 25"}
    stocks = [("Low (<10)", 5), ("Medium (10-24)", 15), ("High (25+)", 30)]
    expiries = [1, 2, 3]
    table = {}
    for label, stock in stocks:
        row = {}
        for exp in expiries:
            state = {"stock": stock, "days_to_expiry": exp, "recent_demand": 12.0, "seasonality": 1.0}
            s = discretize(state)
            row_p = agent.Qp.get(s)
            if row_p is None:
                row[f"{exp} day(s) left" if exp < 3 else "3+ days left"] = "not visited in training"
                continue
            p_idx = int(np.argmax(row_p))
            row_i = agent.Qi.get((s, p_idx))
            i_name = INV_ACTIONS[int(np.argmax(row_i))] if row_i is not None else "NO_REORDER"
            row[f"{exp} day(s) left" if exp < 3 else "3+ days left"] = f"{tag_p[PRICE_ACTIONS[p_idx]]} + {tag_i[i_name]}"
        table[label] = row
    return pd.DataFrame(table).T


# ------------------------------------------------------------------ saving / loading / training
def _to_list(k):
    return [_to_list(x) for x in k] if isinstance(k, (tuple, list)) else int(k)


def _to_tuple(k):
    return tuple(_to_tuple(x) for x in k) if isinstance(k, list) else k


def _dump(tbl):
    return [[_to_list(k), [float(x) for x in v]] for k, v in tbl.items()]


def _load(items):
    return {_to_tuple(k): np.array(v, dtype=float) for k, v in items}


def save_agents(agents, path=AGENT_FILE):
    data = {"single": _dump(agents["single"].Q), "two_Qp": _dump(agents["two"].Qp),
            "two_Qi": _dump(agents["two"].Qi), "two_g_Qp": _dump(agents["two_g"].Qp),
            "two_g_Qi": _dump(agents["two_g"].Qi)}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f)


def load_agents(path=AGENT_FILE):
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as f:
        d = json.load(f)
    single, two, two_g = SingleAgentQLearner(), TwoAgentQLearner(), TwoAgentQLearner()
    single.Q = _load(d["single"])
    two.Qp, two.Qi = _load(d["two_Qp"]), _load(d["two_Qi"])
    two_g.Qp, two_g.Qi = _load(d["two_g_Qp"]), _load(d["two_g_Qi"])
    for a in (single, two, two_g):
        a.eps = 0.0
    return {"single": single, "two": two, "two_g": two_g}


def train_agents(seed=42, episodes=1000):
    """Trains the three learners exactly as train_v2.py does (seed 42, 1000 episodes reproduces
    the agents behind the train_v2.py table)."""
    np.random.seed(seed)
    T.SEED = seed
    _, single = T.run_single(episodes)
    _, two = T.run_two(episodes, guard=False)
    _, two_g = T.run_two(episodes, guard=True)
    for a in (single, two, two_g):
        a.eps = 0.0
    return {"single": single, "two": two, "two_g": two_g}


# ------------------------------------------------------------------ stress test (proposal Section 12.2)
STRESS_SCENARIOS = [
    ("Normal (demand 12, shelf life 4)", 12, 4, {}),
    ("Demand +50% (18 a day)", 18, 4, {}),
    ("Demand -40% (7 a day)", 7, 4, {}),
    ("Short shelf life (2 days)", 12, 2, {}),
    ("Demand surge: x2.5 for 5 days from day 10", 12, 4, make_shocks(10, 5, 2.5)),
    ("Demand slump: x0.4 for 10 days from day 20", 12, 4, make_shocks(20, 10, 0.4)),
]


def stress_test(agents, n=15, horizon=60, gap=CONFIDENCE_GAP, seed0=555000):
    """Mean profit per episode for every method in every scenario. The agents were trained once at
    'Normal'; nobody retrains or re-tunes for the other scenarios."""
    rows = []
    for name, demand, shelf, shocks in STRESS_SCENARIOS:
        with scenario(demand, shelf):
            for m in METHODS:
                profits, wasted, unmet = [], [], []
                for k in range(n):
                    u = np.random.default_rng(seed0 + k).random(horizon)
                    df = run_episode(m, agents, u, horizon, shocks, gap)
                    profits.append(df["Profit (Rs)"].sum())
                    wasted.append(df["Wasted"].sum())
                    unmet.append(df["Unmet"].sum())
                rows.append({"Scenario": name, "Method": m, "Profit (Rs)": round(float(np.mean(profits))),
                             "Wasted": round(float(np.mean(wasted)), 1), "Unmet": round(float(np.mean(unmet)), 1)})
    return pd.DataFrame(rows)


def stress_pivot(df, col="Profit (Rs)"):
    return df.pivot(index="Scenario", columns="Method", values=col)[METHODS].loc[[x[0] for x in STRESS_SCENARIOS]]
