"""
Oracle upper bound: perfect demand foresight + 2-DAY lookahead search.

IMPORTANT, honestly documented bug-fix: a 1-step lookahead oracle (try all 9
actions, keep whichever wins TODAY) turns out to be a broken upper bound here
-reordering never affects the SAME day's sales in this environment (stock
arrives for tomorrow), so a greedy 1-day oracle sees zero same-day benefit to
reordering and never does it - it runs itself into permanent stock-outs. That
was caught by actually running it (see README for the broken numbers it
produced). Fixed by searching 2 days ahead (9x9=81 combinations per decision),
so reordering's benefit - tomorrow's avoided stock-out - is visible to the
search. Still not a true infinite-horizon optimum (a full DP solve over the
whole 60-day horizon would be needed for that, and is left as future work),
but it is now a fair, non-myopic upper bound.
"""
import os
BASE = os.path.dirname(os.path.abspath(__file__))  # save/load next to this script, works on any OS
import copy
import numpy as np
import pandas as pd
from retail_env import RetailEnv, PRICE_ACTIONS, INV_ACTIONS

HORIZON = 60
N_EPISODES = 30  # 2-day search is 81x more expensive per step than 1-day; kept smaller for runtime


def best_two_day_action(env):
    best_sum, best_action = -1e18, None
    for price_a in PRICE_ACTIONS:
        for inv_a in INV_ACTIONS:
            env1 = copy.deepcopy(env)
            _, (rp1, ri1), done1, _ = env1.step(price_a, inv_a)
            day1_reward = rp1 + ri1
            if done1:
                total = day1_reward
            else:
                # best achievable on day 2, given this day-1 choice (same realized demand path)
                best_day2 = -1e18
                for price_b in PRICE_ACTIONS:
                    for inv_b in INV_ACTIONS:
                        env2 = copy.deepcopy(env1)
                        _, (rp2, ri2), _, _ = env2.step(price_b, inv_b)
                        best_day2 = max(best_day2, rp2 + ri2)
                total = day1_reward + best_day2
            if total > best_sum:
                best_sum, best_action = total, (price_a, inv_a)
    return best_action


def oracle_episode(seed):
    env = RetailEnv(horizon=HORIZON, seed=seed)
    env.reset()
    ep_reward, ep_revenue, ep_waste, ep_stockout = 0, 0, 0, 0

    for day in range(HORIZON):
        price_a, inv_a = best_two_day_action(env)
        _, (rp, ri), done, info = env.step(price_a, inv_a)
        ep_reward += rp + ri
        ep_revenue += info["revenue"]; ep_waste += info["wastage"]; ep_stockout += info["stockout"]

    return dict(total_reward=ep_reward, revenue=ep_revenue, wastage=ep_waste, stockout=ep_stockout)


if __name__ == "__main__":
    rows = [oracle_episode(seed=1000 + ep) for ep in range(N_EPISODES)]
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(BASE, "results_oracle.csv"), index=False)
    print(f"Oracle (perfect one-step demand foresight), {N_EPISODES} episodes:")
    print(df.mean().to_string())
