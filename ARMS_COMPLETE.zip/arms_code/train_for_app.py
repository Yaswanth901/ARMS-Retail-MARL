"""
Trains the three learners (Single-Agent, Two-Agent, Two-Agent + guardrails) with the same
settings as train_v2.py (seed 42, 1000 episodes) and saves them to trained_v2_agents.json,
which the Streamlit app and the PowerShell demo load. Takes about 2 minutes.

    python train_for_app.py
    python train_for_app.py 7 600     # optional: seed and episodes
"""
import sys
import app_core as C

if __name__ == "__main__":
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 42
    episodes = int(sys.argv[2]) if len(sys.argv) > 2 else 1000
    print(f"Training 3 agents (seed {seed}, {episodes} episodes each)...")
    agents = C.train_agents(seed, episodes)
    C.save_agents(agents)
    print("Saved:", C.AGENT_FILE)
