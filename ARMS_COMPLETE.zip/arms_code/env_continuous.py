"""
Continuous-observation version of the retail environment (same economics as
retail_env.py, used by the tabular baselines) - neural-network-based agents
(NFQ here, MAPPO in mappo_torch.py) need float vectors, not discretized bins.
No torch dependency, so this file runs in any plain Python/NumPy environment.
"""
import numpy as np

PRICE_ACTIONS = ["REGULAR_PRICE", "MODERATE_DISCOUNT", "CLEARANCE_DISCOUNT"]
PRICE_MULTIPLIER = [1.0, 0.85, 0.65]
DEMAND_LIFT = [1.0, 1.15, 1.3]  # calibrated so discounts are a real margin trade-off, not free revenue
INV_ACTIONS = ["NO_REORDER", "SMALL_REORDER", "FULL_REORDER"]
REORDER_QTY = [0, 10, 25]

BASE_PRICE, BASE_DEMAND, SHELF_LIFE, EXCESS_THRESHOLD = 50.0, 12.0, 4, 35
LAMBDA_W, LAMBDA_S, LAMBDA_E = 4.0, 3.0, 2.5


class ContinuousRetailEnv:
    def __init__(self, horizon=60, seed=None):
        self.horizon = horizon
        self.rng = np.random.default_rng(seed)
        self.reset()

    def reset(self):
        self.day = 0
        self.batches = [[20, SHELF_LIFE]]
        return self._obs()

    def _stock(self):
        return sum(b[0] for b in self.batches)

    def _expiry(self):
        return min((b[1] for b in self.batches), default=SHELF_LIFE)

    def _obs(self, recent_demand=BASE_DEMAND):
        seasonality = 1.15 if (self.day % 7) in (5, 6) else 1.0
        return np.array([self._stock() / 50.0, self._expiry() / SHELF_LIFE,
                          recent_demand / 25.0, seasonality], dtype=np.float32)

    def step(self, price_idx, inv_idx):
        seasonality = 1.15 if (self.day % 7) in (5, 6) else 1.0
        expected_demand = BASE_DEMAND * DEMAND_LIFT[price_idx] * seasonality
        demand = max(0, self.rng.poisson(expected_demand))

        units_sold, remaining = 0, demand
        for b in self.batches:
            if remaining <= 0:
                break
            take = min(b[0], remaining)
            b[0] -= take; units_sold += take; remaining -= take
        stockout = max(0, demand - units_sold)
        revenue = units_sold * BASE_PRICE * PRICE_MULTIPLIER[price_idx]

        wastage, kept = 0, []
        for b in self.batches:
            b[1] -= 1
            if b[1] <= 0:
                wastage += b[0]
            elif b[0] > 0:
                kept.append(b)
        self.batches = kept
        if REORDER_QTY[inv_idx] > 0:
            self.batches.append([REORDER_QTY[inv_idx], SHELF_LIFE])
        excess = max(0, self._stock() - EXCESS_THRESHOLD)

        r_price = revenue - LAMBDA_W * wastage
        r_inv = units_sold - LAMBDA_S * stockout - LAMBDA_E * excess

        self.day += 1
        done = self.day >= self.horizon
        return self._obs(demand), (r_price, r_inv), done, dict(
            revenue=revenue, wastage=wastage, stockout=stockout, demand=demand, units_sold=units_sold)
