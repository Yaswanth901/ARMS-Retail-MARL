"""
Multi-seed check of the v2 (real-profit) results.
Trains Single-Agent, Two-Agent, and Two-Agent+guardrails across independent seeds,
evaluates each on the same fresh test seeds, and runs paired t-tests.
"""
import os
BASE = os.path.dirname(os.path.abspath(__file__))
import numpy as np
import pandas as pd
from scipy import stats
import train_v2 as T

N_SEEDS = 5
N_EPISODES = 600


def one_seed(seed):
    T.SEED = seed * 1000
    np.random.seed(seed)
    _, single = T.run_single(N_EPISODES)
    _, two = T.run_two(N_EPISODES, guard=False)
    _, two_g = T.run_two(N_EPISODES, guard=True)
    return (T.evaluate(T.greedy_policy(single))["profit"].mean(),
            T.evaluate(T.greedy_policy(two))["profit"].mean(),
            T.evaluate(T.greedy_policy(two_g), guard=True)["profit"].mean())


if __name__ == "__main__":
    rule_profit = T.evaluate(T.rule_policy)["profit"].mean()
    rows = []
    for seed in range(N_SEEDS):
        s, t, g = one_seed(seed)
        rows.append(dict(seed=seed, single=s, two_agent=t, two_agent_guarded=g))
        print(f"seed {seed}: single={s:7.0f}  two-agent={t:7.0f}  two-agent+guardrails={g:7.0f}", flush=True)

    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(BASE, "multi_seed_v2_results.csv"), index=False)
    print(f"\nRule-based reference: {rule_profit:.0f}")
    for col in ["single", "two_agent", "two_agent_guarded"]:
        print(f"{col:18s} {df[col].mean():7.0f} +/- {df[col].std(ddof=1):5.0f}   wins vs rule-based: {(df[col] > rule_profit).sum()}/{N_SEEDS}")

    def compare(a, b, label):
        t, p = stats.ttest_rel(df[a], df[b])
        print(f"{label}: mean diff {df[a].mean() - df[b].mean():+.0f}, wins {(df[a] > df[b]).sum()}/{N_SEEDS}, paired t-test p={p:.4f}")

    print()
    compare("two_agent", "single", "Two-Agent vs Single-Agent (no guardrails)")
    compare("two_agent_guarded", "two_agent", "Two-Agent + guardrails vs Two-Agent")
    compare("two_agent_guarded", "single", "Two-Agent + guardrails vs Single-Agent")
