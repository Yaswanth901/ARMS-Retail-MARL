import os
BASE = os.path.dirname(os.path.abspath(__file__))  # save/load next to this script, works on any OS
import numpy as np
import pandas as pd
from env_continuous import ContinuousRetailEnv
from agents_nfq import SingleAgentNFQ, TwoAgentNFQ

HORIZON = 60
N_EPISODES = 400   # NFQ refits a full network each iteration - fewer episodes needed than tabular
FIT_EVERY = 5       # batch-fit every 5 episodes (classic Fitted-Q-Iteration style)
SEED = 123


def run_single_nfq(n_episodes=N_EPISODES):
    agent = SingleAgentNFQ()
    rows = []
    for ep in range(n_episodes):
        env = ContinuousRetailEnv(horizon=HORIZON, seed=SEED + ep)
        obs = env.reset()
        ep_reward, ep_revenue, ep_waste, ep_stockout, ep_demand = 0, 0, 0, 0, 0
        for _ in range(HORIZON):
            idx, price_a, inv_a = agent.act(obs)
            p_idx, i_idx = SingleAgentNFQ.JOINT_ACTIONS[idx]
            next_obs, (rp, ri), done, info = env.step(p_idx, i_idx)
            agent.remember(obs, idx, rp + ri, next_obs, done)
            obs = next_obs
            ep_reward += rp + ri
            ep_revenue += info["revenue"]; ep_waste += info["wastage"]
            ep_stockout += info["stockout"]; ep_demand += info["demand"]
        if ep % FIT_EVERY == 0:
            agent.fit_iteration()
        agent.decay()
        rows.append(dict(episode=ep, total_reward=ep_reward, revenue=ep_revenue, wastage=ep_waste,
                          stockout=ep_stockout, fill_rate=(ep_demand - ep_stockout) / max(ep_demand, 1)))
        if ep % 50 == 0:
            print(f"  [single-NFQ] ep {ep:4d}  reward {ep_reward:8.0f}  eps {agent.eps:.2f}")
    return pd.DataFrame(rows)


def run_two_nfq(n_episodes=N_EPISODES):
    agent = TwoAgentNFQ()
    rows = []
    for ep in range(n_episodes):
        env = ContinuousRetailEnv(horizon=HORIZON, seed=SEED + ep)
        obs = env.reset()
        ep_reward, ep_revenue, ep_waste, ep_stockout, ep_demand = 0, 0, 0, 0, 0
        for _ in range(HORIZON):
            p_idx, i_idx, inv_in, price_a, inv_a = agent.act(obs)
            next_obs, (rp, ri), done, info = env.step(p_idx, i_idx)
            next_p_idx = p_idx  # for logging the next inventory input consistently
            next_onehot = np.eye(3)[next_p_idx]
            next_inv_in = np.concatenate([next_obs, next_onehot])
            agent.remember(obs, p_idx, i_idx, inv_in, rp, ri, next_obs, next_inv_in, done)
            obs = next_obs
            ep_reward += rp + ri
            ep_revenue += info["revenue"]; ep_waste += info["wastage"]
            ep_stockout += info["stockout"]; ep_demand += info["demand"]
        if ep % FIT_EVERY == 0:
            agent.fit_iteration()
        agent.decay()
        rows.append(dict(episode=ep, total_reward=ep_reward, revenue=ep_revenue, wastage=ep_waste,
                          stockout=ep_stockout, fill_rate=(ep_demand - ep_stockout) / max(ep_demand, 1)))
        if ep % 50 == 0:
            print(f"  [two-NFQ]    ep {ep:4d}  reward {ep_reward:8.0f}  eps {agent.eps:.2f}")
    return pd.DataFrame(rows), agent


if __name__ == "__main__":
    np.random.seed(SEED)
    print("Training Single-Agent NFQ (neural net, joint action space)...")
    df_single_nfq = run_single_nfq()
    print("Training Two-Agent NFQ (two neural nets, independent learners, Inventory conditioned on Pricing's action)...")
    df_two_nfq, two_nfq_agent = run_two_nfq()

    df_single_nfq.to_csv(os.path.join(BASE, "results_single_nfq.csv"), index=False)
    df_two_nfq.to_csv(os.path.join(BASE, "results_two_nfq.csv"), index=False)

    print("\n=== NFQ results (last 50 episodes) ===")
    print("Single-Agent NFQ: ", df_single_nfq.tail(50)[["total_reward", "wastage", "stockout", "fill_rate"]].mean().to_dict())
    print("Two-Agent NFQ:    ", df_two_nfq.tail(50)[["total_reward", "wastage", "stockout", "fill_rate"]].mean().to_dict())
    print("done")
