"""
MAPPO v3: the same algorithm as mappo_numpy.py (PPO with clipped updates, GAE, entropy bonus, action masks, centralised critics),
but the inputs and the number of price levels are configurable, and it runs in retail_env_v3.py.
Input sets:  basic    = stock, days to expiry, weekday effect, last demand              (4)
             extras   = basic + smoothed demand + units expiring today                  (6)  <- what the original MAPPO sees
             age      = extras + units by days left (stock by age)                      (11)
             pipe     = extras + units on order                                          (7)
             full     = age + units on order                                             (12)
Also contains the rule baselines used in the experiments (all take a state and return (price index, inventory index)).
"""
import numpy as np
import mappo_numpy as M
import retail_env_v2 as V
from retail_env_v3 import RetailEnvV3, LEGACY_LEVELS

HORIZON, REWARD_SCALE = 60, 0.01
min_ent = M._selected_entropy("MAPPO")   # the entropy bonus chosen on validation episodes


def f_basic(s): return [s["stock"] / 45.0, min(s["days_to_expiry"], 5) / 5.0, s["seasonality"], s["recent_demand"] / 25.0]
def f_extras(s): return f_basic(s) + [s["demand_ema"] / 20.0, s["expiring"] / 25.0]
def f_age(s): return f_extras(s) + [a / 25.0 for a in s["age"]]
def f_pipe(s): return f_extras(s) + [s["on_order"] / 25.0]
def f_markov(s): return f_extras(s) + [1.0 if s["weekday"] == k else 0.0 for k in range(7)]      # adds the day of the week, which the true dynamics depend on
def f_full(s): return f_age(s) + [s["on_order"] / 25.0]
FEATURES = {"basic": (f_basic, 4), "extras": (f_extras, 6), "age": (f_age, 11), "pipe": (f_pipe, 7), "full": (f_full, 12), "markov": (f_markov, 13)}


def price_mask(s, levels):
    """A price below cost is allowed only when the stock expires within a day (same safety rule as before)."""
    return np.array([0.0 if (V.BASE_PRICE * (1 - l) < V.UNIT_COST and s["days_to_expiry"] > 1) else 1.0 for l in levels])


class MAPPOv3:
    def __init__(self, seed=0, feat="extras", levels=LEGACY_LEVELS, hidden=64, lr=1e-3, gamma=0.97, lam=0.95, clip=0.2, epochs=4, minibatch=256, ent=min_ent,
                 critic="correct", team_reward=False, use_masks=True, service_target=None, dual_lr=0.002, lam_max=40.0):
        self.rng = np.random.default_rng(seed); r = self.rng
        self.feat, self.levels, self.nP = feat, tuple(levels), len(levels)
        self.f, nf = FEATURES[feat]
        self.actor_p = M.MLP([nf, hidden, hidden, self.nP], r, 0.01)
        self.actor_i = M.MLP([nf + self.nP, hidden, hidden, 3], r, 0.01)
        self.critic, self.team_reward, self.use_masks = critic, team_reward, use_masks
        self.service_target, self.dual_lr, self.lam, self.lam_max = service_target, dual_lr, 0.0, lam_max      # optional constraint: at most `service_target` unmet units per episode (Lagrange multiplier lam)
        # 'correct': the pricing critic sees the state only, so its baseline does not depend on the pricing agent's own action.
        # 'legacy' (the earlier design): it also saw the chosen price, which cancels the pricing agent's learning signal.
        self.crit_p = M.MLP([nf + (self.nP if critic == "legacy" else 0), hidden, hidden, 1], r, 1.0)
        self.crit_i = M.MLP([nf + self.nP, hidden, hidden, 1], r, 1.0)
        self.lr, self.gamma, self.lam, self.clip, self.epochs, self.minibatch, self.ent = lr, gamma, lam, clip, epochs, minibatch, ent

    def act(self, s, greedy=False, force_price=None):
        x = np.array(self.f(s))[None]; mp = price_mask(s, self.levels) if self.use_masks else np.ones(self.nP)
        pp = M.masked_probs(self.actor_p.forward(x)[0], mp)[0]
        a_p = force_price if force_price is not None else (int(np.argmax(pp)) if greedy else int(self.rng.choice(self.nP, p=pp)))
        onehot = np.zeros(self.nP); onehot[a_p] = 1.0
        xi = np.concatenate([x[0], onehot])[None]; mi = M.inv_mask(s) if self.use_masks else np.ones(3)
        pi = M.masked_probs(self.actor_i.forward(xi)[0], mi)[0]
        a_i = int(np.argmax(pi)) if greedy else int(self.rng.choice(3, p=pi))
        if greedy: return a_p, a_i
        return dict(xp=x[0], mp=mp, ap=a_p, lpp=float(np.log(pp[a_p] + 1e-12)), xi=xi[0], mi=mi, ai=a_i, lpi=float(np.log(pi[a_i] + 1e-12)),
                    xcp=(x[0] if self.critic == "correct" else xi[0]), vp=float(self.crit_p.forward((x if self.critic == "correct" else xi))[0][0, 0]), vi=float(self.crit_i.forward(xi)[0][0, 0]))

    def _gae(self, r, v, last_v=0.0):
        T = len(r); adv = np.zeros(T); g = 0.0
        for t in reversed(range(T)):
            nv = last_v if t == T - 1 else v[t + 1]
            g = (r[t] + self.gamma * nv - v[t]) + self.gamma * self.lam * g; adv[t] = g
        return adv, adv + np.array(v)

    def update(self, episodes):
        keys = ["xp", "mp", "ap", "lpp", "xi", "mi", "ai", "lpi", "xcp"]; cols = {k: [] for k in keys}; advp, retp, advi, reti = [], [], [], []
        for ep in episodes:
            for k in keys: cols[k] += [st[k] for st in ep["steps"]]
            a1, r1 = self._gae(ep["rp"], [st["vp"] for st in ep["steps"]]); a2, r2 = self._gae(ep["ri"], [st["vi"] for st in ep["steps"]])
            advp.append(a1); retp.append(r1); advi.append(a2); reti.append(r2)
        D = {k: np.array(v) for k, v in cols.items()}; advp, retp, advi, reti = map(np.concatenate, (advp, retp, advi, reti))
        advp = (advp - advp.mean()) / (advp.std() + 1e-8); advi = (advi - advi.mean()) / (advi.std() + 1e-8); n = len(advp)
        for _ in range(self.epochs):
            idx = self.rng.permutation(n)
            for lo in range(0, n, self.minibatch):
                b = idx[lo:lo + self.minibatch]
                _, gW, gb = M.actor_loss_and_grads(self.actor_p, D["xp"][b], D["mp"][b], D["ap"][b], D["lpp"][b], advp[b], self.clip, self.ent); self.actor_p.adam(gW, gb, self.lr)
                _, gW, gb = M.actor_loss_and_grads(self.actor_i, D["xi"][b], D["mi"][b], D["ai"][b], D["lpi"][b], advi[b], self.clip, self.ent); self.actor_i.adam(gW, gb, self.lr)
                _, gW, gb = M.critic_loss_and_grads(self.crit_p, D["xcp"][b], retp[b]); self.crit_p.adam(gW, gb, self.lr)
                _, gW, gb = M.critic_loss_and_grads(self.crit_i, D["xi"][b], reti[b]); self.crit_i.adam(gW, gb, self.lr)

    def policy(self, force_price=None):
        return lambda s: self.act(s, greedy=True, force_price=force_price)


def rollout(agent, seed, it, n_episodes, env_kw):
    episodes, profits = [], []
    for j in range(n_episodes):
        env = RetailEnvV3(HORIZON, seed=seed * 1_000_000 + it * 1000 + j, **env_kw); s = env.reset(); steps, rp, ri, prof, um = [], [], [], 0.0, 0
        for _ in range(HORIZON):
            d = agent.act(s); s, (r_p, r_i), _, info = env.step(d["ap"], d["ai"])
            steps.append(d); prof += info["profit"]; um += info["stockout"]; r_i = r_i - agent.lam * info["stockout"]
            if agent.team_reward: rp.append((r_p + r_i) * REWARD_SCALE); ri.append((r_p + r_i) * REWARD_SCALE)
            else: rp.append(r_p * REWARD_SCALE); ri.append(r_i * REWARD_SCALE)
        episodes.append(dict(steps=steps, rp=rp, ri=ri, unmet=um)); profits.append(prof)
    return episodes, float(np.mean(profits))


def train(seed=0, iterations=120, feat="extras", env_kw=None, episodes_per_iter=16, **hp):
    env_kw = dict(env_kw or {}); agent = MAPPOv3(seed, feat, levels=env_kw.get("levels", LEGACY_LEVELS), **hp); curve = []
    for it in range(iterations):
        eps, mean_profit = rollout(agent, seed, it, episodes_per_iter, env_kw); agent.update(eps); curve.append(mean_profit)
    return agent, curve


def evaluate_detail(policy, env_kw=None, n=60, seed0=900000):
    """One row per fresh episode: profit, waste, unmet, fill rate, order days, discount days and safety violations."""
    import pandas as pd
    env_kw = dict(env_kw or {}); rows = []
    for k in range(n):
        env = RetailEnvV3(HORIZON, seed=seed0 + k, **env_kw); s = env.reset(); r = dict(profit=0.0, wasted=0, unmet=0, demand=0, sold=0, order_days=0, discount_days=0, below_cost_days=0, overflow_days=0)
        for _ in range(HORIZON):
            d_left = s["days_to_expiry"]; p, i = policy(s); s, _, _, info = env.step(p, i)
            r["profit"] += info["profit"]; r["wasted"] += info["wastage"]; r["unmet"] += info["stockout"]; r["demand"] += info["demand"]; r["sold"] += info["units_sold"]
            r["order_days"] += int(i > 0); r["discount_days"] += int(info["p_idx"] > 0)
            r["below_cost_days"] += int(info["price"] < V.UNIT_COST and d_left > 1); r["overflow_days"] += int(info["stock_after"] > V.MAX_STOCK)
        r["fill_rate"] = r["sold"] / max(r["demand"], 1); r["waste_rate"] = r["wasted"] / max(r["sold"] + r["wasted"], 1)
        r["success"] = int(r["fill_rate"] >= 0.95 and r["waste_rate"] <= 0.03); rows.append(r)
    return pd.DataFrame(rows)


def evaluate(policy, env_kw=None, n=60, seed0=900000):
    """Mean results of a policy on fresh episodes it never trained on."""
    env_kw = dict(env_kw or {}); rows = []
    for k in range(n):
        env = RetailEnvV3(HORIZON, seed=seed0 + k, **env_kw); s = env.reset(); tot = w = u = disc = 0
        for _ in range(HORIZON):
            p, i = policy(s); s, _, _, info = env.step(p, i); tot += info["profit"]; w += info["wastage"]; u += info["stockout"]; disc += int(info["p_idx"] > 0)
        rows.append((tot, w, u, disc))
    m = np.mean(rows, axis=0)
    return dict(profit=float(m[0]), wasted=float(m[1]), unmet=float(m[2]), discount_days=float(m[3]))


# ------------------------------------------------------------------ rule baselines (no learning)
def rule_ss(thr=26, price_idx=0):
    """Tuned (s,S) rule: order a full batch when stock <= thr; fixed price."""
    return lambda s: (price_idx, 2 if s["stock"] <= thr else 0)

def rule_ss_adaptive(price_idx=0):
    """The SAME extra input MAPPO gets (smoothed demand): the reorder point scales with demand, 26 at 12 a day."""
    return lambda s: (price_idx, 2 if s["stock"] <= round(26.0 * s["demand_ema"] / 12.0) else 0)

def rule_markdown(levels, markdown_level=0.30, min_expiring=2, thr=26):
    """(s,S) ordering plus a manual markdown: when at least `min_expiring` units expire today, sell at the chosen discount."""
    j = int(np.argmin([abs(l - markdown_level) for l in levels]))
    return lambda s: (j if s["expiring"] >= min_expiring else 0, 2 if s["stock"] <= thr else 0)

def tune_ss(env_kw=None, n=30, seed0=500000, adaptive=False):
    """Grid-search the reorder point on tuning episodes (never the test episodes); returns the best threshold and its policy."""
    best = None
    for thr in range(8, 47, 2):
        r = evaluate(rule_ss(thr), env_kw, n, seed0)["profit"]
        if best is None or r > best[1]: best = (thr, r)
    return best[0], rule_ss(best[0])
