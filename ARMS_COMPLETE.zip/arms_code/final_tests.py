"""ALL TESTS in one place.   python final_tests.py          (about 3 minutes)
                           python final_tests.py --full   (also runs the RL integrity check and the app with every button pressed; about 8 minutes)"""
import subprocess, sys, os, json
import numpy as np, pandas as pd
RESULTS = []
def check(name, ok, detail=""):
    RESULTS.append(bool(ok)); print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f"\n        {detail}" if detail else ""), flush=True)

import retail_env_v2 as V, retail_env_v3 as E3, mappo_v3 as W, features_core as F
from retail_env_v3 import RetailEnvV3, FINE_LEVELS

print("1. SIMULATOR\n")
rng = np.random.default_rng(0); worst = 0.0
for seed in range(20):
    a, b = V.RetailEnvV2(60, seed=seed), RetailEnvV3(60, seed=seed); a.reset(); b.reset()
    for _ in range(60):
        pa, ia = int(rng.integers(3)), int(rng.integers(3))
        fa = a.step(V.PRICE_ACTIONS[pa], V.INV_ACTIONS[ia])[3]; fb = b.step(pa, ia)[3]
        worst = max(worst, abs(fa["profit"] - fb["profit"]), abs(fa["wastage"] - fb["wastage"]), abs(fa["stockout"] - fb["stockout"]))
check("v3 with default options reproduces v2 exactly (20 random episodes)", worst == 0.0, f"largest difference {worst}")
e = RetailEnvV3(60, seed=3, delay=(0.5, 0.3, 0.2)); s = e.reset(); bad = 0
for _ in range(60):
    s = e.step(0, int(rng.integers(3)))[0]; bad += int(sum(s["age"]) != s["stock"])
check("stock-by-age adds up to the stock on every day", bad == 0)
e = RetailEnvV3(300, seed=5, delay=(0.5, 0.3, 0.2), shelf=1000, base_demand=1e-12); e.reset(); ordered = 0; ok = True
for t in range(300):
    i = 2 if t % 3 == 0 else 0; s = e.step(0, i)[0]; ordered += 25 if i == 2 else 0; ok &= (s["stock"] + s["on_order"] == 20 + ordered)
check("delayed deliveries conserve units (shelf + on order = 20 + everything ordered)", ok)
lifts = [RetailEnvV3(elasticity=2.0, levels=FINE_LEVELS).lift(j) for j in range(5)]
check("price response: demand = base x price^(-elasticity)", np.allclose(lifts, [(1 - l) ** -2.0 for l in FINE_LEVELS]), f"lifts at 0/10/20/30/40% off with elasticity 2: {np.round(lifts, 2).tolist()}")
m = W.price_mask({"days_to_expiry": 3}, FINE_LEVELS); m1 = W.price_mask({"days_to_expiry": 1}, FINE_LEVELS)
check("safety: a price below cost is blocked unless the stock expires within a day", m.tolist() == [1, 1, 1, 1, 0] and m1.tolist() == [1, 1, 1, 1, 1], f"{m.tolist()} and {m1.tolist()}")

print("\n2. LEARNING\n")
un = [W.evaluate(W.MAPPOv3(seed=s_, feat="age").policy(), n=20)["profit"] for s_ in (21, 22, 23)]
tr = [W.evaluate(W.train(seed=s_, iterations=40, feat="age")[0].policy(), n=20)["profit"] for s_ in (21, 22, 23)]
check("MAPPO with stock-by-age inputs learns (3 seeds, 40 iterations, fresh episodes)", np.mean(tr) > np.mean(un) + 1000 and min(tr) > 6000, f"untrained mean Rs {np.mean(un):,.0f}; trained {[round(x) for x in tr]}")
import mappo_multi as MM, agents_multi as A
u3 = A.evaluate(MM.MAPPOMulti(seed=2).policy(), n=15).profit.mean(); ag3, c3 = MM.train(seed=2, iterations=15)
check("MAPPO in the 3-product store learns", c3[-1] > c3[0] + 1500, f"training profit {c3[0]:,.0f} -> {c3[-1]:,.0f} in 15 iterations")

print("\n3. DATA-DRIVEN PARTS\n")
subprocess.run([sys.executable, "make_price_test_data.py"], capture_output=True); r = subprocess.run([sys.executable, "estimate_price_response.py"], capture_output=True, text=True)
pr = json.load(open("price_response.json")); check("price-response estimator recovers the true elasticity (2.0) inside its 90% interval", pr["ci_low"] <= 2.0 <= pr["ci_high"], f"measured {pr['elasticity']:.2f} (interval {pr['ci_low']:.2f} to {pr['ci_high']:.2f})")
import offer_bandit as OB
w = OB.OfferWorld(0.01, 0.03, 0.60); best, true, share, regret, dist = OB.run(w, OB.EpsGreedy, 0.0, days=90, runs=20)
check("offer learner finds the best offer far more often than chance (random = 17%)", share > 0.40, f"best arm '{OB.ARMS[best]}' chosen in {share:.0%} of the last 30 evenings")
plans = F.shop_plan([("Milk packet", 34, 1), ("Curd cup", 16, 2), ("Bread", 20, 3)])
check("shop assistant flags the milk that is likely to expire and proposes a price not below cost", plans[0]["at_risk"] > 0 and plans[0]["price"] >= 35.0 - 1e-9, f"milk: {plans[0]['at_risk']} units at risk, price Rs {plans[0]['price']:.1f}")
check("cross-sell never claims a link below chance", all((p["cross_sell"]["Bought together (lift)"] >= 1.05).all() or "no special link" in p["cross_sell"].iloc[0]["Why"] for p in plans))

print("\n3b. THE FIVE ALGORITHMS AND THE EVALUATION SUITE\n")
import baselines_rl as B, performance_suite as PS
rnd = PS.final_rows("Random (masked)", "-", PS.random_masked(), {"Seen: normal shop": {}}, False)[0][0]["ret"]
for name, fn in (("DQN", lambda: B.train_dqn(0, 64, 64, PS.ev_fn)), ("Double DQN", lambda: B.train_dqn(0, 64, 64, PS.ev_fn, True)), ("PPO (single agent)", lambda: B.train_ppo(0, 64, 64, PS.ev_fn)), ("MAPPO", lambda: B.train_mappo(0, 64, 64, PS.ev_fn)), ("Q-learning", lambda: B.train_qlearning(0, 200, 200, PS.ev_fn))):
    c = fn()[1]; check(f"{name} learns: final designed return clearly above a random masked policy", c[-1][1] > rnd + (3000 if name != "Q-learning" else 1500) and c[-1][1] > c[0][1], f"random masked {rnd:,.0f}; start {c[0][1]:,.0f} -> end {c[-1][1]:,.0f}")
hp = json.load(open("hp_selection.json")); check("entropy bonus was selected on validation episodes for PPO and MAPPO", set(hp) == {"PPO (single agent)", "MAPPO"}, str(hp))
sm = json.load(open("perf_summary.json")); fm = {r["method"]: r for r in sm["final"]}
check("evaluation summary: all five algorithms and the three rules are present, MAPPO beats the original rule and random policy", all(m in fm for m in ("MAPPO (ours)", "DQN", "Double DQN", "PPO (single agent)", "Q-learning (tabular, two agents)", "Tuned (s,S) rule", "Tuned order-up-to rule", "Original rule")) and fm["MAPPO (ours)"]["mean"] > fm["Original rule"]["mean"] + 3000, f"MAPPO {fm['MAPPO (ours)']['mean']:,.0f}, original rule {fm['Original rule']['mean']:,.0f}")
check("the three diagrams exist (PNG, SVG, native JSON) and the editable draw.io file", all(os.path.exists(f"diagrams/{n}.{e}") for n in ("mdp_loop", "mdp_tuple", "system") for e in ("png", "svg", "json")) and os.path.exists("diagrams/ARMS_diagrams.drawio"))
for fn in ("ma_metrics.json", "ma_metrics_quiet.json"):
    mm = json.load(open(fn)); check(f"multi-agent metrics file {fn} has individual reward, cross-play, coordination and roles", all(k in mm for k in ("individual", "crossplay", "coordination", "roles")) and len(mm["crossplay"]["matrix"]) == 5, f"cross-play own teammate {mm['crossplay']['self_play']:,.0f}, other team {mm['crossplay']['cross_play']:,.0f}")
sn = pd.read_csv("results_sensitivity.csv"); check("sensitivity study (corrected critic) covers 7 settings x 3 seeds", sn.method.nunique() == 7 and sn.seed.nunique() == 3, f"{sn.method.nunique()} settings, {sn.seed.nunique()} seeds")
check("figures exist: learning curve, regret, convergence, generalization, ablation, cross-play", all(os.path.exists(f"figures/{n}.png") for n in ("learning_curve", "regret", "convergence", "generalization", "ablation", "crossplay_quiet")))
r = subprocess.run([sys.executable, "check_mdp_diagram.py"], capture_output=True, text=True); check("every field in the MDP diagrams equals the code, and the MDP rules hold (17 checks)", "17 of 17 checks passed" in r.stdout, [l for l in r.stdout.splitlines() if l.startswith("SUMMARY")][-1:] and [l for l in r.stdout.splitlines() if l.startswith("SUMMARY")][-1])
print("\n4. SAVED RESULTS AND THE APP\n")
for f in ("results_ablation.csv", "results_delays.csv", "results_pricing.csv", "results_pricing_waste.csv", "results_multi_mappo.csv", "results_offer_bandit.csv", "hybrid_results.csv", "money_saved_report.csv", "perf_final.csv", "perf_curves.csv", "perf_ablation.csv", "perf_compute.csv", "perf_episodes.csv"):
    ok = os.path.exists(f) and len(pd.read_csv(f)) > 0; check(f"results file {f} exists and is not empty", ok)
check("deck_data.json (every number used by the report and presentation) exists", os.path.exists("deck_data.json"))
r = subprocess.run([sys.executable, "test_app.py"], capture_output=True, text=True); check("the whole app runs with default settings (no exception, no page error)", r.returncode == 0, r.stdout.strip().splitlines()[0] if r.stdout else r.stderr[-200:])
if "--full" in sys.argv:
    r = subprocess.run([sys.executable, "test_app.py", "--buttons"], capture_output=True, text=True); check("the app runs with every button pressed", r.returncode == 0, r.stdout.strip().splitlines()[0] if r.stdout else r.stderr[-200:])
    r = subprocess.run([sys.executable, "rl_integrity_check.py"], capture_output=True, text=True); check("RL integrity check (8 tests)", "8 of 8 tests passed" in r.stdout, [l for l in r.stdout.splitlines() if l.startswith("SUMMARY")][-1:] and [l for l in r.stdout.splitlines() if l.startswith("SUMMARY")][-1])
print(f"\nSUMMARY: {sum(RESULTS)} of {len(RESULTS)} tests passed"); sys.exit(0 if all(RESULTS) else 1)
