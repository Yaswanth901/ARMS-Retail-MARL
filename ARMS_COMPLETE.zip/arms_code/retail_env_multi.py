"""
Three-product store: milk, curd and bread with different prices, costs, shelf lives and demand,
all sharing ONE limited shelf. This is the setting where a single simple rule struggles, because
products compete for the same space.

Rules of the world (all values are assumptions of the simulation):
  - Each product has its own price tier (regular / moderate discount / clearance) and reorder size (0 / 10 / 25).
  - The shelf holds at most CAPACITY units in total. Orders that do not fit are cut down to what fits.
    Priority for scarce space rotates each day, so no product is always first.
  - Substitution: when a product sells out, SPILL of its unmet customers try the next product
    (milk -> curd -> bread -> milk); the rest are lost.
  - Money is accounted as in retail_env_v2: margin on sales, purchase cost of expired stock, holding cost,
    fixed cost per order, and a stock-out penalty (lost margin plus goodwill).
"""
import numpy as np
from scipy.stats import poisson
import retail_env_v2 as V
from retail_env_v2 import PRICE_ACTIONS, INV_ACTIONS, PRICE_MULTIPLIER, DEMAND_LIFT, REORDER_QTY

PRODUCTS = [
    dict(name="Milk",  price=50.0, cost=35.0, shelf=4, demand=12.0),
    dict(name="Curd",  price=40.0, cost=28.0, shelf=6, demand=8.0),
    dict(name="Bread", price=32.0, cost=22.0, shelf=3, demand=10.0),
]
N = len(PRODUCTS)
INIT_STOCK = [18, 12, 15]
CAPACITY = 60          # total units the shelf can hold
SPILL = 0.3            # share of unmet customers who try the next product
GOODWILL = 5.0         # extra stock-out penalty per unit beyond lost margin


class MultiTraceRNG:
    """Common random numbers for all methods: demand of product k on day d is the Poisson quantile of a
    pre-drawn uniform u[d][k], with an optional demand multiplier (shock) per day."""

    def __init__(self, uniforms, shocks=None):
        self.u = uniforms
        self.shocks = shocks or {}
        self.i = 0

    def poisson(self, lam):
        day, k = divmod(self.i, N)
        self.i += 1
        mult = self.shocks.get(day, 1.0)
        u = float(min(max(self.u[day][k], 1e-9), 1 - 1e-9))
        return int(poisson.ppf(u, lam * mult))


class MultiStoreEnv:
    def __init__(self, horizon=60, seed=None, rng=None):
        self.horizon = horizon
        self.rng = rng if rng is not None else np.random.default_rng(seed)
        self.reset()

    def reset(self):
        self.day = 0
        self.batches = [[[INIT_STOCK[k], PRODUCTS[k]["shelf"]]] for k in range(N)]
        self.last_demand = [P["demand"] for P in PRODUCTS]
        return self.states()

    # ---- helpers
    def stock(self, k):
        return sum(b[0] for b in self.batches[k])

    def total_stock(self):
        return sum(self.stock(k) for k in range(N))

    def expiry(self, k):
        return min((b[1] for b in self.batches[k]), default=PRODUCTS[k]["shelf"])

    def states(self):
        used = self.total_stock()
        season = V.WEEKDAY_MULT[self.day % 7]
        return [dict(stock=self.stock(k), days_to_expiry=self.expiry(k), recent_demand=self.last_demand[k],
                     seasonality=season, shelf_used=used, product=k) for k in range(N)]

    def _sell(self, k, want):
        sold, remaining = 0, want
        for b in self.batches[k]:
            if remaining <= 0:
                break
            take = min(b[0], remaining)
            b[0] -= take
            sold += take
            remaining -= take
        return sold

    # ---- one day: actions = [(price_action, inventory_action), ...] one per product
    def step(self, actions):
        season = V.WEEKDAY_MULT[self.day % 7]
        demand = []
        for k in range(N):
            exp_d = PRODUCTS[k]["demand"] * DEMAND_LIFT[actions[k][0]] * season
            demand.append(max(0, int(self.rng.poisson(exp_d))))

        sold = [self._sell(k, demand[k]) for k in range(N)]
        unmet = [demand[k] - sold[k] for k in range(N)]
        spill_in = [0] * N
        for k in range(N):                               # substitution to the next product
            s = int(SPILL * unmet[k])
            if s > 0:
                nxt = (k + 1) % N
                got = self._sell(nxt, s)
                spill_in[nxt] += got
                unmet[k] -= got
        units = [sold[k] + spill_in[k] for k in range(N)]
        price = [PRODUCTS[k]["price"] * PRICE_MULTIPLIER[actions[k][0]] for k in range(N)]

        wasted = [0] * N                                  # age stock, remove expired units
        for k in range(N):
            kept = []
            for b in self.batches[k]:
                b[1] -= 1
                if b[1] <= 0:
                    wasted[k] += b[0]
                elif b[0] > 0:
                    kept.append(b)
            self.batches[k] = kept

        executed, cut = [None] * N, [0] * N               # reorders, with the shared shelf limit
        total_now = self.total_stock()
        for j in range(N):
            k = (self.day + j) % N                        # rotating priority for scarce space
            want = actions[k][1]
            allowed = max(CAPACITY - total_now, 0)
            if REORDER_QTY[want] > allowed:
                want = [a for a in INV_ACTIONS if REORDER_QTY[a] <= allowed][-1]
                cut[k] = 1
            q = REORDER_QTY[want]
            if q > 0:
                self.batches[k].append([q, PRODUCTS[k]["shelf"]])
                total_now += q
            executed[k] = want

        rewards, infos = [], []
        for k in range(N):
            P = PRODUCTS[k]
            stock_after = self.stock(k)
            lam = (P["price"] - P["cost"]) + GOODWILL
            r_price = units[k] * (price[k] - P["cost"]) - P["cost"] * wasted[k]
            r_inv = -V.HOLD_COST * stock_after - (V.ORDER_FIXED if REORDER_QTY[executed[k]] > 0 else 0.0) - lam * unmet[k]
            rewards.append((r_price, r_inv))
            infos.append(dict(product=P["name"], demand=demand[k], units_sold=units[k], spill_in=spill_in[k],
                              price=price[k], wasted=wasted[k], unmet=unmet[k], stock_after=stock_after,
                              inv_exec=executed[k], cut=cut[k], profit=r_price + r_inv + lam * unmet[k],
                              shelf_used=total_now, r_price=r_price, r_inventory=r_inv))
            self.last_demand[k] = demand[k]
        self.day += 1
        return self.states(), rewards, self.day >= self.horizon, infos
