"""
Two-agent Q-learning with a RICHER state, fixing two weaknesses found while building the app:
  - 'recent demand' was just yesterday's sales (very noisy)      -> smoothed demand estimate (EMA)
  - the agent could not see how many units were about to expire  -> units expiring today
State: stock (3 bins) x days to expiry (3) x smoothed demand (3 bins, split at 9.5 and 15) x units expiring (2).
"""
import numpy as np
from agents import TwoAgentQLearner
from retail_env_v2 import PRICE_ACTIONS, INV_ACTIONS


def discretize_rich(state):
    stock = state["stock"]
    stock_bin = 0 if stock < 10 else (1 if stock < 25 else 2)
    expiry_bin = min(state["days_to_expiry"], 3)
    ema = state["demand_ema"]
    ema_bin = 0 if ema < 9.5 else (1 if ema < 15 else 2)
    exp_bin = 0 if state["expiring"] == 0 else 1
    return (stock_bin, expiry_bin, ema_bin, exp_bin)


class TwoAgentRich(TwoAgentQLearner):
    def act(self, state):
        s = discretize_rich(state)
        if np.random.rand() < self.eps:
            p_idx = np.random.randint(len(PRICE_ACTIONS))
        else:
            p_idx = int(np.argmax(self._rowp(s)))
        if np.random.rand() < self.eps:
            i_idx = np.random.randint(len(INV_ACTIONS))
        else:
            i_idx = int(np.argmax(self._rowi(s, p_idx)))
        return (s, p_idx, i_idx), (PRICE_ACTIONS[p_idx], INV_ACTIONS[i_idx])
