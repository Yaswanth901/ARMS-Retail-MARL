"""Logic behind the new app tabs (kept separate from the screen code so it can be tested without Streamlit)."""
import os
import numpy as np, pandas as pd
import app_core as C, mappo_numpy as M
from retail_env_v2 import BASE_PRICE, PRICE_MULTIPLIER, REORDER_QTY, UNIT_COST, MAX_STOCK

HERE = os.path.dirname(os.path.abspath(__file__))
_AGENT = None
def _mappo():
    global _AGENT
    if _AGENT is None:
        _AGENT = M.MAPPO.load(os.path.join(HERE, "mappo_weights", "seed6.npz"), 6)
    return _AGENT

def advice(stock, expiry, demand=12.0, shelf=4, weekend=False):
    """Recommended price and order for tomorrow, with reasons, safety checks and second opinions."""
    s = dict(stock=int(stock), days_to_expiry=int(expiry), demand_ema=float(demand), recent_demand=float(demand),
             expiring=int(stock) if expiry <= 1 else 0, seasonality=1.15 if weekend else 1.0)
    ag = _mappo(); mp = ag.policy()
    rp, ri, *_ = C.SS_RULE(s); lp, li, *_ = mp(s)
    x = M.features(s)[None]
    pp = M.masked_probs(ag.actor_p.forward(x)[0], M.price_mask(s))[0]
    xi = np.concatenate([x[0], np.eye(3)[int(np.argmax(pp))]])[None]
    conf = float(M.masked_probs(ag.actor_i.forward(xi)[0], M.inv_mask(s))[0].max())
    changed = demand < 0.75 * 12.0 or shelf < 4
    pa, ia = (lp, li) if changed else (rp, ri)
    price, qty = BASE_PRICE * PRICE_MULTIPLIER[pa], REORDER_QTY[ia]
    why = []
    if qty == 0: why.append(f"You have {stock} packets, enough to cover tomorrow, so ordering now would only add cost and risk spoilage.")
    else: why.append(f"Stock ({stock}) is low; ordering {qty} now avoids empty shelves. Each order has a fixed Rs 40 cost, so a full batch is better than small orders.")
    if price < BASE_PRICE: why.append(f"The oldest packets expire in {expiry} day(s); a discount sells them before they are wasted.")
    else: why.append("Regular price: a discount would cut the profit per packet from Rs 15 to about Rs 7.5, so it only pays when packets are about to expire.")
    after = min(stock + qty, MAX_STOCK)
    safety = [f"Price Rs {price:.1f} is {'above' if price >= UNIT_COST else 'BELOW'} the unit cost of Rs {UNIT_COST}" + ("" if price >= UNIT_COST else " (allowed only because stock expires within a day)"),
              f"Shelf after ordering: {after} of {MAX_STOCK} packets" + (" (order trimmed to fit)" if stock + qty > MAX_STOCK else "")]
    mode = "Conditions have changed: using the learned agent" if changed else "Normal conditions: using the proven (s,S) rule"
    return dict(price=price, qty=qty, mode=mode, changed=changed, why=why, safety=safety,
                rule=(BASE_PRICE * PRICE_MULTIPLIER[rp], REORDER_QTY[ri]), learned=(BASE_PRICE * PRICE_MULTIPLIER[lp], REORDER_QTY[li], conf))

# ---------------------------------------------------------------- shop data
def load_shop():
    a, b = os.path.join(HERE, "SIMULATED_shop_month_sales.csv"), os.path.join(HERE, "SIMULATED_shop_month_stock.csv")
    if not (os.path.exists(a) and os.path.exists(b)): return None
    return pd.read_csv(a, parse_dates=["date"]), pd.read_csv(b)

def shop_summary(sales, stock):
    cost = {"Milk packet": 35, "Curd cup": 24, "Bread": 30}
    bills = sales.groupby("bill_id").line_amount.sum()
    wcost = float(sum(r.expired * cost[r["product"]] for _, r in stock.iterrows()))
    handled = stock.sold.sum() + stock.expired.sum()
    return dict(rows=len(sales), bills=int(sales.bill_id.nunique()), days=int(sales.date.nunique()), avg_bill=float(bills.mean()),
                waste_units=int(stock.expired.sum()), waste_share=float(stock.expired.sum() / handled), waste_cost=wcost)

def weekly_pattern(sales):
    b = sales.groupby("date").bill_id.nunique(); wd = b.index.weekday
    base = b[wd < 5].mean(); names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    return pd.DataFrame({"Weekday": names, "Traffic relative to Mon-Fri average": [float(b[wd == k].mean() / base) for k in range(7)]}).set_index("Weekday")

def offer_results(T=100, q=0.3, accept35=0.10, accept15=0.04, days=1500, seed=5):
    """Near-expiry offer vs plain discounts. Customer responses (q, accept...) are ASSUMED."""
    sales, stock = load_shop(); rng = np.random.default_rng(seed)
    cost = {"Milk packet": 35, "Curd cup": 24, "Bread": 30}
    leftover = stock.expired.sum() / stock.date.nunique()
    price = float(sales[sales.category == "perishable"].unit_price.mean())
    sales = sales.assign(hour=sales.time.str[:2].astype(int))
    bills = sales.groupby("bill_id").agg(value=("line_amount", "sum"), hour=("hour", "first"))
    evening = bills[bills.hour >= 17].value.values; eve_n = len(evening) / sales.date.nunique()
    am = float(sales[sales.category == "add-on"].line_margin.sum() / sales[sales.category == "add-on"].line_amount.sum())
    def one(policy):
        L = rng.poisson(leftover); nb = rng.poisson(eve_n); v = rng.choice(evening, nb)
        if policy == "nothing" or L == 0: return 0.0, 0
        if policy in ("d15", "d35"):
            a, f = (accept15, 0.85) if policy == "d15" else (accept35, 0.65)
            n = min(L, rng.binomial(nb, a)); return n * price * f, n
        gift, extra, left = 0, 0.0, L
        for x in v:
            if left == 0: break
            if x >= T:
                if rng.random() < 0.8: left -= 1; gift += 1
            elif x >= T - 50 and rng.random() < q:
                extra += (T - x) * am; left -= 1; gift += 1
        return extra, gift
    rows = []
    for name, pol in [("Do nothing", "nothing"), ("Plain discount 15%", "d15"), ("Plain discount 35%", "d35"), (f"Free unit with a bill of Rs {T}+", "offer")]:
        r = np.array([one(pol) for _ in range(days)])
        rows.append({"Policy": name, "Rs per day": round(float(r[:, 0].mean()), 1), "Rs per month": round(float(r[:, 0].mean() * 30)), "Waste avoided per day (units)": round(float(r[:, 1].mean()), 2)})
    return pd.DataFrame(rows).set_index("Policy"), float(leftover), float(leftover * np.mean([cost[k] for k in cost]))

def read_csv_safe(name):
    p = os.path.join(HERE, name)
    return pd.read_csv(p) if os.path.exists(p) else None


# ================================================================ SHOP ASSISTANT: stock check + pricing + cross-sell + offers
SHELF = {"Milk packet": 4, "Curd cup": 5, "Bread": 4}          # shelf life in days for the perishable products

def product_facts(sales):
    """Per product: average units per weekday, unit price, unit cost (all measured from the bills)."""
    days = sales.date.nunique()
    out = {}
    for p, g in sales.groupby("product"):
        daily = g.groupby("date").qty.sum().reindex(sorted(sales.date.unique()), fill_value=0)
        wd = daily[[d.weekday() < 5 for d in daily.index]]
        out[p] = dict(mean_weekday_units=float(wd.mean()), price=float(g.line_amount.sum() / g.qty.sum()),
                      cost=float(g.unit_cost.iloc[0]), category=g.category.iloc[0],
                      margin_unit=float(g.line_margin.sum() / g.qty.sum()))
    return out

def cross_sell(sales, product, top=3):
    """Add-ons to suggest with `product`. First choice: add-ons bought together MORE than chance (lift of at least 1.05), best margin first.
    If none exists in the data, say so and fall back to the most valuable popular add-on (no special link)."""
    b = sales.pivot_table(index="bill_id", columns="product", values="qty", aggfunc="sum").notna()
    facts = product_facts(sales); rows = []
    for a in b.columns:
        if a == product or facts[a]["category"] != "add-on": continue
        p_a, p_ag = float(b[a].mean()), float(b.loc[b[product], a].mean())
        lift = p_ag / p_a if p_a > 0 else 0.0
        rows.append({"Suggest": a, "Bought together (lift)": round(lift, 2), "Share of these bills that include it": round(p_ag, 2),
                     "Margin per unit (Rs)": round(facts[a]["margin_unit"], 1), "Overall share of bills": round(p_a, 2)})
    df = pd.DataFrame(rows)
    partners = df[df["Bought together (lift)"] >= 1.05].copy()
    if len(partners):
        partners["Score"] = partners["Bought together (lift)"] * partners["Margin per unit (Rs)"]
        out = partners.sort_values("Score", ascending=False).head(top).drop(columns="Score"); out["Why"] = "bought together more than chance"
    else:
        df["Value"] = df["Overall share of bills"] * df["Margin per unit (Rs)"]
        out = df.sort_values("Value", ascending=False).head(2).drop(columns="Value"); out["Why"] = "popular, high-margin add-on (no special link with this product in the data)"
    return out.reset_index(drop=True)

def _evening_threshold(sales):
    s = sales.assign(hour=sales.time.str[:2].astype(int))
    bills = s.groupby("bill_id").agg(value=("line_amount", "sum"), hour=("hour", "first"))
    ev = bills[bills.hour >= 17].value.values
    return int(max(50, round(float(np.percentile(ev, 70)) / 25) * 25))

def plan_product(sales, product, stock, days_left):
    """Decision for ONE perishable product: reorder, price, and (if stock is at risk) an offer with cross-sell partners."""
    f = product_facts(sales)[product]; shelf = SHELF[product]
    mean = f["mean_weekday_units"]; expected = mean * max(days_left, 1)
    at_risk = int(max(0, round(stock - expected)))
    out = dict(product=product, stock=int(stock), days_left=int(days_left), mean_daily=round(mean, 1), expected_sales=round(expected, 1), at_risk=at_risk)
    # --- reorder
    if product == "Milk packet":
        a = advice(stock, days_left, demand=mean, shelf=shelf)
        out.update(order=a["qty"], price=a["price"], mode=a["mode"],
                   method=("learned MAPPO agent (conditions have changed)" if a["changed"] else "tuned (s,S) rule (normal conditions); the learned MAPPO agent gives a second opinion in the Advice tab"))
        floor = f["cost"]
    else:
        s = int(np.ceil(2.0 * mean)); batch = int(min(np.ceil(2.0 * mean), np.floor(0.8 * mean * shelf)))
        out.update(order=(batch if stock <= s else 0), method=f"rule of thumb: order {batch} when stock is {s} or less (about 2 days of demand; not a trained agent)", mode="rule of thumb")
        floor = f["cost"]; out["price"] = f["price"]
    # --- pricing for stock that will probably expire
    out["discount_note"] = "keep the regular price"
    if at_risk >= 2 and days_left <= 2:
        max_disc = max(0.0, (f["price"] - floor) / f["price"])
        d = min(0.35, max_disc)
        if d >= 0.05:
            out["price"] = round(f["price"] * (1 - d), 1); out["discount_note"] = f"{at_risk} packets may expire: offer about {d:.0%} off (never below the cost of Rs {floor:.0f})"
    # --- offer and cross-sell
    out["offer"] = None; out["cross_sell"] = cross_sell(sales, product)
    if at_risk >= 2 and days_left <= 2:
        T = _evening_threshold(sales); tbl, left, _ = offer_results(T=T, q=0.3, accept35=0.10, days=800)
        partner = out["cross_sell"].iloc[0]["Suggest"]
        disc = tbl.loc["Plain discount 35%"]; off = tbl.iloc[3]
        out["offer"] = dict(threshold=T, partner=partner, discount_cash=float(disc["Rs per day"]), discount_waste=float(disc["Waste avoided per day (units)"]),
                            offer_cash=float(off["Rs per day"]), offer_waste=float(off["Waste avoided per day (units)"]),
                            text=(f"Option A, 35% off in the evening: about Rs {disc['Rs per day']:.0f} a day, avoids {disc['Waste avoided per day (units)']:.1f} units of waste. "
                                  f"Option B, one {product.lower()} free with a bill of Rs {T}+ (suggest {partner} to help customers reach it): about Rs {off['Rs per day']:.0f} a day of extra margin, "
                                  f"avoids {off['Waste avoided per day (units)']:.1f} units. A is better for cash, B for waste and bill size. Customer response is assumed: try B on a few days and compare."))
    return out

def shop_plan(rows):
    """rows: list of (product, stock, days_left). Returns one decision per product."""
    shop = load_shop()
    if shop is None: raise FileNotFoundError("Run make_shop_data.py first (or supply your own sales file).")
    sales, _ = shop
    return [plan_product(sales, p, st, dl) for p, st, dl in rows]
