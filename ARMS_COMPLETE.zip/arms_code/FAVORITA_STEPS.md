# Using the real Favorita data (about 30-60 minutes, mostly downloading)

Goal: replace the *assumed* weekly demand pattern with the one measured from real grocery sales, so you can
say "the weekly pattern comes from the Corporacion Favorita data". Only the weekly SHAPE is used. The effect of a
price change stays an assumption, because this data has no price column.

## Choose one dataset

**Option A - item level (matches your submitted document).** Kaggle competition
"Corporacion Favorita Grocery Sales Forecasting".
- Files needed: `train.csv` and `items.csv` (the second one marks which items are perishable).
- `train.csv` is large (several GB once extracted). The Kaggle page may list the files as `.7z` archives.
  If so, install the free tool 7-Zip (7-zip.org), right-click the archive, choose 7-Zip, then "Extract here".
- Needs about 5 GB of free disk space.

**Option B - smaller and easier.** Kaggle competition "Store Sales - Time Series Forecasting", which also uses
Corporacion Favorita's stores. Sales are per product family (DAIRY, BREAD/BAKERY, PRODUCE, ...), not per item.
- File needed: `train.csv` only (about 120 MB, a normal CSV).
- If you use this one, say so in your write-up: "Corporacion Favorita store sales, product-family level".

## Steps

1. Create a free Kaggle account (kaggle.com). Kaggle may ask to verify a phone number before downloads.
2. Open the competition page you chose, go to the **Data** tab, and click **Join Competition / I Understand and Accept**
   (you cannot download until you accept the rules).
3. Download the files (the Data tab has a "Download All" button, or download single files).
4. Make a folder, for example `C:\Users\yaswa\Downloads\favorita`, and put the extracted `train.csv`
   (and `items.csv` for option A) in it.
5. In PowerShell, from the project folder with the environment active:

```
# Option A (item level). --max-rows 40000000 reads roughly the first year only, which is enough and faster
python calibrate_favorita.py --data-dir "C:\Users\yaswa\Downloads\favorita" --max-rows 40000000

# Option B (family level) - detected automatically
python calibrate_favorita.py --data-dir "C:\Users\yaswa\Downloads\favorita"
```

6. It prints the measured weekly pattern (Monday to Sunday), the variance-to-mean ratio, and the promotion lift, and
   saves `demand_profile.json`.
7. Use it:

```
python make_report.py                      # Section 8 of the report now shows the measured pattern
python demo_cli.py --profile --batch 30    # test every method under the measured weekly pattern
python -m streamlit run app.py             # tick "Use the weekly demand pattern measured from Favorita data"
```

## If something goes wrong
- `Cannot find ...train.csv`: the folder path is wrong, or the file is still a `.7z` archive.
- `No rows for store 44`: try another store, for example `--store 1`.
- Anything else: copy the full message and send it.

## What to say about it
"The weekly demand pattern in the simulation was measured from the Corporacion Favorita sales data for perishable
products in one store. The price response remains an assumption, because the dataset contains no prices."
(The script was tested on files generated in the same layout, where it recovered a known pattern; check the first
real run's output for plausibility: most grocery stores sell more on weekends.)
