"""
A fair, hard-to-dismiss baseline: an "order-up-to" rule with its parameters TUNED by grid search.

Rule: each day, order the largest quantity (0 / 10 / 25) that keeps stock at or below TARGET.
      Price: regular, except a discount when stock is about to expire (thresholds tuned too).
Tuning uses its own seeds (500000+); the final number is measured on the fresh test seeds
(900000+) that every other method is also tested on, so nothing is tuned on the test data.

    python tune_baseline.py
"""
import os
BASE = os.path.dirname(os.path.abspath(__file__))
import itertools
import numpy as np
import pandas as pd
from retail_env_v2 import RetailEnvV2, REORDER_QTY, INV_ACTIONS
import train_v2 as T

HORIZON = 60


def make_policy(target, clear_exp, clear_stock, mod_exp):
    def policy(state):
        fits = [i for i in INV_ACTIONS if state["stock"] + REORDER_QTY[i] <= target]
        inv = fits[-1] if fits else "NO_REORDER"
        if state["days_to_expiry"] <= clear_exp and state["stock"] > clear_stock:
            price = "CLEARANCE_DISCOUNT"
        elif state["days_to_expiry"] <= mod_exp:
            price = "MODERATE_DISCOUNT"
        else:
            price = "REGULAR_PRICE"
        return price, inv, 0
    return policy


def mean_profit(policy, seed0, n):
    total = 0.0
    for k in range(n):
        env = RetailEnvV2(HORIZON, seed=seed0 + k)
        s = env.reset()
        for _ in range(HORIZON):
            p, i, _ = policy(s)
            s, _, _, info = env.step(p, i)
            total += info["profit"]
    return total / n


if __name__ == "__main__":
    grid = list(itertools.product(range(15, 46, 3), [0, 1], [0, 5, 10], [1, 2]))
    rows = []
    for target, ce, cs, me in grid:
        rows.append(dict(target=target, clear_exp=ce, clear_stock=cs, mod_exp=me,
                         tuning_profit=mean_profit(make_policy(target, ce, cs, me), 500000, 40)))
    res = pd.DataFrame(rows).sort_values("tuning_profit", ascending=False)
    res.to_csv(os.path.join(BASE, "tuned_baseline_grid.csv"), index=False)
    best = res.iloc[0]
    print(f"Searched {len(grid)} settings on tuning seeds. Best:\n{best.to_string()}\n")

    pol = make_policy(int(best.target), int(best.clear_exp), int(best.clear_stock), int(best.mod_exp))
    ev = T.evaluate(pol)
    print(f"Tuned order-up-to rule on FRESH test seeds: profit Rs {ev['profit'].mean():.0f} per episode, "
          f"wasted {ev['wastage'].mean():.1f}, unmet {ev['stockout'].mean():.1f}")
    print(f"(original rule-based: Rs {T.evaluate(T.rule_policy)['profit'].mean():.0f})")
