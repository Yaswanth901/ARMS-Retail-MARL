# ARMS - start here

Two cooperating RL agents (one prices, one reorders) for a perishable product in a simulated store,
tested honestly against rule-based and tuned classical baselines (including an (s,S) rule).

## 1. Setup (once)
```
cd "C:\Users\yaswa\Downloads\<folder>\arms_code"
pip install -r requirements.txt
```
(Open PowerShell inside the folder that contains `app.py`. If `dir` shows only another `arms_code` folder, `cd arms_code` once more.)

## 2. The one-click way: run everything and get a report
```
python run_all.py --quick      # about 5-10 minutes; reuses saved results for the slowest steps
python run_all.py              # everything from scratch, about 20-30 minutes
```
(or double-click `run_all.bat`). At the end it builds and opens **ARMS_report.html**: one page with every table,
chart and honest conclusion. In the browser press Ctrl+P and choose "Save as PDF" to submit it.
If one step fails, the others still run and the summary tells you which one failed. Send me that line.

## 3. Show it live
```
python demo_cli.py                     # 14-day replay with a plain-English note per day (PowerShell only)
python demo_cli.py --compare           # all 6 methods on the same demand
python demo_cli.py --stress            # 6 harder scenarios (demand up/down, 2-day shelf life, surge, slump)
python demo_cli.py --batch 30          # 30 test episodes: mean and spread
python demo_cli.py --store             # three products (milk, curd, bread) sharing one shelf
python -m streamlit run app.py         # interactive app in the browser (sliders, shock injector, stress tab, retrain button)
```
Use `python -m streamlit` (not plain `streamlit`). If it asks for an email, press Enter.

## 4. Use REAL data (answers "show me the dataset")
1. Make a free Kaggle account, open **Corporacion Favorita Grocery Sales Forecasting**, accept the rules, download `train.csv` and `items.csv` into one folder. (train.csv is very large; a quick trial works with `--max-rows`.)
2. ```
   python calibrate_favorita.py --data-dir "C:\path\to\favorita" --max-rows 20000000
   ```
   It prints the measured weekly pattern, variability and promotion lift and saves `demand_profile.json`.
3. ```
   python demo_cli.py --profile --batch 30
   python make_report.py
   ```
   The app gets a checkbox to use the measured weekly pattern. Only the weekly SHAPE comes from the data; the effect of a
   price change stays an assumption because Favorita has no price column. The script was tested on files I generated in the
   same layout (it recovered the known pattern) but NOT on the real Kaggle files, so send me any error you get.

## 5. What to tell madam (true statements only)
- Built: a simulator with real costs, four learning methods (tabular Q-learning, neural fitted Q-iteration, a neural-network MAPPO written in NumPy,
  and the per-product learners in a three-product store), a safety layer, an interactive app, a PowerShell demo and a reproducible evaluation.
- Found:
  1. Two cooperating agents beat one agent doing both jobs (8 of 8 seeds, revenue-based reward).
  2. Under real profit costs the tabular RL methods showed no reliable winner and did not beat a tuned classical rule.
  3. MAPPO (15 training seeds, one setting, no tuning) averaged about Rs 8,300 and beat the tuned order-up-to rule (Rs 7,811) in 14 of 15 seeds,
     by learning to order in full batches. A tuned (s,S) rule (Rs 8,843) is still better in normal conditions.
  4. When conditions changed (demand down 40%, 2-day shelf life, demand slump), MAPPO beat the (s,S) rule in every saved seed and stayed profitable.
  5. Per-product tabular RL in a three-product store with a shared shelf stayed below the tuned rule at every capacity tested.
- Be upfront: MAPPO receives inputs the rules do not (smoothed demand, units expiring), so its edge cannot be credited to learning alone.
  Everything is simulated; the price response is an assumption.
- Next: calibrate with real Favorita data, test MAPPO in the three-product store, separate the effect of MAPPO's extra inputs from the effect of learning.
- Do NOT say: "RL beats the best baseline" (the (s,S) rule is better in normal conditions), "we used the Favorita data" (until you have run the calibration),
  or that the results describe a real store.

## 6. Where is the RL code?
`agents.py` (Q-learning update), `agents_nfq.py` (neural fitted Q-iteration), `mappo_numpy.py` (MAPPO: actors, centralised critics, PPO clipped loss, GAE;
`python mappo_numpy.py --check` verifies its gradients), `retail_env_v2.py` (environment and rewards), `guardrails.py` (safety layer),
`tune_baseline.py` and `tune_sS.py` (the two classical baselines). `mappo_torch.py` is an older PyTorch draft for the revenue-based reward that has never been run.
See `README.md` for every result and `HOW_TO_RUN.md` for each script. `FAVORITA_STEPS.md` explains the real-data step.

## Not verified here
The Streamlit pages and the HTML report were run and checked for code errors but not seen in a real browser. The Favorita script has not been run on the real
Kaggle files.
