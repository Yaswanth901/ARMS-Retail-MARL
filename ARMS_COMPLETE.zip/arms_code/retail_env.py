"""
Retail Pricing-Inventory MARL Environment
Matches Section 8/9 of the submitted proposal:
  - Pricing Agent acts first: REGULAR_PRICE / MODERATE_DISCOUNT / CLEARANCE_DISCOUNT
  - Inventory Agent acts second, conditioned on Pricing Agent's action:
    NO_REORDER / SMALL_REORDER / FULL_REORDER
  - Role-specific rewards (Section 9.4):
      R_price,t     = Revenue_t - lambda_w * Wastage_t
      R_inventory,t = FulfilledDemand_t - lambda_s * Stockout_t - lambda_e * ExcessInventory_t
"""
import numpy as np

PRICE_ACTIONS = ["REGULAR_PRICE", "MODERATE_DISCOUNT", "CLEARANCE_DISCOUNT"]
PRICE_MULTIPLIER = {"REGULAR_PRICE": 1.0, "MODERATE_DISCOUNT": 0.85, "CLEARANCE_DISCOUNT": 0.65}
# Revenue factor (price x lift) is intentionally NOT >1 for discounts - real perishable-goods
# demand isn't elastic enough for a markdown to pay for itself on revenue alone; discounting
# is a genuine margin sacrifice, only worth it to avoid a larger wastage penalty near expiry.
DEMAND_LIFT = {"REGULAR_PRICE": 1.0, "MODERATE_DISCOUNT": 1.15, "CLEARANCE_DISCOUNT": 1.3}
# -> revenue factor: REGULAR 1.00, MODERATE 0.98, CLEARANCE 0.845

INV_ACTIONS = ["NO_REORDER", "SMALL_REORDER", "FULL_REORDER"]
REORDER_QTY = {"NO_REORDER": 0, "SMALL_REORDER": 10, "FULL_REORDER": 25}

BASE_PRICE = 50.0       # Rs per unit
BASE_DEMAND = 12.0      # mean units/day at regular price, before noise
SHELF_LIFE_DAYS = 4     # perishable: expires after this many days
EXCESS_THRESHOLD = 35   # stock above this counts as "excess" for the inventory penalty

LAMBDA_W = 4.0   # wastage penalty weight (Pricing Agent)
LAMBDA_S = 3.0   # stock-out penalty weight (Inventory Agent)
LAMBDA_E = 2.5   # excess-inventory penalty weight (Inventory Agent)


class RetailEnv:
    """One simulated store, one perishable product. Episode = `horizon` days."""

    def __init__(self, horizon=60, seed=None):
        self.horizon = horizon
        self.rng = np.random.default_rng(seed)
        self.reset()

    def reset(self):
        self.day = 0
        # batches: list of [units_remaining, days_left_until_expiry]
        self.batches = [[20, SHELF_LIFE_DAYS]]
        self.history = []
        return self._state()

    def _stock(self):
        return sum(b[0] for b in self.batches)

    def _days_to_nearest_expiry(self):
        if not self.batches:
            return SHELF_LIFE_DAYS
        return min(b[1] for b in self.batches)

    def _state(self, price_action=None, expected_demand=None):
        seasonality = 1.15 if (self.day % 7) in (5, 6) else 1.0  # weekend lift
        s = {
            "stock": self._stock(),
            "days_to_expiry": self._days_to_nearest_expiry(),
            "recent_demand": self.history[-1]["demand"] if self.history else BASE_DEMAND,
            "seasonality": seasonality,
        }
        if price_action is not None:
            s["selected_price"] = price_action
            s["expected_demand"] = expected_demand
        return s

    def step(self, price_action, inventory_action):
        state0 = self._state()
        seasonality = state0["seasonality"]

        # --- demand realized under the chosen price ---
        expected_demand = BASE_DEMAND * DEMAND_LIFT[price_action] * seasonality
        demand = max(0, self.rng.poisson(expected_demand))

        # --- sell against oldest batches first (FIFO) ---
        stock_before = self._stock()
        units_sold = 0
        remaining_demand = demand
        for b in self.batches:
            if remaining_demand <= 0:
                break
            take = min(b[0], remaining_demand)
            b[0] -= take
            units_sold += take
            remaining_demand -= take
        stockout_units = max(0, demand - units_sold)

        price = BASE_PRICE * PRICE_MULTIPLIER[price_action]
        revenue = units_sold * price

        # --- age stock by one day, remove expired units as wastage ---
        wastage_units = 0
        new_batches = []
        for b in self.batches:
            b[1] -= 1
            if b[1] <= 0:
                wastage_units += b[0]
            elif b[0] > 0:
                new_batches.append(b)
        self.batches = new_batches

        # --- inventory agent reorders ---
        qty = REORDER_QTY[inventory_action]
        if qty > 0:
            self.batches.append([qty, SHELF_LIFE_DAYS])

        stock_after = self._stock()
        excess_units = max(0, stock_after - EXCESS_THRESHOLD)

        # --- role-specific rewards (Section 9.4) ---
        r_price = revenue - LAMBDA_W * wastage_units
        r_inventory = units_sold - LAMBDA_S * stockout_units - LAMBDA_E * excess_units

        info = {
            "day": self.day, "price_action": price_action, "inventory_action": inventory_action,
            "demand": demand, "units_sold": units_sold, "revenue": revenue,
            "wastage": wastage_units, "stockout": stockout_units, "excess": excess_units,
            "stock_before": stock_before, "stock_after": stock_after,
            "r_price": r_price, "r_inventory": r_inventory,
        }
        self.history.append(info)
        self.day += 1
        done = self.day >= self.horizon
        next_state = self._state(price_action, expected_demand)
        return next_state, (r_price, r_inventory), done, info
