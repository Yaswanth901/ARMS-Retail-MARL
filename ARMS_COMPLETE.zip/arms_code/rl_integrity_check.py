"""RL INTEGRITY CHECK: proves the reinforcement-learning code really learns (and shows where RL is, and is not, making decisions).
Run:  python rl_integrity_check.py     (about 2 minutes)
Each test prints PASS or FAIL with the numbers behind it."""
import time, numpy as np, pandas as pd
import train_v2 as T, mappo_numpy as M, app_core as C, features_core as F
from agents import TwoAgentQLearner
from env_continuous import ContinuousRetailEnv
from agents_nfq import TwoAgentNFQ
from retail_env_v2 import RetailEnvV2

RESULTS = []
def check(name, ok, detail):
    RESULTS.append(bool(ok)); print(f"[{'PASS' if ok else 'FAIL'}] {name}\n        {detail}")
mean_profit = lambda pol, guard=False: float(T.evaluate(pol, n=60, guard=guard)["profit"].mean())

print("A. THE LEARNING RULES FOLLOW THE ALGORITHMS\n")
# 1. Q-learning update = Bellman / temporal-difference formula
ag = TwoAgentQLearner(alpha=0.15, gamma=0.95); s, s2 = ("S",), ("S2",)
ag._rowp(s)[0] = 100.0; ag._rowp(s2)[:] = [120, 5, 0]; ag._rowi(s, 0)[1] = 50.0; ag._rowi(s2, 0)[:] = [30, 10, 0]
ag.update(s, 0, 1, 80.0, 20.0, s2, False)
exp_p = 100 + 0.15 * (80 + 0.95 * 120 - 100); exp_i = 50 + 0.15 * (20 + 0.95 * 30 - 50)
ag2 = TwoAgentQLearner(alpha=0.15, gamma=0.95); ag2._rowp(s)[0] = 100.0; ag2.update(s, 0, 0, 80.0, 0.0, s2, True)
check("Q-learning update equals Q + alpha*(r + gamma*max Q' - Q)", np.isclose(ag._rowp(s)[0], exp_p) and np.isclose(ag._rowi(s, 0)[1], exp_i) and np.isclose(ag2._rowp(s)[0], 100 + 0.15 * (80 - 100)),
      f"pricing cell 100 -> {ag._rowp(s)[0]:.2f} (hand calculation {exp_p:.2f}); terminal step uses only the reward")

# 2. PPO clipped objective behaves as the theory says
rng = np.random.default_rng(1); net = M.MLP([9, 8, 8, 3], rng, 0.5); B = 20; x = rng.normal(size=(B, 9)); mask = np.ones((B, 3))
p = M.masked_probs(net.forward(x)[0], mask); a = np.array([rng.choice(3, p=pi) for pi in p]); lp = np.log(p[np.arange(B), a])
def gnorm(shift, adv):
    _, gW, _ = M.actor_loss_and_grads(net, x, mask, a, lp + shift, np.full(B, adv), clip=0.2, ent=0.0); return max(float(np.abs(g).max()) for g in gW)
cases = [("good action, ratio 1.65 (above 1.2)", gnorm(-0.5, +1.0), True), ("good action, ratio 1.0 (inside)", gnorm(0.0, +1.0), False),
         ("bad action, ratio 0.61 (below 0.8)", gnorm(+0.5, -1.0), True), ("bad action, ratio 1.65 (wrong way)", gnorm(-0.5, -1.0), False)]
ok = all((g == 0.0) == should_zero for _, g, should_zero in cases)
check("PPO clip: gradient is zero when the policy has already moved past the clip range, and not otherwise", ok,
      "; ".join(f"{n}: gradient {'ZERO' if g == 0 else 'non-zero'}" for n, g, _ in cases))
# 3. hand-written gradients match numerical gradients
check("MAPPO gradients match finite differences (backpropagation is correct)", M.gradient_check(), "error limit 1e-4 (printed above)")

print("\nB. THE AGENTS REALLY LEARN FROM REWARD (compared with doing things at random)\n")
np.random.seed(0); t0 = time.time()
df, q_agent = T.run_two(400, True); q_agent.eps = 0.0
rand_agent = TwoAgentQLearner(eps=1.0); rand_pol = lambda st: (lambda r: (r[1][0], r[1][1], 0))(rand_agent.act(st))
rp, qp = mean_profit(rand_pol, True), mean_profit(T.greedy_policy(q_agent), True)
check("Q-learning: after 400 episodes it earns far more than random choices (same safety guardrails, fresh test episodes)", qp > rp + 1000,
      f"random policy Rs {rp:,.0f}  ->  trained Q-learning Rs {qp:,.0f} per episode ({time.time()-t0:.0f}s); Q-table has {len(q_agent.Qp)} pricing states and {len(q_agent.Qi)} inventory entries")

# NFQ (neural fitted Q-iteration) on its own environment
t0 = time.time(); np.random.seed(123)
agent = TwoAgentNFQ()
import train_nfq as TN
dfn, nfq = TN.run_two_nfq(150)
def nfq_eval(ag, eps):
    ag.eps = eps; tot = []
    for k in range(15):
        env = ContinuousRetailEnv(horizon=60, seed=777000 + k); obs = env.reset(); r = 0.0
        for _ in range(60):
            p_idx, i_idx, *_ = ag.act(obs); obs, (rp_, ri_), _, _ = env.step(p_idx, i_idx); r += rp_ + ri_
        tot.append(r)
    return float(np.mean(tot))
rnd_n = nfq_eval(TwoAgentNFQ(), 1.0); trn_n = nfq_eval(nfq, 0.0)
check("Neural fitted Q-iteration: after 150 episodes its greedy policy beats random choices", trn_n > rnd_n,
      f"random reward {rnd_n:,.0f}  ->  trained NFQ reward {trn_n:,.0f} on the same 15 fresh episodes ({time.time()-t0:.0f}s)")

t0 = time.time()
ag0 = M.MAPPO(seed=100); before = mean_profit(ag0.policy())
agm, curve = M.train(seed=100, iterations=30); after = mean_profit(agm.policy())
check("MAPPO: starting from random networks, 30 iterations of PPO lift both training profit and fresh-episode profit", after > before + 1000 and curve[-1] > curve[0] + 1000,
      f"training profit {curve[0]:,.0f} -> {curve[-1]:,.0f}; fresh-episode profit {before:,.0f} (untrained) -> {after:,.0f} (trained) ({time.time()-t0:.0f}s)")

print("\nC. CONTROL TEST: LEARNING COMES FROM THE REWARD, NOT FROM A BUG  (6 seeds each; random networks vary a lot, so one seed proves nothing)\n")
class NoiseEnv(RetailEnvV2):                      # same store, but the reward the agent receives is pure random noise
    def __init__(self, *a, **k): super().__init__(*a, **k); self._r = np.random.default_rng(k.get("seed", 0) + 7)
    def step(self, p, i):
        s, _, d, info = super().step(p, i); return s, (self._r.normal(0, 50), self._r.normal(0, 50)), d, info
real_env = M.RetailEnvV2; res = {"untrained": [], "trained on random-noise rewards": [], "trained on the real reward": []}
ev40 = lambda a_: float(T.evaluate(a_.policy(), n=40)["profit"].mean())
for sd in range(200, 206):
    res["untrained"].append(ev40(M.MAPPO(seed=sd)))
    M.RetailEnvV2 = NoiseEnv
    try: res["trained on random-noise rewards"].append(ev40(M.train(seed=sd, iterations=30)[0]))
    finally: M.RetailEnvV2 = real_env
    res["trained on the real reward"].append(ev40(M.train(seed=sd, iterations=30)[0]))
for k, v in res.items(): print(f"        {k:34s} mean Rs {np.mean(v):7,.0f}   per seed {[round(x) for x in v]}")
u, n_, r_ = (np.mean(res[k]) for k in res)
check("Training on random rewards does NOT help; training on the real reward helps in every seed", r_ > n_ + 2000 and abs(n_ - u) < 2000 and min(res["trained on the real reward"]) > max(n_, u),
      f"untrained Rs {u:,.0f} | random-noise rewards Rs {n_:,.0f} | real reward Rs {r_:,.0f}; the real-reward agents are tightly grouped and all above the others")

print("\nD. THE SAVED AGENTS USED IN THE DEMO ARE REALLY TRAINED NETWORKS\n")
saved = M.MAPPO.load("mappo_weights/seed6.npz", 6); init = M.MAPPO(seed=6)
diff = np.mean([np.abs(a - b).mean() / (np.abs(b).mean() + 1e-9) for a, b in zip(saved.actor_i.W, init.actor_i.W)])
polS = saved.policy(); st = lambda stock: dict(stock=stock, days_to_expiry=4, demand_ema=12.0, recent_demand=12.0, expiring=0, seasonality=1.0)
acts = {k: polS(st(k))[1] for k in (0, 10, 30, 40)}
check("Saved MAPPO (seed 6): weights are far from random initialisation, and decisions depend on the state", diff > 0.5 and len(set(acts.values())) > 1,
      f"average weight change {diff:.1f}x from initialisation; reorder by stock level: {acts}; fresh-episode profit Rs {mean_profit(polS):,.0f}")

print("\nE. WHERE RL ACTUALLY MAKES THE DECISION (read this honestly)\n")
a_norm = F.advice(18, 2, 12.0, 4); a_chg = F.advice(30, 4, 6.0, 4)
print("   Normal conditions (demand 12, shelf 4)  -> decision comes from:", "the (s,S) RULE" if not a_norm["changed"] else "the learned agent")
print("   Demand falls (6 a day) or shelf < 4     -> decision comes from:", "the LEARNED MAPPO agent" if a_chg["changed"] else "the rule")
print("   Shop assistant: milk follows the same rule/agent switch; curd and bread use a simple rule of thumb (no learning)")
print("   Results tables, stress tests, 'MAPPO' and 'Two-Agent RL' methods in the app: decisions come from trained RL agents")

print(f"\nSUMMARY: {sum(RESULTS)} of {len(RESULTS)} tests passed")
