"""MONEY-SAVED REPORT: turns profit, waste and lost sales into rupees per month for ONE perishable product (simulated shop).
Compares the original rule, the tuned (s,S) rule, MAPPO and the drift-aware hybrid in three situations.
A month is approximated as half of a 60-day run.   Run:  python money_saved_report.py   (about 1 minute)"""
import numpy as np, pandas as pd, app_core as C, mappo_numpy as M, retail_env_v2 as E, train_v2 as T
mp = M.MAPPO.load("mappo_weights/seed6.npz", 6).policy()
def hybrid(s):
    return mp(s) if (s["demand_ema"] < 0.75 * 12.0 or E.SHELF_LIFE_DAYS < 4) else C.SS_RULE(s)
METHODS = [("Original rule", T.rule_policy), ("Tuned (s,S) rule", C.SS_RULE), ("MAPPO", mp), ("Drift-aware hybrid", hybrid)]
SCEN = [("Normal shop (12 a day, 4-day shelf life)", 12, 4), ("Quieter shop (7 a day)", 7, 4), ("Short shelf life (2 days)", 12, 2)]
rows = []
for sname, demand, shelf in SCEN:
    res = {}
    for name, pol in METHODS:
        prof, wst, unm = [], [], []
        for k in range(30):
            u = np.random.default_rng(900000 + k).random(60)
            with C.scenario(demand, shelf):
                env = C.make_env(60, u, None); s = env.reset(); p_, w_, m_ = 0.0, 0, 0
                for _ in range(60):
                    p, i, *_ = pol(s); s, _, _, info = env.step(p, i); p_ += info["profit"]; w_ += info["wastage"]; m_ += info["stockout"]
            prof.append(p_); wst.append(w_); unm.append(m_)
        res[name] = (np.mean(prof) / 2, np.mean(wst) / 2, np.mean(unm) / 2)          # per 30 days
    base = res["Original rule"][0]
    print(f"\n{sname}\n{'Method':22s} {'Profit/month':>12s} {'vs original':>12s} {'Wasted units':>13s} {'Unmet units':>12s} {'Lost-sales margin':>18s}")
    for name, (p, w, m) in res.items():
        print(f"{name:22s} {p:12,.0f} {p-base:+12,.0f} {w:13.1f} {m:12.1f} {m*15:18,.0f}")
        rows.append(dict(situation=sname, method=name, profit_per_month=round(p), change_vs_original=round(p - base), wasted_units=round(w, 1), unmet_units=round(m, 1), lost_sales_margin=round(m * 15)))
pd.DataFrame(rows).to_csv("money_saved_report.csv", index=False)
print("\nValues are rupees per month for ONE product in the simulator (lost-sales margin = unmet units x Rs 15). Saved to money_saved_report.csv.")
