# ARMS: coordinated RL for retail pricing and inventory (22AIE401, Amrita Vishwa Vidyapeetham)

Team: M.V Yaswanth Rahul, S. Vidish Kumar, E. Siddartha. Python project; run commands in PowerShell with the `arms_env` virtual environment active.

## What this project is
A simulated store sells one perishable product (cost Rs 35, price Rs 50, 4-day shelf life, Poisson demand about 12 a day, +15% weekends).
Two cooperating agents choose a price tier and a reorder size each day. Methods compared: original rule, tuned order-up-to rule, tuned (s,S) rule,
single/two-agent Q-learning (+guardrails, +fallback), neural fitted Q-iteration, MAPPO (hand-written NumPy, `mappo_numpy.py`), plus a drift-aware hybrid.

## Ground rules (important)
- Be honest. The tuned (s,S) rule is the best method in normal conditions (Rs 8,843 per 60-day episode); MAPPO averages Rs 8,335 over 15 seeds.
  Learned pricing adds nothing measurable (forcing regular price earned slightly more). Never claim RL beats everything.
- All shop data is SIMULATED (files named SIMULATED_...). Customer responses to offers are ASSUMED. Do not present them as real.
- Do not put a real dataset name on slides. Do not claim "nobody has done this"; say "not seen in the papers we reviewed".
- Do not change reported numbers without rerunning the script that produces them.

## Key commands
| Command | Expected |
|---|---|
| `python final_tests.py` | `SUMMARY: 39 of 39 tests passed` |
| `python rl_integrity_check.py` | `SUMMARY: 8 of 8 tests passed` |
| `python test_app.py --buttons` | `exception: none | page errors: none` |
| `python -m streamlit run app.py` | 8 tabs: Live replay, Compare, Stress test, 3 products, Shop assistant, Offers, Research, About |
See README.md for every other command. Experiments resume from their CSV; delete `results_*.csv` or `perf_*.csv` to restart.

## File map
Environments: `retail_env_v2.py`, `retail_env_v3.py` (stock by age, delays, price response, fine discounts), `retail_env_multi.py` (3 products).
Agents: `agents.py` (tabular), `agents_nfq.py`, `mappo_numpy.py` (main), `mappo_v3.py`, `mappo_multi.py`, `baselines_rl.py` (DQN, Double DQN, single-agent PPO, trainers).
Evaluation: `performance_suite.py`, `select_entropy.py`, `make_figures.py`, `collect_numbers.py`, `experiments_v3.py`. Diagrams: `make_diagrams.py`. Documents: `build_docs/`.
App: `app.py`, `app_core.py`, `app_pages.py`, `features_core.py`. Tools: `shop_assistant.py`, `advise.py`, `offer_bandit.py`, `estimate_price_response.py`, `calibrate_from_sales.py`.

## Findings to keep honest
Primary metric = designed return = profit minus 20 per unmet unit (profit is reported separately). Tuned (s,S) rule is best on the seen shop; DQN, Double DQN, PPO, MAPPO are within about 1% of each other; MAPPO has the best unseen-shop return.
The pricing critic must not see its own action (fixed; the earlier design is in legacy_critic_results/). Entropy 0.1 was chosen on validation episodes. In the 3-product store MAPPO is below both rules on return. Cross-play shows independently trained teams are interchangeable; the price message gives no measurable coordination benefit. A service-constrained (Lagrangian) MAPPO was tried and failed. All data are simulated.

## Open tasks
1. Calibrate with real bills and run a pilot; 2. validation-based checkpoint selection; 3. exact dynamic-programming benchmark; 4. reward-weight and learning-rate/clip sensitivity with the corrected critic; 5. longer training for the 3-product MAPPO; 6. open the app in a real browser (it was tested with a stand-in for Streamlit).
