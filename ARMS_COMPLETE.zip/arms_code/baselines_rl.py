"""
The other RL algorithms madam asked us to compare with, written with the SAME NumPy networks, the SAME 6 inputs and the SAME training budget as MAPPO:
  DQN         : replay buffer + target network, one agent choosing the joint (price, reorder) action (9 actions)
  Double DQN  : as DQN, but the next action is chosen by the online network and evaluated by the target network
  PPO         : one agent, one actor over the 9 joint actions, one critic, reward = pricing + inventory reward
  Q-learning  : the tabular two-agent learner already in agents.py (with guardrails)
Every trainer returns (policy, curve) where curve = [(episodes seen, mean profit on fixed evaluation episodes), ...] and policy(state) -> (price index, reorder index).
"""
import copy, time
import numpy as np
import mappo_numpy as M
import mappo_v3 as W
import retail_env_v2 as V
from retail_env_v3 import RetailEnvV3, LEGACY_LEVELS
from mappo_v3 import f_extras, price_mask, HORIZON, REWARD_SCALE

NA = 9
def due(e, sched): return (e in sched) if not isinstance(sched, int) else (e % sched == 0)
def joint_mask(s): return np.outer(price_mask(s, LEGACY_LEVELS), M.inv_mask(s)).reshape(-1)


class DQN:
    def __init__(self, seed=0, double=False, hidden=64, lr=1e-3, gamma=0.97, size=30000, batch=64, target_every=400, learn_start=600, train_every=4, eps_end=0.05, eps_steps=35000):
        self.rng = np.random.default_rng(seed); self.double = double
        self.q = M.MLP([6, hidden, hidden, NA], self.rng, 1.0); self.qt = copy.deepcopy(self.q)
        self.lr, self.gamma, self.batch, self.target_every, self.learn_start, self.train_every = lr, gamma, batch, target_every, learn_start, train_every
        self.eps_end, self.eps_steps, self.size = eps_end, eps_steps, size
        self.X = np.zeros((size, 6)); self.A = np.zeros(size, int); self.R = np.zeros(size); self.X2 = np.zeros((size, 6)); self.M2 = np.zeros((size, NA)); self.D = np.zeros(size)
        self.n = self.ptr = self.steps = 0

    def eps(self): return max(self.eps_end, 1.0 - (1.0 - self.eps_end) * self.steps / self.eps_steps)

    def act(self, s, greedy=False):
        x = np.array(f_extras(s)); mask = joint_mask(s)
        if not greedy and self.rng.random() < self.eps(): a = int(self.rng.choice(np.flatnonzero(mask)))
        else: a = int(np.argmax(np.where(mask > 0, self.q.forward(x[None])[0][0], -1e9)))
        return a, x

    def remember(self, x, a, r, x2, m2, d):
        i = self.ptr; self.X[i], self.A[i], self.R[i], self.X2[i], self.M2[i], self.D[i] = x, a, r, x2, m2, d
        self.ptr = (self.ptr + 1) % self.size; self.n = min(self.n + 1, self.size)

    def learn(self):
        b = self.rng.integers(0, self.n, self.batch); X, A, R, X2, M2, D = self.X[b], self.A[b], self.R[b], self.X2[b], self.M2[b], self.D[b]
        qt = np.where(M2 > 0, self.qt.forward(X2)[0], -1e9)
        if self.double: a2 = np.argmax(np.where(M2 > 0, self.q.forward(X2)[0], -1e9), axis=1); nxt = qt[np.arange(self.batch), a2]
        else: nxt = qt.max(axis=1)
        y = R + self.gamma * (1.0 - D) * nxt
        out, acts = self.q.forward(X); err = out[np.arange(self.batch), A] - y
        dout = np.zeros_like(out); dout[np.arange(self.batch), A] = 2.0 * err / self.batch
        gW, gb = self.q.backward(acts, dout); self.q.adam(gW, gb, self.lr, max_norm=10.0)

    def sync(self): self.qt.W = [w.copy() for w in self.q.W]; self.qt.b = [b.copy() for b in self.q.b]
    def policy(self): return lambda s: divmod(self.act(s, True)[0], 3)
    def n_params(self): return int(sum(w.size for w in self.q.W) + sum(b.size for b in self.q.b))


def train_dqn(seed, episodes, eval_every, eval_fn, double=False):
    ag = DQN(seed, double); curve = []
    for ep in range(episodes):
        if due(ep, eval_every): curve.append((ep, eval_fn(ag.policy())))
        env = RetailEnvV3(HORIZON, seed=seed * 1_000_000 + ep); s = env.reset()
        for t in range(HORIZON):
            a, x = ag.act(s); p, i = divmod(a, 3); s2, (rp, ri), done, _ = env.step(p, i)
            ag.remember(x, a, (rp + ri) * REWARD_SCALE, np.array(f_extras(s2)), joint_mask(s2), float(done)); ag.steps += 1
            if ag.steps >= ag.learn_start and ag.steps % ag.train_every == 0: ag.learn()
            if ag.steps % ag.target_every == 0: ag.sync()
            s = s2
    curve.append((episodes, eval_fn(ag.policy()))); return ag, curve


class PPOSingle:
    def __init__(self, seed=0, hidden=64, lr=1e-3, gamma=0.97, lam=0.95, clip=0.2, epochs=4, minibatch=256, ent=M._selected_entropy("PPO (single agent)")):
        self.rng = np.random.default_rng(seed); r = self.rng
        self.actor = M.MLP([6, hidden, hidden, NA], r, 0.01); self.crit = M.MLP([6, hidden, hidden, 1], r, 1.0)
        self.lr, self.gamma, self.lam, self.clip, self.epochs, self.minibatch, self.ent = lr, gamma, lam, clip, epochs, minibatch, ent

    def act(self, s, greedy=False):
        x = np.array(f_extras(s))[None]; mask = joint_mask(s); p = M.masked_probs(self.actor.forward(x)[0], mask)[0]
        if greedy: return int(np.argmax(p))
        a = int(self.rng.choice(NA, p=p)); return dict(x=x[0], m=mask, a=a, lp=float(np.log(p[a] + 1e-12)), v=float(self.crit.forward(x)[0][0, 0]))

    def update(self, episodes):
        cols = {k: [] for k in ("x", "m", "a", "lp")}; adv, ret = [], []
        for ep in episodes:
            for k in cols: cols[k] += [st[k] for st in ep["steps"]]
            v = [st["v"] for st in ep["steps"]]; T = len(v); a_ = np.zeros(T); g = 0.0
            for t in reversed(range(T)):
                nv = 0.0 if t == T - 1 else v[t + 1]; g = (ep["r"][t] + self.gamma * nv - v[t]) + self.gamma * self.lam * g; a_[t] = g
            adv.append(a_); ret.append(a_ + np.array(v))
        D = {k: np.array(v) for k, v in cols.items()}; adv, ret = np.concatenate(adv), np.concatenate(ret); adv = (adv - adv.mean()) / (adv.std() + 1e-8); n = len(adv)
        for _ in range(self.epochs):
            idx = self.rng.permutation(n)
            for lo in range(0, n, self.minibatch):
                b = idx[lo:lo + self.minibatch]
                _, gW, gb = M.actor_loss_and_grads(self.actor, D["x"][b], D["m"][b], D["a"][b], D["lp"][b], adv[b], self.clip, self.ent); self.actor.adam(gW, gb, self.lr)
                _, gW, gb = M.critic_loss_and_grads(self.crit, D["x"][b], ret[b]); self.crit.adam(gW, gb, self.lr)

    def policy(self): return lambda s: divmod(self.act(s, True), 3)
    def n_params(self): return int(sum(w.size + 0 for w in self.actor.W) + sum(b.size for b in self.actor.b))


def train_ppo(seed, episodes, eval_every, eval_fn, per_iter=16, **hp):
    ag = PPOSingle(seed, **hp); curve = []
    for it in range(episodes // per_iter):
        if due(it * per_iter, eval_every): curve.append((it * per_iter, eval_fn(ag.policy())))
        eps = []
        for j in range(per_iter):
            env = RetailEnvV3(HORIZON, seed=seed * 1_000_000 + it * 1000 + j); s = env.reset(); steps, r = [], []
            for _ in range(HORIZON):
                d = ag.act(s); s, (rp, ri), _, _ = env.step(*divmod(d["a"], 3)); steps.append(d); r.append((rp + ri) * REWARD_SCALE)
            eps.append(dict(steps=steps, r=r))
        ag.update(eps)
    curve.append((episodes, eval_fn(ag.policy()))); return ag, curve


def train_mappo(seed, episodes, eval_every, eval_fn, per_iter=16, feat="extras", **hp):
    ag = W.MAPPOv3(seed, feat, **hp); curve = []
    for it in range(episodes // per_iter):
        if due(it * per_iter, eval_every): curve.append((it * per_iter, eval_fn(ag.policy())))
        eps, _ = W.rollout(ag, seed, it, per_iter, {}); ag.update(eps)
        if ag.service_target is not None: um_ = float(np.mean([e["unmet"] for e in eps])); ag.lam = min(ag.lam_max, max(0.0, ag.lam + ag.dual_lr * (um_ - ag.service_target))); ag.hist = getattr(ag, "hist", []) + [(it, round(ag.lam, 2), round(um_, 1))]   # dual ascent, multiplier capped
    curve.append((episodes, eval_fn(ag.policy()))); return ag, curve


def train_qlearning(seed, episodes, eval_every, eval_fn, guard=True):
    from agents import TwoAgentQLearner, discretize
    from guardrails import apply_guardrails
    ag = TwoAgentQLearner(); curve = []
    def pol(s):
        e, ag.eps = ag.eps, 0.0; (_, _, _), (p, i) = ag.act(s); ag.eps = e
        if guard: p, i, _ = apply_guardrails(s, p, i)
        return V.PRICE_ACTIONS.index(p), V.INV_ACTIONS.index(i)
    for ep in range(episodes):
        if due(ep, eval_every): curve.append((ep, eval_fn(pol)))
        env = RetailEnvV3(HORIZON, seed=seed * 1_000_000 + ep); s = env.reset()
        for _ in range(HORIZON):
            (s_disc, p_idx, i_idx), (p, i) = ag.act(s)
            if guard:
                p, i, _ = apply_guardrails(s, p, i); p_idx, i_idx = V.PRICE_ACTIONS.index(p), V.INV_ACTIONS.index(i)
            s_next, (rp, ri), done, _ = env.step(p_idx, i_idx); ag.update(s_disc, p_idx, i_idx, rp, ri, discretize(s_next), done); s = s_next
        ag.decay()
    curve.append((episodes, eval_fn(pol))); ag.policy_fn = pol; return ag, curve
