"""Collects every number used by the report and the presentation into deck_data.json (single source of truth).   python collect_numbers.py"""
import json, os
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); rd = lambda n: pd.read_csv(os.path.join(HERE, n)) if os.path.exists(os.path.join(HERE, n)) else None
D = json.load(open(os.path.join(HERE, "perf_summary.json")))
def ms(g): g = pd.Series(g).astype(float); return [float(g.mean()), float(g.std(ddof=1)) if len(g) > 1 else 0.0, int(len(g))]
m = rd("mappo_results_all.csv")
if m is not None: D["main15"] = dict(mean=float(m.profit.mean()), sd=float(m.profit.std(ddof=1)), n=int(len(m)), unmet=float(m.unmet.mean()), min=float(m.profit.min()), max=float(m.profit.max()))
old = rd("legacy_critic_results/mappo_results_all.csv")
if old is not None: D["legacy15"] = dict(mean=float(old.profit.mean()), sd=float(old.profit.std(ddof=1)), n=int(len(old)))
h = rd("hybrid_results.csv")
if h is not None: D["hybrid"] = {n: dict(rule=float(g.tuned_sS_rule.mean()), mappo=float(g.MAPPO.mean()), hybrid=float(g.drift_aware_hybrid.mean())) for n, g in h.groupby("scenario_set", sort=False)}
mo = rd("money_saved_report.csv")
if mo is not None: D["money"] = mo.to_dict("records")
def table(df, by, extra=()):
    out = []
    for k, g in df.groupby(by, sort=False):
        k = k if isinstance(k, tuple) else (k,); row = dict(zip(by if isinstance(by, list) else [by], k)); row["ret"] = ms(g.profit - 20 * g.unmet); row["profit"] = ms(g.profit)[0]
        for c in ("wasted", "unmet", "discount_days"): row[c] = float(g[c].mean()) if c in g else None
        out.append(row)
    return out
for name, key, by in (("results_ablation.csv", "ext_inputs", ["method", "scenario"]), ("results_delays.csv", "ext_delays", ["method"]), ("results_pricing.csv", "ext_pricing", ["method", "elasticity"]), ("results_pricing_waste.csv", "ext_pricing_waste", ["method"]), ("results_multi_mappo.csv", "ext_multi", ["method"])):
    d = rd(name)
    if d is not None: d = d.copy(); d["method"] = d["method"].astype(str); D[key] = table(d, by)
b = rd("results_offer_bandit.csv")
if b is not None: D["bandit"] = b[(b.waste_value == 0)].to_dict("records")
pj = os.path.join(HERE, "price_response.json")
if os.path.exists(pj): D["price"] = json.load(open(pj))
for key, fn in (("ma", "ma_metrics.json"), ("ma_quiet", "ma_metrics_quiet.json")):
    p = os.path.join(HERE, fn)
    if os.path.exists(p): D[key] = json.load(open(p))
sn = rd("results_sensitivity.csv")
if sn is not None:
    sn = sn.copy(); sn["ret"] = sn.profit - 20 * sn.unmet; D["sens"] = [dict(method=k[0], scenario=k[1], ret=ms(g.ret)) for k, g in sn.groupby(["method", "scenario"], sort=False)]
mk = os.path.join(HERE, "results_markov_weekday.json")
if os.path.exists(mk): D["markov"] = json.load(open(mk))["markov"]["Seen: normal shop"][0]
json.dump(D, open(os.path.join(HERE, "deck_data.json"), "w"), indent=1, default=float); print("deck_data.json keys:", list(D))
