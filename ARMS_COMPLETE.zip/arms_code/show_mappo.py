"""Shows what the trained MAPPO agent (seed 6) decides in different store situations.
Run:  python show_mappo.py"""
import numpy as np
import mappo_numpy as M

ag = M.MAPPO.load("mappo_weights/seed6.npz", 6)
sizes = lambda net: [net.W[0].shape[0]] + [w.shape[1] for w in net.W]
nparams = lambda net: sum(w.size for w in net.W) + sum(b.size for b in net.b)
print("MAPPO agent (seed 6): two actors + two critics, all hand-written NumPy networks")
print(f"  pricing actor   : {sizes(ag.actor_p)}  ({nparams(ag.actor_p)} weights)")
print(f"  inventory actor : {sizes(ag.actor_i)}  ({nparams(ag.actor_i)} weights)")
print(f"  critics         : {sizes(ag.crit_p)} and {sizes(ag.crit_i)} (used only in training)\n")

def state(stock, expiry, demand=12.0):
    return dict(stock=stock, days_to_expiry=expiry, demand_ema=demand, expiring=0 if expiry > 1 else stock,
                seasonality=1.0, recent_demand=demand)

print("Policy: what the two actors choose (greedy), and how sure they are")
print(f"{'Stock':>5} {'Days left':>9} | {'Price':>10} {'P(price)':>9} | {'Reorder':>10} {'P(reorder)':>10}")
for stock in (0, 5, 10, 15, 20, 26, 30, 40):
    for expiry in (4, 1):
        s = state(stock, expiry)
        x = M.features(s)[None]
        pp = M.masked_probs(ag.actor_p.forward(x)[0], M.price_mask(s))[0]
        a_p = int(np.argmax(pp))
        xi = np.concatenate([x[0], np.eye(3)[a_p]])[None]
        pi = M.masked_probs(ag.actor_i.forward(xi)[0], M.inv_mask(s))[0]
        a_i = int(np.argmax(pi))
        print(f"{stock:5d} {expiry:9d} | {M.PRICE_ACTIONS[a_p].replace('_PRICE','').replace('_DISCOUNT',''):>10} {pp[a_p]:9.2f} | {M.INV_ACTIONS[a_i].replace('_REORDER',''):>10} {pi[a_i]:10.2f}")
print("\nRead it as: low stock -> order a full batch; enough stock -> wait. That batch rule was learned from reward, not written by us.")
