"""
Neural Fitted Q-Iteration (NFQ) - Riedmiller, 2005, "Neural Fitted Q Iteration -
First Experiences with a Data Efficient Neural Reinforcement Learning Method."

A real deep-RL method: a neural network approximates Q(state, action) instead
of a lookup table, trained by repeated batch fitting on accumulated experience
(Fitted Q-Iteration), rather than one gradient step per transition like DQN's
online updates. It's the right published RL algorithm to use when a true online
deep-RL stack (e.g. PyTorch) isn't available, and it runs on plain scikit-learn -
which IS available in this sandbox, unlike torch.

Two agents:
  SingleAgentNFQ  - one network, one joint 9-action Q-table (3 price x 3 inventory)
  TwoAgentNFQ     - two INDEPENDENT neural networks, each with its own replay buffer
                    (pricing; inventory conditioned on pricing's one-hot action).
                    This is independent learning with sequential action-conditioning,
                    NOT CTDE - there is no centralized critic here. The true CTDE
                    method (centralized critic) is MAPPO in mappo_torch.py.
"""
import numpy as np
from sklearn.neural_network import MLPRegressor
from env_continuous import PRICE_ACTIONS, INV_ACTIONS


def make_net():
    return MLPRegressor(hidden_layer_sizes=(32, 32), activation="relu",
                         solver="adam", warm_start=True, max_iter=300,
                         learning_rate_init=1e-3, random_state=0)


class SingleAgentNFQ:
    JOINT_ACTIONS = [(p, i) for p in range(3) for i in range(3)]

    def __init__(self, eps=1.0, eps_decay=0.995, eps_min=0.05, gamma=0.97):
        self.net = make_net()
        self.fitted = False
        self.eps, self.eps_decay, self.eps_min, self.gamma = eps, eps_decay, eps_min, gamma
        self.buffer = []  # (obs, joint_idx, reward, next_obs, done)

    def act(self, obs):
        if (not self.fitted) or np.random.rand() < self.eps:
            idx = np.random.randint(9)
        else:
            q = self.net.predict(obs.reshape(1, -1))[0]
            idx = int(np.argmax(q))
        p_idx, i_idx = self.JOINT_ACTIONS[idx]
        return idx, PRICE_ACTIONS[p_idx], INV_ACTIONS[i_idx]

    def remember(self, obs, idx, reward, next_obs, done):
        self.buffer.append((obs, idx, reward, next_obs, done))

    def fit_iteration(self, max_buffer=6000):
        if len(self.buffer) < 200:
            return
        self.buffer = self.buffer[-max_buffer:]
        obs = np.array([b[0] for b in self.buffer])
        idx = np.array([b[1] for b in self.buffer])
        r = np.array([b[2] for b in self.buffer], dtype=np.float32)
        next_obs = np.array([b[3] for b in self.buffer])
        done = np.array([b[4] for b in self.buffer], dtype=np.float32)

        if self.fitted:
            q_all = self.net.predict(obs)
            next_q = self.net.predict(next_obs).max(axis=1)
        else:
            q_all = np.zeros((len(obs), 9))
            next_q = np.zeros(len(obs))
        target = q_all.copy()
        target[np.arange(len(obs)), idx] = r + self.gamma * next_q * (1 - done)
        self.net.fit(obs, target)
        self.fitted = True

    def decay(self):
        self.eps = max(self.eps_min, self.eps * self.eps_decay)


class TwoAgentNFQ:
    def __init__(self, eps=1.0, eps_decay=0.995, eps_min=0.05, gamma=0.97):
        self.net_p = make_net()   # pricing: input = obs (4,)
        self.net_i = make_net()   # inventory: input = obs + price one-hot (7,)
        self.fitted_p, self.fitted_i = False, False
        self.eps, self.eps_decay, self.eps_min, self.gamma = eps, eps_decay, eps_min, gamma
        self.buffer_p, self.buffer_i = [], []

    def act(self, obs):
        if (not self.fitted_p) or np.random.rand() < self.eps:
            p_idx = np.random.randint(3)
        else:
            p_idx = int(np.argmax(self.net_p.predict(obs.reshape(1, -1))[0]))
        p_onehot = np.eye(3)[p_idx]
        inv_in = np.concatenate([obs, p_onehot])

        if (not self.fitted_i) or np.random.rand() < self.eps:
            i_idx = np.random.randint(3)
        else:
            i_idx = int(np.argmax(self.net_i.predict(inv_in.reshape(1, -1))[0]))
        return p_idx, i_idx, inv_in, PRICE_ACTIONS[p_idx], INV_ACTIONS[i_idx]

    def remember(self, obs, p_idx, i_idx, inv_in, r_p, r_i, next_obs, next_inv_in, done):
        self.buffer_p.append((obs, p_idx, r_p, next_obs, done))
        self.buffer_i.append((inv_in, i_idx, r_i, next_inv_in, done))

    def fit_iteration(self, max_buffer=6000):
        if len(self.buffer_p) >= 200:
            self.buffer_p = self.buffer_p[-max_buffer:]
            obs = np.array([b[0] for b in self.buffer_p])
            idx = np.array([b[1] for b in self.buffer_p])
            r = np.array([b[2] for b in self.buffer_p], dtype=np.float32)
            nobs = np.array([b[3] for b in self.buffer_p])
            done = np.array([b[4] for b in self.buffer_p], dtype=np.float32)
            q_all = self.net_p.predict(obs) if self.fitted_p else np.zeros((len(obs), 3))
            next_q = self.net_p.predict(nobs).max(axis=1) if self.fitted_p else np.zeros(len(obs))
            target = q_all.copy()
            target[np.arange(len(obs)), idx] = r + self.gamma * next_q * (1 - done)
            self.net_p.fit(obs, target)
            self.fitted_p = True

        if len(self.buffer_i) >= 200:
            self.buffer_i = self.buffer_i[-max_buffer:]
            obs = np.array([b[0] for b in self.buffer_i])
            idx = np.array([b[1] for b in self.buffer_i])
            r = np.array([b[2] for b in self.buffer_i], dtype=np.float32)
            nobs = np.array([b[3] for b in self.buffer_i])
            done = np.array([b[4] for b in self.buffer_i], dtype=np.float32)
            q_all = self.net_i.predict(obs) if self.fitted_i else np.zeros((len(obs), 3))
            next_q = self.net_i.predict(nobs).max(axis=1) if self.fitted_i else np.zeros(len(obs))
            target = q_all.copy()
            target[np.arange(len(obs)), idx] = r + self.gamma * next_q * (1 - done)
            self.net_i.fit(obs, target)
            self.fitted_i = True

    def decay(self):
        self.eps = max(self.eps_min, self.eps * self.eps_decay)
