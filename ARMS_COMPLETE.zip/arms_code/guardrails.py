"""
Safety layer between the RL agent and the store.

A company will not let a learning agent act unchecked. Two protections:

1. HARD GUARDRAILS (rules the agent cannot break)
   - Price floor: never sell below unit cost, UNLESS the stock expires within 1 day
     (selling a doomed unit below cost beats throwing it away).
   - Reorder cap: never order so much that stock would exceed shelf capacity (MAX_STOCK).

2. LOW-CONFIDENCE FALLBACK (used at deployment)
   - If the agent has never seen this situation, or its action values are nearly tied
     (it does not really know which action is better), hand the decision to the
     simple rule-based policy instead of guessing.
"""
import numpy as np
from retail_env_v2 import (PRICE_ACTIONS, INV_ACTIONS, PRICE_MULTIPLIER, REORDER_QTY,
                            BASE_PRICE, UNIT_COST, MAX_STOCK)
from agents import discretize, rule_based_policy

CONFIDENCE_GAP = 8.0   # minimum gap between best and worst action value to trust the agent


def apply_guardrails(state, price_a, inv_a):
    """Return the (possibly corrected) actions and which guardrails fired."""
    fired = {"price_floor": False, "reorder_cap": False}

    if BASE_PRICE * PRICE_MULTIPLIER[price_a] < UNIT_COST and state["days_to_expiry"] > 1:
        allowed = [p for p in PRICE_ACTIONS if BASE_PRICE * PRICE_MULTIPLIER[p] >= UNIT_COST]
        price_a = allowed[-1]            # deepest discount that is still at or above cost
        fired["price_floor"] = True

    if state["stock"] + REORDER_QTY[inv_a] > MAX_STOCK:
        allowed = [i for i in INV_ACTIONS if state["stock"] + REORDER_QTY[i] <= MAX_STOCK]
        inv_a = allowed[-1] if allowed else "NO_REORDER"   # largest order that still fits
        fired["reorder_cap"] = True

    return price_a, inv_a, fired


def greedy_with_fallback(agent, state, gap=CONFIDENCE_GAP):
    """Deployed two-agent policy: greedy, but defer to the rule-based policy when unsure.
    Returns (price_action, inventory_action, used_fallback)."""
    s = discretize(state)
    row_p = agent.Qp.get(s)
    if row_p is None or (row_p.max() - row_p.min()) < gap:
        p, i = rule_based_policy(state)
        return p, i, True
    p_idx = int(np.argmax(row_p))
    row_i = agent.Qi.get((s, p_idx))
    if row_i is None or (row_i.max() - row_i.min()) < gap:
        p, i = rule_based_policy(state)
        return p, i, True
    return PRICE_ACTIONS[p_idx], INV_ACTIONS[int(np.argmax(row_i))], False
