"""STRONGER METHOD TRIED: MAPPO with a service-level constraint (Lagrangian). The inventory reward gets an extra penalty lam x unmet units, and lam rises while the
average unmet demand per episode is above the target and falls when below. Targets 15 and 8 unmet units per episode, 3 seeds; evaluated on the seen shop and 3 unseen shops.
   python constrained_experiment.py       writes results_constrained.csv"""
import os, numpy as np, pandas as pd
import baselines_rl as B, mappo_v3 as W, performance_suite as PS
HERE = os.path.dirname(os.path.abspath(__file__)); rows = []
for target in (15, 8):
    for sd in range(3):
        ag, _ = B.train_mappo(sd, 1920, 1920, lambda p: 0.0, service_target=target, dual_lr=0.01)
        for r in PS.final_rows(f"MAPPO + service constraint (target {target} unmet)", sd, ag.policy(), {k: PS.SCEN[k] for k in ("Seen: normal shop", "Unseen: quiet shop (7 a day)", "Unseen: 2-day shelf life", "Unseen: busy shop (18 a day)")}, False)[0]:
            r["final_lambda"] = ag.lam; rows.append(r)
        print("target", target, "seed", sd, "lambda", round(ag.lam, 3), flush=True)
pd.DataFrame(rows).to_csv(os.path.join(HERE, "results_constrained.csv"), index=False); print("done")
