"""
Three-product store experiment (milk, curd, bread sharing one shelf).

  1. tune an order-up-to rule (one target per product) by grid search on separate tuning seeds
  2. train the per-product RL agents (seed 42) and save them for the app
  3. compare the original rule, the tuned rule and RL on fresh seeds (same random demand for every method)
  4. repeat RL training over 5 seeds
  5. repeat everything at several shelf capacities: sharing the shelf only matters when it is tight

    python multi_experiment.py          (about 3-5 minutes)
"""
import os
BASE = os.path.dirname(os.path.abspath(__file__))
import itertools
import json
import numpy as np
import pandas as pd
from scipy import stats
import retail_env_multi as M
import agents_multi as A

GRID = [10, 15, 20, 25, 30, 35]


def tune(n=15, seed0=500000):
    best, best_val = None, -1e18
    for t in itertools.product(GRID, repeat=M.N):
        val = A.evaluate(A.policy_tuned(list(t)), n=n, seed0=seed0, crn=False)["profit"].mean()
        if val > best_val:
            best, best_val = list(t), val
    return best, best_val


def summarize(label, ev):
    row = {"Method": label, "Profit (Rs/episode)": ev["profit"].mean(), "Wasted units": ev["wasted"].mean(),
           "Unmet demand (units)": ev["unmet"].mean(), "Shelf use": ev["shelf_use"].mean() * 100,
           "Orders cut by shelf limit": ev["cuts"].mean()}
    for p in M.PRODUCTS:
        row[f"{p['name']} profit"] = ev[f"profit_{p['name']}"].mean()
    return row


if __name__ == "__main__":
    base_cap = M.CAPACITY
    print(f"Tuning order-up-to targets at shelf capacity {base_cap}...", flush=True)
    targets, tv = tune()
    print("  best targets (milk, curd, bread):", targets, "| tuning profit", round(tv), flush=True)
    with open(os.path.join(BASE, "store3_tuned_targets.json"), "w") as f:
        json.dump({"capacity": base_cap, "targets": targets}, f)

    print("Training per-product RL agents (seed 42, 1500 episodes)...", flush=True)
    agents = A.train_multi(42, 1500)
    A.save_agents(agents, os.path.join(BASE, "trained_store3_agents.json"))

    rows = [summarize("Original rule", A.evaluate(A.policy_original)),
            summarize("Tuned order-up-to rule", A.evaluate(A.policy_tuned(targets))),
            summarize("RL (per-product agents)", A.evaluate(A.policy_rl(agents)))]
    res = pd.DataFrame(rows)
    res.to_csv(os.path.join(BASE, "store3_results.csv"), index=False)
    pd.set_option("display.width", 250); pd.set_option("display.max_columns", 20)
    print("\nFRESH TEST SEEDS (100 episodes, same demand for every method):")
    print(res.round(1).to_string(index=False), flush=True)

    tuned_profit = rows[1]["Profit (Rs/episode)"]
    print("\nRL over 5 training seeds (1000 episodes each)...", flush=True)
    seeds = []
    for sd in range(5):
        ag = A.train_multi(sd, 1000)
        seeds.append(A.evaluate(A.policy_rl(ag))["profit"].mean())
        print(f"  seed {sd}: RL profit {seeds[-1]:.0f}", flush=True)
    seeds = np.array(seeds)
    pd.DataFrame({"seed": range(5), "rl_profit": seeds}).to_csv(os.path.join(BASE, "store3_seed_results.csv"), index=False)
    t = stats.ttest_1samp(seeds, tuned_profit)
    print(f"  RL mean {seeds.mean():.0f} +/- {seeds.std(ddof=1):.0f} | tuned rule {tuned_profit:.0f} | "
          f"RL above tuned rule in {(seeds > tuned_profit).sum()}/5 seeds | one-sample t-test vs tuned rule p={t.pvalue:.3f}", flush=True)

    print("\nCooperative variant: a shared team reward (every agent is scored on the whole store)...", flush=True)
    team = []
    for sd in range(5):
        ag = A.train_multi(sd, 1000, team_reward=True)
        team.append(A.evaluate(A.policy_rl(ag))["profit"].mean())
    team = np.array(team)
    pd.DataFrame({"seed": range(5), "rl_profit": team}).to_csv(os.path.join(BASE, "store3_team_seed_results.csv"), index=False)
    print(f"  team-reward RL mean {team.mean():.0f} +/- {team.std(ddof=1):.0f} | above tuned rule in {(team > tuned_profit).sum()}/5 seeds", flush=True)

    print("\nShelf capacity sensitivity (targets re-tuned and RL retrained at each capacity)...", flush=True)
    cap_rows = []
    for cap in [35, 45, 60, 80]:
        M.CAPACITY = cap
        tg, _ = tune()
        ag = A.train_multi(42, 1000)
        for label, pol in [("Original rule", A.policy_original), ("Tuned order-up-to rule", A.policy_tuned(tg)),
                           ("RL (per-product agents)", A.policy_rl(ag))]:
            ev = A.evaluate(pol)
            cap_rows.append({"Shelf capacity": cap, "Method": label, "Profit (Rs/episode)": ev["profit"].mean(),
                             "Wasted units": ev["wasted"].mean(), "Unmet demand (units)": ev["unmet"].mean(),
                             "Orders cut by shelf limit": ev["cuts"].mean()})
        print(f"  capacity {cap}: tuned targets {tg}", flush=True)
    M.CAPACITY = base_cap
    cap_df = pd.DataFrame(cap_rows)
    cap_df.to_csv(os.path.join(BASE, "store3_capacity_results.csv"), index=False)
    print(cap_df.pivot(index="Shelf capacity", columns="Method", values="Profit (Rs/episode)").round(0).to_string())
