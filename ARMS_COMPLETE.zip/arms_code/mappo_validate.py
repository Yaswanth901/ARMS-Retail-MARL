"""
Independent re-test of the trained MAPPO agents (saved weights, seeds 5-14) on 300 NEW episodes, next to the two tuned
classical rules, plus a look at what MAPPO does differently (how often it orders, and in what size).

    python mappo_validate.py
"""
import os
BASE = os.path.dirname(os.path.abspath(__file__))
import numpy as np
import pandas as pd
from retail_env_v2 import RetailEnvV2, PRICE_ACTIONS, INV_ACTIONS
import mappo_numpy as M
import app_core as C
from tune_sS import make_sS

N, SEED0 = 300, 2_000_000


def run(policy):
    profits, orders, price_n, inv_n = [], [], np.zeros(3), np.zeros(3)
    for k in range(N):
        env = RetailEnvV2(60, seed=SEED0 + k)
        s = env.reset()
        prof = 0.0
        for _ in range(60):
            p, i, _ = policy(s)
            price_n[PRICE_ACTIONS.index(p)] += 1
            inv_n[INV_ACTIONS.index(i)] += 1
            s, _, _, info = env.step(p, i)
            prof += info["profit"]
        profits.append(prof)
    return np.array(profits), price_n / price_n.sum() * 100, inv_n / inv_n.sum() * 100


if __name__ == "__main__":
    sS = pd.read_csv(os.path.join(BASE, "tuned_sS_grid.csv")).iloc[0]
    rules = {"Tuned order-up-to rule": C.TUNED_RULE, "Tuned (s,S) rule": make_sS(int(sS.s), sS.order, int(sS.mod_exp))}
    rows, behav = [], []
    for name, pol in rules.items():
        pr, pp, ip = run(pol)
        rows.append(dict(method=name, seed="", profit=pr.mean(), std_error=pr.std(ddof=1) / np.sqrt(N)))
        behav.append(dict(method=name, regular=pp[0], moderate=pp[1], clearance=pp[2], no_order=ip[0], small_order=ip[1], full_order=ip[2]))
    mean_by_seed = []
    for sd in range(5, 15):
        agent = M.MAPPO.load(os.path.join(BASE, "mappo_weights", f"seed{sd}.npz"), sd)
        pr, pp, ip = run(agent.policy())
        rows.append(dict(method="MAPPO", seed=sd, profit=pr.mean(), std_error=pr.std(ddof=1) / np.sqrt(N)))
        mean_by_seed.append(pr.mean())
        if sd == 6:                                   # the median-performing seed, used in the app
            behav.append(dict(method="MAPPO (seed 6)", regular=pp[0], moderate=pp[1], clearance=pp[2], no_order=ip[0], small_order=ip[1], full_order=ip[2]))
    pd.DataFrame(rows).to_csv(os.path.join(BASE, "mappo_validation.csv"), index=False)
    pd.DataFrame(behav).to_csv(os.path.join(BASE, "mappo_behaviour.csv"), index=False)
    print(f"{N} NEW test episodes (seeds {SEED0}+)")
    for r in rows[:2]:
        print(f"  {r['method']:24s} {r['profit']:7.0f} (s.e. {r['std_error']:.0f})")
    print(f"  MAPPO, 10 saved agents    mean {np.mean(mean_by_seed):7.0f}, range {min(mean_by_seed):.0f} to {max(mean_by_seed):.0f}")
    print(pd.DataFrame(behav).round(1).to_string(index=False))
