"""
PERFORMANCE SUITE: every metric on madam's list, for Q-learning, DQN, Double DQN, PPO and MAPPO (ours) against the rule benchmarks.
  python performance_suite.py rules                 benchmark rules + a random policy (no training)
  python performance_suite.py train --seeds 5       train each method (same budget: 1,920 episodes = 115,200 steps), evaluate while learning, then test
  python performance_suite.py ablation --seeds 5    remove one component of MAPPO at a time
Results are appended to perf_*.csv and the commands resume where they stopped. make_figures.py turns them into the figures and tables.
Fixed before running: evaluation = 20 fixed episodes every 160 training episodes; test = fresh episodes the agents never trained on;
SUCCESS EPISODE = fill rate >= 95% and waste <= 3% of units handled; convergence threshold = designed return Rs 7,500 for 2 consecutive evaluations.
EPISODIC RETURN (primary metric) = designed reward summed over the episode = profit - 20 x unmet units; profit is reported as a problem-specific metric.
"""
import argparse, os, time
import numpy as np, pandas as pd
import mappo_v3 as W, baselines_rl as B, retail_env_v2 as V
import app_core as C, train_v2 as T

HERE = os.path.dirname(os.path.abspath(__file__))
BUDGET, EVAL_N, EVAL_SEED = 1920, 20, 950000
EVAL_EVERY = {0, 32, 64, 96, 160, 320, 480, 640, 960, 1280, 1600}     # more checkpoints early, where the learning happens
SCEN = {"Seen: normal shop": {}, "Unseen: quiet shop (7 a day)": {"base_demand": 7.0}, "Unseen: busy shop (18 a day)": {"base_demand": 18.0},
        "Unseen: 2-day shelf life": {"shelf": 2}, "Unseen: late deliveries": {"delay": (0.6, 0.3, 0.1)}}
KEEP = ["ret", "profit", "wasted", "unmet", "fill_rate", "waste_rate", "success", "order_days", "discount_days", "below_cost_days", "overflow_days"]
def ev_fn(pol):
    r = W.evaluate(pol, None, EVAL_N, EVAL_SEED); return r["profit"] - 20.0 * r["unmet"]     # designed return = profit minus the 20 per unmet unit penalty the agents are trained on

def idx_rule(fn):
    def f(s):
        p, i, *_ = fn(s); return V.PRICE_ACTIONS.index(p), V.INV_ACTIONS.index(i)
    return f
def noisy(policy, sigma=0.10, seed=0):
    rng = np.random.default_rng(seed)
    def f(s):
        s2 = dict(s); s2["stock"] = max(0, int(round(s["stock"] * (1 + rng.normal(0, sigma)))))
        for k in ("demand_ema", "recent_demand"): s2[k] = max(0.0, s[k] * (1 + rng.normal(0, 1.5 * sigma)))
        return policy(s2)
    return f
def random_masked(seed=0):
    rng = np.random.default_rng(seed)
    return lambda s: (int(rng.choice(np.flatnonzero(W.price_mask(s, (0.0, 0.15, 0.35))))), int(rng.choice(np.flatnonzero(__import__("mappo_numpy").inv_mask(s)))))

def append(df, name):
    p = os.path.join(HERE, name); df.to_csv(p, mode="a" if os.path.exists(p) else "w", header=not os.path.exists(p), index=False)
def done_set(name, cols=("method", "seed")):
    p = os.path.join(HERE, name)
    return set() if not os.path.exists(p) else set(map(tuple, pd.read_csv(p)[list(cols)].astype(str).drop_duplicates().values))

def final_rows(method, seed, policy, scenarios=SCEN, episodes_for_regret=True):
    rows, eps = [], []
    for sname, kw in scenarios.items():
        d = W.evaluate_detail(policy, kw, 100 if sname.startswith("Seen") else 60, 900000)
        d["ret"] = d["profit"] - 20.0 * d["unmet"]
        rows.append(dict(method=method, seed=seed, scenario=sname, **{k: float(d[k].mean()) for k in KEEP}))
        if sname.startswith("Seen") and episodes_for_regret: eps += [dict(method=method, seed=seed, episode=i, ret=float(v)) for i, v in enumerate(d["ret"].values[:30])]
    dn = W.evaluate_detail(noisy(policy), {}, 60, 900000); dn["ret"] = dn["profit"] - 20.0 * dn["unmet"]
    rows.append(dict(method=method, seed=seed, scenario="Noisy observations (10% on stock)", **{k: float(v) for k, v in dn[KEEP].mean().items()}))
    return rows, eps

def compute_row(method, seed, secs, policy, params):
    s_list, env = [], W.RetailEnvV3(60, seed=123); s = env.reset()
    for _ in range(60): s_list.append(s); s = env.step(*policy(s))[0]
    t0 = time.perf_counter(); [policy(x) for _ in range(5) for x in s_list]; ms = (time.perf_counter() - t0) / (5 * len(s_list)) * 1000
    return dict(method=method, seed=seed, train_seconds=round(secs, 1), inference_ms=round(ms, 3), parameters=params)

def count(ag):
    if hasattr(ag, "Qp"): return int(sum(len(v) for v in ag.Qp.values()) + sum(len(v) for v in ag.Qi.values()))
    if hasattr(ag, "q"): return ag.n_params()
    nets = [ag.actor] if hasattr(ag, "actor") else [ag.actor_p, ag.actor_i]
    return int(sum(sum(w.size for w in n.W) + sum(b.size for b in n.b) for n in nets))

def rules():
    done = done_set("perf_final.csv"); R = {"Original rule": idx_rule(T.rule_policy), "Tuned order-up-to rule": idx_rule(lambda s: C.TUNED_RULE(s)), "Tuned (s,S) rule": W.rule_ss(26), "Random (masked)": random_masked()}
    for name, pol in R.items():
        if (name, "-") in done: continue
        rows, eps = final_rows(name, "-", pol); append(pd.DataFrame(rows), "perf_final.csv"); append(pd.DataFrame(eps), "perf_episodes.csv"); append(pd.DataFrame([compute_row(name, "-", 0, pol, 0)]), "perf_compute.csv"); print("rule done:", name, flush=True)
        for e in range(0, BUDGET + 1, EVAL_EVERY):   # horizontal reference lines for the learning curves
            pass
        append(pd.DataFrame([dict(method=name, seed="-", episodes=e, steps=e * 60, eval_return=ev_fn(pol)) for e in (0, BUDGET)]), "perf_curves.csv")

TRAINERS = {"Q-learning (tabular, two agents)": lambda sd: B.train_qlearning(sd, BUDGET, EVAL_EVERY, ev_fn), "DQN": lambda sd: B.train_dqn(sd, BUDGET, EVAL_EVERY, ev_fn),
            "Double DQN": lambda sd: B.train_dqn(sd, BUDGET, EVAL_EVERY, ev_fn, True), "PPO (single agent)": lambda sd: B.train_ppo(sd, BUDGET, EVAL_EVERY, ev_fn),
            "MAPPO (ours)": lambda sd: B.train_mappo(sd, BUDGET, EVAL_EVERY, ev_fn)}
def train(seeds, only=None):
    done = done_set("perf_final.csv")
    for name, fn in TRAINERS.items():
        if only and only not in name: continue
        for sd in range(seeds):
            if (name, str(sd)) in done: continue
            t0 = time.time(); ag, curve = fn(sd); secs = time.time() - t0
            pol = ag.policy_fn if hasattr(ag, "policy_fn") else ag.policy()
            append(pd.DataFrame([dict(method=name, seed=sd, episodes=e, steps=e * 60, eval_return=r) for e, r in curve]), "perf_curves.csv")
            rows, eps = final_rows(name, sd, pol); append(pd.DataFrame(rows), "perf_final.csv"); append(pd.DataFrame(eps), "perf_episodes.csv")
            append(pd.DataFrame([compute_row(name, sd, secs, pol, count(ag))]), "perf_compute.csv")
            print(f"{name} seed {sd}: final evaluation return {curve[-1][1]:,.0f} ({secs:.0f}s)", flush=True)

def curves(seeds):
    """Re-record only the learning curves with the early checkpoints (training is deterministic, so the final policies are unchanged). Resumable."""
    p = os.path.join(HERE, "perf_curves.csv"); old = pd.read_csv(p)
    for name, fn in TRAINERS.items():
        for sd in range(seeds):
            old = pd.read_csv(p)
            if ((old.method == name) & (old.seed.astype(str) == str(sd)) & (old.episodes == 32)).any(): continue
            ag, curve = fn(sd); keep = old[~((old.method == name) & (old.seed.astype(str) == str(sd)))]
            pd.concat([keep, pd.DataFrame([dict(method=name, seed=sd, episodes=e, steps=e * 60, eval_return=r) for e, r in curve])], ignore_index=True).to_csv(p, index=False); print("curve", name, sd, flush=True)

VARIANTS = {"MAPPO (ours)": {}, "Default entropy bonus 0.01 (no tuning)": {"ent": 0.01}, "Pricing critic sees its own action (earlier design)": {"critic": "legacy"}, "No role-specific rewards (shared team reward)": {"team_reward": True},
            "No safety action masks": {"use_masks": False}, "Basic inputs only (no smoothed demand, no units expiring)": {"feat": "basic"}}
def ablation(seeds):
    done = done_set("perf_ablation.csv"); scen = {k: SCEN[k] for k in ("Seen: normal shop", "Unseen: quiet shop (7 a day)", "Unseen: 2-day shelf life")}
    for name, hp in VARIANTS.items():
        for sd in range(seeds):
            if (name, str(sd)) in done: continue
            t0 = time.time(); ag, _ = B.train_mappo(sd, BUDGET, BUDGET, ev_fn, **hp); rows, _ = final_rows(name, sd, ag.policy(), scen, False)
            append(pd.DataFrame(rows), "perf_ablation.csv"); print(f"ablation {name} seed {sd} done ({time.time()-t0:.0f}s)", flush=True)

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("cmd", choices=["rules", "train", "ablation", "curves"]); ap.add_argument("--seeds", type=int, default=5); ap.add_argument("--only", default=None); a = ap.parse_args()
    {"rules": lambda: rules(), "train": lambda: train(a.seeds, a.only), "ablation": lambda: ablation(a.seeds), "curves": lambda: curves(a.seeds)}[a.cmd](); print("done", a.cmd)
