"""NEW FEATURE TEST: drift-aware controller (version 2).
Use the proven tuned (s,S) rule in normal conditions; hand over to the learned MAPPO agent when
(a) smoothed demand has FALLEN more than 25% below the level the rule was tuned for (12 a day), or
(b) the product's shelf life is shorter than the 4 days the rule was tuned for.
The switch was designed after seeing the first six scenarios, so it is ALSO tested on four new ones.
Run: python hybrid_test.py    (about 2 minutes)"""
import numpy as np, app_core as C, mappo_numpy as M, retail_env_v2 as E
def hybrid(mp):
    def f(s):
        falling = s["demand_ema"] < 0.75 * 12.0
        short_life = E.SHELF_LIFE_DAYS < 4
        return mp(s) if (falling or short_life) else C.SS_RULE(s)
    return f
def run(policy, demand, shelf, shocks, k):
    u = np.random.default_rng(555000 + k).random(60)
    with C.scenario(demand, shelf):
        env = C.make_env(60, u, shocks); s = env.reset(); tot = 0.0
        for _ in range(60):
            p, i, *_ = policy(s); s, _, _, info = env.step(p, i); tot += info["profit"]
    return tot
agents = [M.MAPPO.load(f"mappo_weights/seed{sd}.npz", sd) for sd in range(5, 10)]
old = [(n, d, sh, shk) for n, d, sh, shk in C.STRESS_SCENARIOS]
new = [("NEW: demand -25% (9 a day)", 9, 4, None), ("NEW: demand -55% (5.4 a day)", 5.4, 4, None),
       ("NEW: shelf life 3 days", 12, 3, None), ("NEW: demand +25% (15 a day)", 15, 4, None)]
ROWS = []
def block(title, scs):
    print(f"\n{title}\n{'Scenario':34s} {'(s,S) rule':>10s} {'MAPPO':>8s} {'Hybrid':>8s}")
    tot = dict(ss=[], mp=[], hy=[])
    for name, demand, shelf, shocks in scs:
        r = dict(ss=[], mp=[], hy=[])
        for sd, ag in enumerate(agents):
            mp = ag.policy()
            for k in range(8):
                if sd == 0: r["ss"].append(run(C.SS_RULE, demand, shelf, shocks, k))
                r["mp"].append(run(mp, demand, shelf, shocks, k)); r["hy"].append(run(hybrid(mp), demand, shelf, shocks, k))
        m = {k: np.mean(v) for k, v in r.items()}
        for k in m: tot[k].append(m[k])
        print(f"{' '.join(name.split())[:34]:34s} {m['ss']:10.0f} {m['mp']:8.0f} {m['hy']:8.0f}")
        ROWS.append(dict(scenario_set=title.split('(')[0].strip().title(), scenario=' '.join(name.split()), tuned_sS_rule=round(m['ss']), MAPPO=round(m['mp']), drift_aware_hybrid=round(m['hy'])))
    print(f"{'AVERAGE':34s} {np.mean(tot['ss']):10.0f} {np.mean(tot['mp']):8.0f} {np.mean(tot['hy']):8.0f}")
block("SCENARIOS USED TO DESIGN THE SWITCH", old)
block("NEW SCENARIOS (not used in the design)", new)

import pandas as pd
pd.DataFrame(ROWS).to_csv("hybrid_results.csv", index=False)
print("\nSaved hybrid_results.csv (the app reads it).")
