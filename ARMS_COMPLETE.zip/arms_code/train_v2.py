"""
v2 experiment: real profit economics + safety guardrails.

Compared (all trained/evaluated on the same v2 environment):
  1. Rule-based control
  2. Single-Agent Q-learning
  3. Two-Agent Q-learning (no guardrails)
  4. Two-Agent Q-learning trained WITH guardrails
  5. Same as 4, deployed with the low-confidence fallback to the rule-based policy
"""
import os
BASE = os.path.dirname(os.path.abspath(__file__))
import numpy as np
import pandas as pd
from retail_env_v2 import RetailEnvV2, PRICE_ACTIONS, INV_ACTIONS
from agents import SingleAgentQLearner, TwoAgentQLearner, rule_based_policy, discretize
from guardrails import apply_guardrails, greedy_with_fallback

HORIZON = 60
N_EPISODES = 1000
SEED = 42


class EpStats:
    def __init__(self):
        self.profit = self.wastage = self.stockout = self.demand = 0
        self.below_cost = self.over_cap = self.guard_fires = self.fallbacks = 0

    def add(self, info, guard_fired=0, fallback=0):
        self.profit += info["profit"]
        self.wastage += info["wastage"]
        self.stockout += info["stockout"]
        self.demand += info["demand"]
        self.below_cost += info["below_cost_units"]
        self.over_cap += info["over_capacity"]
        self.guard_fires += guard_fired
        self.fallbacks += fallback

    def row(self, ep):
        return dict(episode=ep, profit=self.profit, wastage=self.wastage, stockout=self.stockout,
                    fill_rate=(self.demand - self.stockout) / max(self.demand, 1),
                    below_cost_units=self.below_cost, over_capacity_days=self.over_cap,
                    guardrail_fires=self.guard_fires, fallback_decisions=self.fallbacks)


def run_rule(n):
    rows = []
    for ep in range(n):
        env = RetailEnvV2(HORIZON, seed=SEED + ep)
        s = env.reset()
        st = EpStats()
        for _ in range(HORIZON):
            p, i = rule_based_policy(s)
            s, _, done, info = env.step(p, i)
            st.add(info)
        rows.append(st.row(ep))
    return pd.DataFrame(rows)


def run_single(n):
    agent = SingleAgentQLearner()
    rows = []
    for ep in range(n):
        env = RetailEnvV2(HORIZON, seed=SEED + ep)
        s = env.reset()
        st = EpStats()
        for _ in range(HORIZON):
            s_disc = discretize(s)
            idx, (p, i) = agent.act(s)
            s_next, (rp, ri), done, info = env.step(p, i)
            agent.update(s_disc, idx, rp + ri, discretize(s_next), done)
            s = s_next
            st.add(info)
        agent.decay()
        rows.append(st.row(ep))
    return pd.DataFrame(rows), agent


def run_two(n, guard):
    agent = TwoAgentQLearner()
    rows = []
    for ep in range(n):
        env = RetailEnvV2(HORIZON, seed=SEED + ep)
        s = env.reset()
        st = EpStats()
        for _ in range(HORIZON):
            (s_disc, p_idx, i_idx), (p, i) = agent.act(s)
            fired = 0
            if guard:
                p2, i2, f = apply_guardrails(s, p, i)
                fired = int(f["price_floor"] or f["reorder_cap"])
                p, i = p2, i2
                p_idx, i_idx = PRICE_ACTIONS.index(p), INV_ACTIONS.index(i)   # learn from the action actually executed
            s_next, (rp, ri), done, info = env.step(p, i)
            agent.update(s_disc, p_idx, i_idx, rp, ri, discretize(s_next), done)
            s = s_next
            st.add(info, guard_fired=fired)
        agent.decay()
        rows.append(st.row(ep))
    return pd.DataFrame(rows), agent


def evaluate(policy, n=100, guard=False):
    """Deployed evaluation on fresh seeds no agent trained on. policy(state) -> (price, inv, used_fallback)."""
    rows = []
    for ep in range(n):
        env = RetailEnvV2(HORIZON, seed=900000 + ep)
        s = env.reset()
        st = EpStats()
        for _ in range(HORIZON):
            p, i, used_fb = policy(s)
            fired = 0
            if guard:
                p, i, f = apply_guardrails(s, p, i)
                fired = int(f["price_floor"] or f["reorder_cap"])
            s, _, done, info = env.step(p, i)
            st.add(info, guard_fired=fired, fallback=int(used_fb))
        rows.append(st.row(ep))
    return pd.DataFrame(rows)


def rule_policy(s):
    p, i = rule_based_policy(s)
    return p, i, 0


def greedy_policy(agent):
    def f(s):
        old = agent.eps
        agent.eps = 0.0
        out = agent.act(s)
        agent.eps = old
        p, i = out[1] if len(out) == 2 and isinstance(out[1], tuple) else out[1:]
        return p, i, 0
    return f


def summarize(df, label):
    m = df.mean(numeric_only=True)
    return {"Method": label, "Profit (Rs/episode)": round(m["profit"]), "Wastage (units)": round(m["wastage"], 1),
            "Stock-out (units)": round(m["stockout"], 1), "Fill rate": f"{m['fill_rate']*100:.1f}%",
            "Below-cost units sold": round(m["below_cost_units"], 1),
            "Days over shelf capacity": round(m["over_capacity_days"], 1),
            "Guardrail interventions": round(m["guardrail_fires"], 1),
            "Fallback decisions": round(m["fallback_decisions"], 1)}


if __name__ == "__main__":
    np.random.seed(SEED)
    print("Rule-based...")
    df_rule = run_rule(200)
    print("Single-agent Q-learning...")
    df_single, single = run_single(N_EPISODES)
    print("Two-agent Q-learning (no guardrails)...")
    df_two, two = run_two(N_EPISODES, guard=False)
    print("Two-agent Q-learning (trained with guardrails)...")
    df_two_g, two_g = run_two(N_EPISODES, guard=True)

    # fair, deployed comparison: every method on the SAME fresh seeds, no exploration noise
    ev_rule = evaluate(rule_policy)
    ev_single = evaluate(greedy_policy(single))
    ev_two = evaluate(greedy_policy(two))
    ev_two_g = evaluate(greedy_policy(two_g), guard=True)

    table = pd.DataFrame([
        summarize(ev_rule, "Rule-based"),
        summarize(ev_single, "Single-Agent Q-learning"),
        summarize(ev_two, "Two-Agent Q-learning (no guardrails)"),
        summarize(ev_two_g, "Two-Agent Q-learning + guardrails"),
    ])
    pd.set_option("display.width", 250)
    pd.set_option("display.max_columns", 20)
    print("\n" + table.to_string(index=False))
    table.to_csv(os.path.join(BASE, "v2_results_table.csv"), index=False)
    df_two.to_csv(os.path.join(BASE, "v2_curve_two_agent.csv"), index=False)
    df_two_g.to_csv(os.path.join(BASE, "v2_curve_two_agent_guarded.csv"), index=False)
    df_single.to_csv(os.path.join(BASE, "v2_curve_single_agent.csv"), index=False)
    print("\nsaved v2_results_table.csv and learning-curve CSVs")

    # Low-confidence fallback: a safety-vs-performance trade-off, swept over the confidence threshold
    sweep = []
    for gap in [8, 100, 300, 600, 1000]:
        pol = lambda s, g=gap: greedy_with_fallback(two_g, s, gap=g)
        ev = evaluate(pol, guard=True)
        decisions = HORIZON * len(ev)
        sweep.append({"Confidence threshold": gap, "Profit (Rs/episode)": round(ev["profit"].mean()),
                      "Decisions handed to rule-based": f"{ev['fallback_decisions'].sum() / decisions * 100:.1f}%",
                      "Stock-out (units)": round(ev["stockout"].mean(), 1),
                      "Wastage (units)": round(ev["wastage"].mean(), 1)})
    sweep = pd.DataFrame(sweep)
    print("\nFallback trade-off (higher threshold = defers to the safe rule more often):")
    print(sweep.to_string(index=False))
    sweep.to_csv(os.path.join(BASE, "v2_fallback_sweep.csv"), index=False)
