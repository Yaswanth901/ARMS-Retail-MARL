"""LEARN FROM SHOP DATA: reads a sales file (one row per bill line) and measures what the simulator needs.
  python calibrate_from_sales.py                       (uses SIMULATED_shop_month_sales.csv)
  python calibrate_from_sales.py --sales my_shop.csv   (columns: date,time,bill_id,product,category,qty,unit_price,unit_cost,expiry_date)
It prints the measured weekly pattern, demand level and variability, basket statistics, which products are bought together,
how much near-expiry stock customers accept, and writes demand_profile_shop.json."""
import argparse, json, os, numpy as np, pandas as pd
ap = argparse.ArgumentParser(); ap.add_argument("--sales", default="SIMULATED_shop_month_sales.csv")
ap.add_argument("--stock", default="SIMULATED_shop_month_stock.csv"); ap.add_argument("--truth", default="shop_month_truth.json")
a = ap.parse_args()
s = pd.read_csv(a.sales, parse_dates=["date"]); s["wd"] = s.date.dt.weekday
days = s.groupby("date").size().index
print(f"Read {len(s)} bill lines, {s.bill_id.nunique()} bills, {s.date.nunique()} days\n")

# ---- 1. store traffic and weekly pattern (bills per day)
bills = s.groupby("date").bill_id.nunique(); wd = bills.index.weekday
wk_mean = bills[wd < 5].mean(); mult = [round(float(bills[wd == k].mean() / wk_mean), 3) for k in range(7)]
weekend = float(bills[wd >= 5].mean() / wk_mean)
smoothed = [1.0] * 5 + [round(weekend, 3)] * 2
print("1. WEEKLY PATTERN (bills per day, relative to the Mon-Fri average)")
print("   raw by weekday :", dict(zip(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], mult)))
print(f"   weekend vs weekday multiplier: {weekend:.3f}   |  bills per weekday: {wk_mean:.1f}")

# ---- 2. demand level and variability per perishable product
print("\n2. DEMAND OF PERISHABLE PRODUCTS (units per weekday)  [variance/mean = 1 would be exactly Poisson]")
prof = {}
for p in s[s.category == "perishable"]["product"].unique():
    u = s[s["product"] == p].groupby("date").qty.sum().reindex(days, fill_value=0); uw = u[u.index.weekday < 5]
    prof[p] = dict(mean_weekday_units=round(float(uw.mean()), 2), variance_to_mean=round(float(uw.var() / uw.mean()), 2))
    print(f"   {p:12s} mean {uw.mean():5.2f}   variance/mean {uw.var()/uw.mean():4.2f}")

# ---- 3. baskets
bv = s.groupby("bill_id").line_amount.sum(); sz = s.groupby("bill_id").size()
print(f"\n3. BASKETS: average bill Rs {bv.mean():.0f} (median {bv.median():.0f}); {sz.mean():.2f} items per bill; "
      f"{(bv >= 150).mean():.0%} of bills are Rs 150 or more, {(bv >= 100).mean():.0%} are Rs 100 or more")

# ---- 4. products bought together (lift = how much more often than chance)
b = s.pivot_table(index="bill_id", columns="product", values="qty", aggfunc="sum").notna()
rows = []
for x in b.columns:
    for y in b.columns:
        if x < y: rows.append((x, y, b[x].mean(), b[y].mean(), (b[x] & b[y]).mean() / (b[x].mean() * b[y].mean())))
print("\n4. BOUGHT TOGETHER (lift above 1 means they are bought together more often than chance)")
for x, y, px, py, lift in sorted(rows, key=lambda r: -r[4])[:4]: print(f"   {x} + {y}: lift {lift:.2f}")

# ---- 5. near-expiry acceptance and waste
per = s[(s.category == "perishable") & (s.expiry_date.notna())].copy(); per["expiry_date"] = pd.to_datetime(per.expiry_date)
left = (per.expiry_date - per.date).dt.days
near = float(per[left <= 1].qty.sum() / per.qty.sum())
print(f"\n5. NEAR-EXPIRY: {near:.1%} of perishable units were sold when they had 1 day or less left")
if os.path.exists(a.stock):
    st = pd.read_csv(a.stock); waste = st.expired.sum() / (st.sold.sum() + st.expired.sum())
    cost = {"Milk packet": 35, "Curd cup": 24, "Bread": 30}
    wcost = sum(r.expired * cost[r["product"]] for _, r in st.iterrows())
    print(f"   Waste: {int(st.expired.sum())} units expired = {waste:.1%} of perishable units handled (worth Rs {wcost:,.0f} at cost); {int(st.unmet.sum())} units of demand were unmet")

# ---- 6. check against the TRUE settings (only possible for the simulated file)
if os.path.exists(a.truth) and "SIMULATED" in a.sales:
    t = json.load(open(a.truth)); print("\n6. CHECK AGAINST THE TRUE SETTINGS USED TO MAKE THE SIMULATED DATA")
    print(f"   weekend multiplier : true {t['weekday_mult'][5]:.2f}  | measured {weekend:.2f}")
    print(f"   bills per weekday  : true {t['bills_per_weekday']}    | measured {wk_mean:.1f}")
    pm = b["Milk packet"].mean(); print(f"   milk on a bill     : true {t['product_probability']['Milk packet']:.2f}  | measured {pm:.2f}   (true value measured from the generator itself)")
json.dump(dict(source=os.path.basename(a.sales), n_rows=int(len(s)), weekday_mult=smoothed, weekday_mult_raw=mult,
               products=prof, avg_bill_value=round(float(bv.mean()), 1), near_expiry_sold_share=round(near, 4)), open("demand_profile_shop.json", "w"), indent=2)
print("\nWrote demand_profile_shop.json (the measured weekly pattern; copy it to demand_profile.json to try it in the app).")
