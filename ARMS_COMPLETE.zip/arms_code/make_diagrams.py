"""Draws the MDP and system diagrams once and exports them four ways: JSON (native PowerPoint shapes), SVG and PNG (report), draw.io (editable).
   python make_diagrams.py"""
import html, json, os
import xml.etree.ElementTree as ET
CR = "#B60345"; INK = "#1A1A1A"; GREY = "#555555"
PAL = {"rose": ("#FCE9F0", "#B60345"), "card": ("#F9F7F4", "#B8B2AA"), "white": ("#FFFFFF", "#8F8A84"), "green": ("#E6F2E1", "#6FA860"), "amber": ("#FFF1D6", "#D9962B"),
       "blue": ("#E4EDF8", "#5B87C6"), "purple": ("#EEE7F5", "#8467AD"), "grey": ("#F0EEEB", "#A8A29B"), "crimson": ("#B60345", "#B60345"), "none": ("#FFFFFF", "#FFFFFF")}

class D:
    def __init__(self, name, w, h): self.name, self.w, self.h, self.items = name, w, h, []
    def box(self, x, y, w, h, lines, color="card", align="left", valign="middle", dashed=False, tcolor=INK):
        self.items.append(dict(kind="box", x=x, y=y, w=w, h=h, lines=lines, color=color, align=align, valign=valign, dashed=dashed, tcolor=tcolor))
    def text(self, x, y, w, h, lines, align="left", tcolor="#333333", valign="top"):
        self.items.append(dict(kind="text", x=x, y=y, w=w, h=h, lines=lines, align=align, tcolor=tcolor, valign=valign))
    def arrow(self, x1, y1, x2, y2, color=GREY, width=2.2, head=True, dashed=False):
        self.items.append(dict(kind="arrow", x1=x1, y1=y1, x2=x2, y2=y2, color=color, width=width, head=head, dashed=dashed))
    def json(self): return dict(name=self.name, w=self.w, h=self.h, pal=PAL, items=self.items)
    # ------------------------------------------------------------- SVG
    def svg(self, font="Arial, Helvetica, sans-serif"):
        o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {self.w} {self.h}" width="{self.w}" height="{self.h}" font-family="{font}">',
             '<defs><marker id="ah" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto"><path d="M0,0 L9,4.5 L0,9 z" fill="context-stroke"/></marker></defs>',
             f'<rect width="{self.w}" height="{self.h}" fill="#FFFFFF"/>']
        for it in self.items:
            if it["kind"] == "arrow":
                dash = ' stroke-dasharray="6 4"' if it.get("dashed") else ""
                mk = ' marker-end="url(#ah)"' if it["head"] else ""
                o.append(f'<line x1="{it["x1"]}" y1="{it["y1"]}" x2="{it["x2"]}" y2="{it["y2"]}" stroke="{it["color"]}" stroke-width="{it["width"]}"{dash}{mk}/>'); continue
            if it["kind"] == "box":
                f, s = PAL[it["color"]]; dash = ' stroke-dasharray="6 4"' if it["dashed"] else ""
                o.append(f'<rect x="{it["x"]}" y="{it["y"]}" width="{it["w"]}" height="{it["h"]}" rx="9" fill="{f}" stroke="{s}" stroke-width="1.6"{dash}/>')
            lines = it["lines"]; lh = [ln[2] * 1.32 for ln in lines]; total = sum(lh)
            y = it["y"] + (it["h"] - total) / 2 if it["valign"] == "middle" else (it["y"] if it["valign"] == "top0" else it["y"] + 8)
            for ln, h in zip(lines, lh):
                col = ln[3] if len(ln) > 3 else it["tcolor"]; size = ln[2]
                if it["align"] == "center": x, anchor = it["x"] + it["w"] / 2, "middle"
                else: x, anchor = it["x"] + 11, "start"
                o.append(f'<text x="{x}" y="{y + size * 1.0}" font-size="{size}" font-weight="{700 if ln[1] else 400}" fill="{col}" text-anchor="{anchor}">{html.escape(ln[0])}</text>'); y += h
        return "\n".join(o) + "</svg>"
    # ------------------------------------------------------------- draw.io
    def drawio(self, idx):
        d = ET.Element("diagram", {"name": self.name, "id": f"page{idx}"})
        g = ET.SubElement(d, "mxGraphModel", {"dx": "1000", "dy": "600", "grid": "1", "gridSize": "10", "guides": "1", "tooltips": "1", "connect": "1", "arrows": "1", "fold": "1", "page": "1", "pageScale": "1", "pageWidth": str(self.w + 40), "pageHeight": str(self.h + 40), "math": "0", "shadow": "0"})
        root = ET.SubElement(g, "root"); ET.SubElement(root, "mxCell", {"id": "0"}); ET.SubElement(root, "mxCell", {"id": "1", "parent": "0"})
        for n, it in enumerate(self.items, start=2):
            cid = f"{idx}_{n}"
            if it["kind"] == "arrow":
                c = ET.SubElement(root, "mxCell", {"id": cid, "style": f"endArrow={'classic' if it['head'] else 'none'};html=1;strokeWidth={it['width']};strokeColor={it['color']};{'dashed=1;' if it.get('dashed') else ''}", "edge": "1", "parent": "1"})
                geo = ET.SubElement(c, "mxGeometry", {"width": "50", "height": "50", "relative": "1", "as": "geometry"})
                ET.SubElement(geo, "mxPoint", {"x": str(it["x1"]), "y": str(it["y1"]), "as": "sourcePoint"}); ET.SubElement(geo, "mxPoint", {"x": str(it["x2"]), "y": str(it["y2"]), "as": "targetPoint"}); continue
            parts = []
            for ln in it["lines"]:
                col = ln[3] if len(ln) > 3 else it["tcolor"]; t = html.escape(ln[0]); parts.append(f'<font style="font-size: {int(ln[2])}px;" color="{col}">' + (f"<b>{t}</b>" if ln[1] else t) + "</font>")
            if it["kind"] == "box":
                f, s = PAL[it["color"]]; style = f"rounded=1;whiteSpace=wrap;html=1;arcSize=5;fillColor={f};strokeColor={s};strokeWidth=1.5;align={it['align']};verticalAlign={it['valign']};spacingLeft=10;{'dashed=1;' if it['dashed'] else ''}"
            else: style = f"text;html=1;whiteSpace=wrap;align={it['align']};verticalAlign={it['valign']};spacingLeft=2;"
            c = ET.SubElement(root, "mxCell", {"id": cid, "value": "<br>".join(parts), "style": style, "vertex": "1", "parent": "1"})
            ET.SubElement(c, "mxGeometry", {"x": str(it["x"]), "y": str(it["y"]), "width": str(it["w"]), "height": str(it["h"]), "as": "geometry"})
        return d

H = lambda t, c=CR, s=16: (t, True, s, c)
S = lambda t, s=13.5, c=None: (t, False, s, c) if c else (t, False, s)
B = lambda t, s=13.5, c=None: (t, True, s, c) if c else (t, True, s)

def mdp_loop():
    d = D("MDP loop", 1000, 470)
    d.box(8, 8, 350, 454, [H("AGENTS: two cooperating policies", CR, 16)], "rose", align="center", valign="top")
    d.box(22, 40, 322, 148, [H("Pricing agent   \u03c0_p(a_p | o_t)", CR, 15), S("input:  observation o_t  (6 numbers)", 13), B("output:  price tier  a_p", 13.5), S("a_p \u2208 { regular, 15% off, 35% off }", 13), S("own reward:  r^p_{t+1}", 13), S("actor 6\u219264\u219264\u21923     critic V_p(o_t)", 12.5)], "white")
    d.arrow(183, 188, 183, 214, CR, 2.4); d.text(194, 190, 140, 20, [S("price a_p", 12.5)])
    d.box(22, 216, 322, 150, [H("Inventory agent   \u03c0_i(a_i | o_t, a_p)", CR, 15), S("input:  o_t  and the chosen price a_p", 13), B("output:  reorder size  a_i", 13.5), S("a_i \u2208 { order 0, 10, 25 units }", 13), S("own reward:  r^i_{t+1}", 13), S("actor 9\u219264\u219264\u21923     critic V_i(o_t, a_p)", 12.5)], "white")
    d.box(22, 374, 322, 80, [B("Joint policy   \u03c0(a | o) = \u03c0_p(a_p | o) \u00b7 \u03c0_i(a_i | o, a_p)", 12.5, "#8A5A00"), S("Safety masks remove unsafe actions first:", 12), S("35% off only if \u2264 1 day left; no order that", 12), S("would overfill the 45-unit shelf", 12)], "amber")
    d.box(642, 8, 350, 454, [H("ENVIRONMENT: simulated store", "#3E7A2E", 16)], "green", align="center", valign="top")
    d.box(656, 38, 322, 74, [B("TRUE STATE  s_t  (partly hidden from the agents)", 13, "#2F5E22"), S("stock in batches by age \u00b7 day of week", 12.5), S("smoothed demand \u00b7 last demand", 12.5)], "white")
    steps = [("1  Demand", "D_t ~ Poisson(\u03bb_t),  \u03bb_t = 12 \u00d7 lift(a_p) \u00d7 weekday effect"), ("2  Sell oldest stock first", "sold = min(stock, D_t);  unmet = D_t \u2212 sold"), ("3  Age the stock one day", "units past their last day are wasted"), ("4  Order a_i arrives", "next morning, with 4 days of life"), ("5  Compute the rewards", "r^p_{t+1} and r^i_{t+1}, then  s_{t+1}")]
    for k, (h_, b_) in enumerate(steps): d.box(656, 120 + k * 66, 322, 60, [B(h_, 13.5, "#2F5E22"), S(b_, 12)], "white")
    d.text(358, 26, 284, 20, [B("Observation  o_t = \u03c6(s_t)", 14.5)], "center")
    d.text(358, 50, 284, 54, [S("stock \u00b7 days to expiry \u00b7 last demand", 12.5), S("weekday effect \u00b7 smoothed demand", 12.5), S("units expiring today   (6 numbers)", 12.5)], "center")
    d.arrow(642, 118, 358, 118, GREY, 2.4)
    d.text(358, 142, 284, 20, [B("Action  a_t = (a_p, a_i)", 14.5, CR)], "center"); d.arrow(358, 176, 642, 176, CR, 2.4)
    d.text(358, 184, 284, 40, [S("3 price tiers \u00d7 3 reorder sizes", 12.5), S("= 9 joint actions", 12.5)], "center")
    d.text(358, 236, 284, 20, [B("Rewards  r_{t+1}", 14.5, "#9A6A00")], "center")
    d.text(358, 260, 284, 66, [S("r^p = sold\u00b7(price \u2212 35) \u2212 35\u00b7expired", 12), S("r^i = \u2212(0.6\u00b7stock + 40\u00b71[order] + 20\u00b7unmet)", 12), S("team reward  r = r^p + r^i", 12.5, "#9A6A00")], "center")
    d.arrow(642, 336, 358, 336, "#C58A1B", 2.4); d.text(358, 344, 284, 20, [S("then the next observation  o_{t+1}", 12.5)], "center")
    d.text(358, 384, 284, 70, [B("t = 0 \u2026 59   (1 step = 1 day)", 13), S("o_t \u2192 a_t \u2192 ( r_{t+1}, o_{t+1} )", 12.5), S("episode ends at t = 60 (time limit)", 12.5)], "center")
    return d

def _markov_numbers():
    import json, os
    try:
        m = json.load(open("results_markov_weekday.json"))["markov"]["Seen: normal shop"][0]; sm = json.load(open("perf_summary.json")); e = next(r["mean"] for r in sm["final"] if r["method"] == "MAPPO (ours)")
        return f"{m:,.0f} vs {e:,.0f}"
    except Exception: return "see report"

def mdp_tuple():
    d = D("MDP tuple", 1000, 470)
    cards = [("STATE s_t AND OBSERVATION o_t", ["o_t = \u03c6(s_t), 6 numbers:", "stock 0 to 45 units", "days to expiry 1 to 4 (nearest batch)", "last demand \u00b7 weekday effect 1.00 / 1.15", "smoothed demand \u00b7 units expiring today"]),
             ("ACTIONS  A = A_p \u00d7 A_i", ["A_p: regular, 15% off, 35% off", "A_i: order 0, 10, 25 units", "9 joint actions", "mask: 35% off only if \u2264 1 day left;", "no order that overfills 45 units"]),
             ("TRANSITION  P(s' | s, a)", ["D ~ Poisson(12 \u00b7 lift \u00b7 weekday effect)", "lift 1.00 / 1.15 / 1.30; weekend 1.15", "sold = min(stock, D), oldest first", "age one day, expired units lost", "order arrives next morning"]),
             ("REWARD  r_{t+1}", ["r^p = sold\u00b7(price \u2212 35) \u2212 35\u00b7expired", "r^i = \u2212(0.6\u00b7stock + 40\u00b71[order]", "          + 20\u00b7unmet)", "team reward  r = r^p + r^i", "training uses r \u00f7 100"])]
    for k, (t, ls) in enumerate(cards): d.box(8 + k * 248, 8, 240, 180, [H(t, CR, 13.5)] + [S(x, 12.8) for x in ls], "card", valign="top")
    row2 = [("DISCOUNT  \u03b3", ["0.97 (MAPPO, PPO, DQN)", "0.95 (tabular Q-learning)", "horizon 1/(1\u2212\u03b3) = 33 or 20 days"]),
            ("INITIAL STATE  \u03c1_0", ["20 units, all with 4 days left", "day 0 is a Monday", "mean demand 12 a day"]),
            ("EPISODE AND TERMINAL", ["60 steps, t = 0 \u2026 59", "terminal: time limit at t = 60", "value after the last day = 0", "no goal or absorbing state"]),
            ("OBSERVABILITY", ["weekday and stock-by-age are hidden", "so o_t is an approximate state", "adding the weekday did not help:", f"return {_markov_numbers()}"])]
    for k, (t, ls) in enumerate(row2): d.box(8 + k * 248, 196, 240, 130, [H(t, CR, 13.5)] + [S(x, 12.8) for x in ls], "card", valign="top")
    d.box(8, 334, 984, 128, [H("OBJECTIVE", CR, 15), B("maximise   J(\u03c0) = E [ \u03a3  \u03b3^t \u00b7 r_{t+1} ]    over t = 0 \u2026 59,      \u03c0 = (\u03c0_p, \u03c0_i)", 17), S("measured as: designed return (profit \u2212 20 \u00d7 unmet), profit, wasted units, unmet demand, fill rate, safety violations", 13)], "rose")
    return d

def mdp_formal():
    d = D("MDP rules", 1000, 470)
    d.box(8, 8, 486, 150, [H("VIEW 1: MDP OF THE TEAM  (one decision-maker)", CR, 14), B("M = ( S, A, P, R, \u03b3, \u03c1_0 )", 14.5), S("A = A_p \u00d7 A_i  (9 joint actions)", 13), S("R = r^p + r^i   (one team reward)", 13), S("policy  \u03c0(a | o) = \u03c0_p(a_p | o) \u00b7 \u03c0_i(a_i | o, a_p)", 13), S("objective  J(\u03c0) = E[ \u03a3 \u03b3^t r_{t+1} ]", 13)], "rose", valign="top")
    d.box(506, 8, 486, 150, [H("VIEW 2: COOPERATIVE MARKOV GAME  (two agents)", CR, 14), B("G = ( S, A_p, A_i, P, R_p, R_i, \u03b3 )", 14.5), S("each agent k has its own reward r^k and J_k = E[ \u03a3 \u03b3^t r^k_{t+1} ]", 13), S("cooperative: team objective J = J_p + J_i", 13), S("the pricing agent acts first; the inventory agent sees its action", 13), S("training: MAPPO updates both policies together", 13)], "rose", valign="top")
    rules = [("1  MARKOV PROPERTY", ["P(s' | s, a) must not depend on", "earlier history.", "Simulator state s_t: yes.", "Observation o_t (6 numbers): the", "weekday is hidden, so approximate."]),
             ("2  REWARD", ["r_{t+1} depends only on", "(s_t, a_t, s_{t+1}):", "sold, expired, unmet, stock, order.", "Checked against the code", "(difference 0)."]),
             ("3  POLICY", ["\u03c0(a | o): stochastic while", "learning (sampling), greedy", "when tested.", "Unsafe actions get probability", "0 through the masks."]),
             ("4  RETURN AND VALUE", ["G_t = \u03a3_k \u03b3^k r_{t+k+1}", "V^\u03c0(s) = E[ G_t | s_t = s ]", "critics V_p(o), V_i(o, a_p)", "advantage A_t by GAE", "(\u03b3 0.97, \u03bb 0.95)."])]
    for k, (t, ls) in enumerate(rules): d.box(8 + k * 248, 168, 240, 170, [H(t, CR, 13.5)] + [S(x, 12.8) for x in ls], "card", valign="top")
    d.box(8, 348, 984, 114, [H("ONE EPISODE", CR, 14), B("s_0 ~ \u03c1_0;   for t = 0 \u2026 59:   observe o_t \u2192 pricing agent picks a_p \u2192 inventory agent picks a_i \u2192 store gives r_{t+1} and s_{t+1}", 13.5), S("terminal at t = 60 (time limit, no goal state); the next episode starts again from \u03c1_0", 13), S("only the simulator knows the true state; the agents see o_t and their own reward", 13)], "white")
    return d

def system():
    d = D("System design", 1000, 486)
    T = lambda y, t: d.text(8, y, 984, 18, [(t, True, 13.5, "#5A5650")], valign="top0")
    T(0, "1  INPUTS AND SIMULATOR")
    d.box(8, 24, 226, 82, [B("Demand model", 14), S("Poisson, weekday pattern,", 12), S("price response (assumed", 12), S("or measured from data)", 12)], "grey")
    d.box(246, 24, 226, 82, [B("Store settings", 14), S("cost Rs 35, price Rs 50,", 12), S("shelf life 4 days, shelf 45,", 12), S("order cost Rs 40", 12)], "grey")
    d.box(484, 24, 226, 82, [B("Scenarios", 14), S("seeds, demand shocks, quiet", 12), S("or busy shop, short shelf life,", 12), S("late deliveries, noisy readings", 12)], "grey")
    d.box(728, 24, 264, 82, [B("Store simulator (environment)", 14, "#2F5E22"), S("sell, age, expire, deliver,", 12), S("compute rewards", 12), S("retail_env_v3.py", 12)], "green")
    for x1, x2 in ((234, 246), (472, 484), (710, 728)): d.arrow(x1, 65, x2, 65, GREY, 2)
    T(120, "2  AGENTS ACT AND LEARN  (training: 16 episodes per iteration)")
    d.box(8, 142, 692, 112, [B("AGENTS   policy \u03c0 = (\u03c0_p, \u03c0_i)", 13.5, CR)], "rose", valign="top")
    d.box(18, 170, 128, 76, [B("State encoder", 13), S("6 numbers", 12), S("scaled to 0\u20131", 12)], "white")
    d.box(158, 170, 168, 76, [B("Pricing actor \u03c0_p", 13, CR), S("6\u219264\u219264\u21923", 12), S("critic V_p(s)", 12)], "white")
    d.box(338, 170, 168, 76, [B("Inventory actor \u03c0_i", 13, CR), S("9\u219264\u219264\u21923", 12), S("critic V_i(s, a_p)", 12)], "white")
    d.box(518, 170, 172, 76, [B("Safety masks", 13, "#8A5A00"), S("no sale below cost", 12), S("no overfull shelf", 12)], "amber")
    for x in (146, 326, 506): d.arrow(x, 208, x + 12, 208, CR, 2)
    d.arrow(860, 106, 860, 208, GREY, 2.4, head=False); d.arrow(860, 208, 700, 208, GREY, 2.4); d.text(716, 150, 140, 36, [B("1  state s_t", 12.5), S("and reward r_t", 12.5)], valign="top0")
    d.arrow(600, 142, 600, 126, CR, 2.4, head=False); d.arrow(600, 126, 800, 126, CR, 2.4, head=False); d.arrow(800, 126, 800, 106, CR, 2.4); d.text(612, 108, 180, 16, [B("2  action a_t", 12.5, CR)], valign="top0")
    T(264, "3  LEARNING SIGNAL")
    d.box(8, 286, 300, 74, [B("Rollout buffer", 14, "#2C5A99"), S("16 episodes \u00d7 60 days:", 12), S("states, actions, rewards, log-probs", 12)], "blue")
    d.box(328, 286, 664, 74, [B("PPO update  (4 passes per iteration)", 14, "#2C5A99"), S("advantages by GAE (\u03b3 0.97, \u03bb 0.95);  loss = \u2212min( ratio\u00b7A , clip(ratio, 0.8, 1.2)\u00b7A ) \u2212 0.01\u00b7entropy;", 12), S("critics fitted to the returns;  Adam, learning rate 1e-3", 12)], "blue")
    d.arrow(262, 254, 262, 286, "#2C5A99", 2.4); d.text(272, 258, 150, 16, [S("3  record", 12.5, "#2C5A99")], valign="top0")
    d.arrow(308, 323, 328, 323, "#2C5A99", 2.2)
    d.arrow(520, 286, 520, 254, "#2C5A99", 2.4); d.text(530, 258, 160, 16, [B("4  new weights", 12.5, "#2C5A99")], valign="top0")
    T(372, "4  EVALUATION AND OUTPUT  (frozen policy; fresh episodes the agents never trained on)")
    d.box(8, 394, 210, 86, [B("Frozen policy", 14), S("greedy: the most likely", 12), S("action, no exploration", 12)], "purple")
    d.box(236, 394, 236, 86, [B("Test episodes", 14), S("seen shop, plus unseen: quiet,", 12), S("busy, 2-day shelf, late deliveries,", 12), S("noisy readings", 12)], "purple")
    d.box(490, 394, 290, 86, [B("Metrics, compared with benchmarks", 13.5, "#5B3F8C"), S("return, success rate, regret, convergence,", 12), S("sample efficiency, generalization gap, stability,", 12), S("compute, waste, unmet, violations", 12)], "purple")
    d.box(798, 394, 194, 86, [B("Outputs", 14), S("report, app, shop assistant,", 12), S("advice tool, presentation", 12)], "white")
    for x in (218, 472, 780): d.arrow(x, 437, x + 18, 437, GREY, 2)
    return d

BUILD = [("mdp_loop", mdp_loop), ("mdp_tuple", mdp_tuple), ("mdp_formal", mdp_formal), ("system", system)]
if __name__ == "__main__":
    os.makedirs("diagrams", exist_ok=True); mx = ET.Element("mxfile", {"host": "app.diagrams.net", "version": "21.0.0"})
    for i, (name, fn) in enumerate(BUILD):
        dg = fn(); json.dump(dg.json(), open(f"diagrams/{name}.json", "w")); open(f"diagrams/{name}.svg", "w", encoding="utf-8").write(dg.svg()); mx.append(dg.drawio(i))
    ET.ElementTree(mx).write("diagrams/ARMS_diagrams.drawio", encoding="utf-8", xml_declaration=True); print("diagrams written:", [n for n, _ in BUILD])
