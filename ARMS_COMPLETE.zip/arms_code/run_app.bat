@echo off
cd /d "%~dp0"
echo Installing/checking libraries (first time only)...
python -m pip install -r requirements.txt
echo.
echo Starting the ARMS app. A browser tab will open. Close this window to stop it.
python -m streamlit run app.py
pause
