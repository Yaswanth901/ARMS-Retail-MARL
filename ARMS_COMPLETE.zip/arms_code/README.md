# ARMS: coordinated multi-agent RL for pricing and inventory of perishable goods

All demand, shop data and the price test are SIMULATED. Run in PowerShell with the environment activated, one command per line.

## Check everything
| Command | Expected | Time |
|---|---|---|
| `python final_tests.py` | `SUMMARY: 39 of 39 tests passed` | 4 min |
| `python rl_integrity_check.py` | `SUMMARY: 8 of 8 tests passed` | 2 min |
| `python check_mdp_diagram.py` | `SUMMARY: 17 of 17 checks passed` (every diagram field equals the code; reward formulas; Markov-property test) | 10 s |
| `python test_app.py --buttons` | `exception: none | page errors: none` | 15 s |

## Reproduce the evaluation (results are already saved in perf_*.csv, results_*.csv)
| Command | What it does | Time |
|---|---|---|
| `python select_entropy.py` | chooses the entropy bonus for PPO and MAPPO on validation episodes | 8 min |
| `python performance_suite.py rules` / `train --seeds 5` / `curves --seeds 5` / `ablation --seeds 3` | the five algorithms, rule benchmarks, learning curves and ablation | 25 min |
| `python make_figures.py` then `python collect_numbers.py` | figures, metrics, deck_data.json | 1 min |
| `python experiments_v3.py ablation | delays | pricing | pricing_waste` | stock-by-age, supplier delays, price response | 15 min |
| `python mappo_multi.py --seeds 2 --iters 120` | MAPPO in the three-product store | 3 min |
| `python mappo_numpy.py --seeds 10 --seed-start 5 --iterations 300 --out mappo_results_all.csv` | main agents used by the app | 12 min |
| `python multiagent_metrics.py` and `python multiagent_metrics.py quiet` | individual reward, cross-play, coordination, role use (5 teams) | 8 min |
| `python experiments_v3.py sensitivity --seeds 3 --iters 120` | learning rate, clip, gamma | 6 min |
| `python constrained_experiment.py` | the service-constrained MAPPO attempt (failed; see legacy_critic_results/failed_attempts) | 2 min |
| `python make_diagrams.py` | redraws the MDP and system diagrams (diagrams/) | 5 s |

## Tools and app
`python -m streamlit run app.py` (8 tabs), `python shop_assistant.py`, `python advise.py --stock 18 --expiry 2 --demand 11`, `python offer_bandit.py`, `python estimate_price_response.py`, `python calibrate_from_sales.py`.
The earlier results (before the critic fix) are archived in `legacy_critic_results/`.
