"""
MAPPO (Multi-Agent PPO) under Centralized-Training, Decentralized-Execution (CTDE)
for the two-agent retail Pricing/Inventory environment described in the proposal
(Section 8/9: State, Action, Reward, Policy=MAPPO, Objective).

Requires: pip install torch numpy pandas matplotlib
Not runnable in this sandbox (no internet/PyTorch here) - run on Colab or locally.
GPU not required for a problem this small; CPU training finishes in a few minutes.

Design:
  - Two actors (Pricing, Inventory), each a small MLP outputting action logits.
    Inventory's actor also receives the Pricing agent's action (one-hot) as input,
    preserving the sequential-dependency coordination described in Section 8.
  - Two CENTRALIZED critics (one per agent), each conditioned on the full joint
    state (both agents' observations concatenated) - this is the "centralized
    training" half of CTDE. At execution time only the actors are used, which
    is the "decentralized execution" half.
  - Standard clipped-surrogate PPO objective + GAE advantage estimation.
"""
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Categorical

# ---------------------------------------------------------------- Environment
PRICE_ACTIONS = ["REGULAR_PRICE", "MODERATE_DISCOUNT", "CLEARANCE_DISCOUNT"]
PRICE_MULTIPLIER = [1.0, 0.85, 0.65]
DEMAND_LIFT = [1.0, 1.15, 1.3]          # calibrated so discounts are a real margin trade-off, not free revenue
INV_ACTIONS = ["NO_REORDER", "SMALL_REORDER", "FULL_REORDER"]
REORDER_QTY = [0, 10, 25]

BASE_PRICE, BASE_DEMAND, SHELF_LIFE, EXCESS_THRESHOLD = 50.0, 12.0, 4, 35
LAMBDA_W, LAMBDA_S, LAMBDA_E = 4.0, 3.0, 2.5


class RetailEnvTorch:
    """Same economics as retail_env.py, but returns normalized float vectors
    (neural nets need continuous inputs, not the discretized bins used for the
    tabular baseline)."""

    def __init__(self, horizon=60, seed=None):
        self.horizon = horizon
        self.rng = np.random.default_rng(seed)
        self.reset()

    def reset(self):
        self.day = 0
        self.batches = [[20, SHELF_LIFE]]
        return self._obs()

    def _stock(self):
        return sum(b[0] for b in self.batches)

    def _expiry(self):
        return min((b[1] for b in self.batches), default=SHELF_LIFE)

    def _obs(self, recent_demand=BASE_DEMAND):
        seasonality = 1.15 if (self.day % 7) in (5, 6) else 1.0
        # normalized: stock/50, expiry/4, demand/25, seasonality already ~1
        return np.array([self._stock() / 50.0, self._expiry() / SHELF_LIFE,
                          recent_demand / 25.0, seasonality], dtype=np.float32)

    def step(self, price_idx, inv_idx):
        seasonality = 1.15 if (self.day % 7) in (5, 6) else 1.0
        expected_demand = BASE_DEMAND * DEMAND_LIFT[price_idx] * seasonality
        demand = max(0, self.rng.poisson(expected_demand))

        units_sold, remaining = 0, demand
        for b in self.batches:
            if remaining <= 0:
                break
            take = min(b[0], remaining)
            b[0] -= take; units_sold += take; remaining -= take
        stockout = max(0, demand - units_sold)
        revenue = units_sold * BASE_PRICE * PRICE_MULTIPLIER[price_idx]

        wastage, kept = 0, []
        for b in self.batches:
            b[1] -= 1
            if b[1] <= 0:
                wastage += b[0]
            elif b[0] > 0:
                kept.append(b)
        self.batches = kept
        if REORDER_QTY[inv_idx] > 0:
            self.batches.append([REORDER_QTY[inv_idx], SHELF_LIFE])
        excess = max(0, self._stock() - EXCESS_THRESHOLD)

        r_price = revenue - LAMBDA_W * wastage
        r_inv = units_sold - LAMBDA_S * stockout - LAMBDA_E * excess

        self.day += 1
        done = self.day >= self.horizon
        return self._obs(demand), (r_price, r_inv), done, dict(
            revenue=revenue, wastage=wastage, stockout=stockout, demand=demand, units_sold=units_sold)


# ---------------------------------------------------------------- Networks
HIDDEN = 64

class Actor(nn.Module):
    def __init__(self, obs_dim, n_actions):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(obs_dim, HIDDEN), nn.Tanh(),
                                  nn.Linear(HIDDEN, HIDDEN), nn.Tanh(),
                                  nn.Linear(HIDDEN, n_actions))

    def forward(self, x):
        return self.net(x)  # logits


class CentralizedCritic(nn.Module):
    """Conditioned on the FULL joint state (both agents' observations) -
    this is what makes training "centralized" under CTDE."""
    def __init__(self, joint_obs_dim):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(joint_obs_dim, HIDDEN), nn.Tanh(),
                                  nn.Linear(HIDDEN, HIDDEN), nn.Tanh(),
                                  nn.Linear(HIDDEN, 1))

    def forward(self, x):
        return self.net(x).squeeze(-1)


# ---------------------------------------------------------------- MAPPO agent
class MAPPO:
    def __init__(self, obs_dim=4, lr=3e-4, gamma=0.97, gae_lambda=0.95,
                 clip_eps=0.2, epochs=4, device="cpu"):
        self.gamma, self.gae_lambda, self.clip_eps, self.epochs = gamma, gae_lambda, clip_eps, epochs
        self.device = device
        joint_dim = obs_dim * 2  # critic sees both agents' observations

        self.actor_p = Actor(obs_dim, 3).to(device)                 # pricing: sees own obs
        self.actor_i = Actor(obs_dim + 3, 3).to(device)              # inventory: own obs + pricing's one-hot action
        self.critic_p = CentralizedCritic(joint_dim).to(device)
        self.critic_i = CentralizedCritic(joint_dim).to(device)

        params = list(self.actor_p.parameters()) + list(self.actor_i.parameters()) \
               + list(self.critic_p.parameters()) + list(self.critic_i.parameters())
        self.opt = optim.Adam(params, lr=lr)

    def act(self, obs):
        obs_t = torch.as_tensor(obs, dtype=torch.float32, device=self.device)
        logits_p = self.actor_p(obs_t)
        dist_p = Categorical(logits=logits_p)
        p_idx = dist_p.sample()
        logp_p = dist_p.log_prob(p_idx)

        p_onehot = torch.zeros(3, device=self.device); p_onehot[p_idx] = 1.0
        inv_in = torch.cat([obs_t, p_onehot])
        logits_i = self.actor_i(inv_in)
        dist_i = Categorical(logits=logits_i)
        i_idx = dist_i.sample()
        logp_i = dist_i.log_prob(i_idx)

        return int(p_idx), int(i_idx), float(logp_p), float(logp_i)

    def gae(self, rewards, values, dones):
        T = len(rewards)
        adv = np.zeros(T, dtype=np.float32)
        last_gae = 0.0
        for t in reversed(range(T)):
            next_v = 0.0 if (t == T - 1 or dones[t]) else values[t + 1]
            delta = rewards[t] + self.gamma * next_v * (1 - dones[t]) - values[t]
            last_gae = delta + self.gamma * self.gae_lambda * (1 - dones[t]) * last_gae
            adv[t] = last_gae
        returns = adv + np.array(values, dtype=np.float32)
        return adv, returns

    def update(self, batch):
        """batch: dict of lists collected over one or more rollouts - see train loop below."""
        obs = torch.as_tensor(np.array(batch["obs"]), dtype=torch.float32, device=self.device)
        joint_obs = torch.as_tensor(np.array(batch["joint_obs"]), dtype=torch.float32, device=self.device)
        p_idx = torch.as_tensor(batch["p_idx"], device=self.device)
        i_idx = torch.as_tensor(batch["i_idx"], device=self.device)
        p_onehot = torch.nn.functional.one_hot(p_idx, 3).float()
        old_logp_p = torch.as_tensor(batch["logp_p"], dtype=torch.float32, device=self.device)
        old_logp_i = torch.as_tensor(batch["logp_i"], dtype=torch.float32, device=self.device)

        adv_p, ret_p = self.gae(batch["r_price"], batch["v_price"], batch["done"])
        adv_i, ret_i = self.gae(batch["r_inv"], batch["v_inv"], batch["done"])
        adv_p = (adv_p - adv_p.mean()) / (adv_p.std() + 1e-8)
        adv_i = (adv_i - adv_i.mean()) / (adv_i.std() + 1e-8)
        adv_p_t = torch.as_tensor(adv_p, dtype=torch.float32, device=self.device)
        adv_i_t = torch.as_tensor(adv_i, dtype=torch.float32, device=self.device)
        ret_p_t = torch.as_tensor(ret_p, dtype=torch.float32, device=self.device)
        ret_i_t = torch.as_tensor(ret_i, dtype=torch.float32, device=self.device)

        for _ in range(self.epochs):
            logits_p = self.actor_p(obs)
            dist_p = Categorical(logits=logits_p)
            new_logp_p = dist_p.log_prob(p_idx)
            ratio_p = torch.exp(new_logp_p - old_logp_p)
            surr1 = ratio_p * adv_p_t
            surr2 = torch.clamp(ratio_p, 1 - self.clip_eps, 1 + self.clip_eps) * adv_p_t
            loss_actor_p = -torch.min(surr1, surr2).mean() - 0.01 * dist_p.entropy().mean()

            inv_in = torch.cat([obs, p_onehot], dim=-1)
            logits_i = self.actor_i(inv_in)
            dist_i = Categorical(logits=logits_i)
            new_logp_i = dist_i.log_prob(i_idx)
            ratio_i = torch.exp(new_logp_i - old_logp_i)
            surr1i = ratio_i * adv_i_t
            surr2i = torch.clamp(ratio_i, 1 - self.clip_eps, 1 + self.clip_eps) * adv_i_t
            loss_actor_i = -torch.min(surr1i, surr2i).mean() - 0.01 * dist_i.entropy().mean()

            v_p = self.critic_p(joint_obs)
            v_i = self.critic_i(joint_obs)
            loss_critic = nn.functional.mse_loss(v_p, ret_p_t) + nn.functional.mse_loss(v_i, ret_i_t)

            loss = loss_actor_p + loss_actor_i + 0.5 * loss_critic
            self.opt.zero_grad(); loss.backward(); self.opt.step()


# ---------------------------------------------------------------- Training loop
def train(n_episodes=800, horizon=60, seed=0, device="cpu"):
    torch.manual_seed(seed)
    agent = MAPPO(device=device)
    history = []

    for ep in range(n_episodes):
        env = RetailEnvTorch(horizon=horizon, seed=seed + ep)
        obs = env.reset()
        batch = {k: [] for k in ["obs", "joint_obs", "p_idx", "i_idx", "logp_p", "logp_i",
                                  "r_price", "r_inv", "v_price", "v_inv", "done"]}
        ep_reward, ep_revenue, ep_waste, ep_stockout = 0, 0, 0, 0

        for t in range(horizon):
            p_idx, i_idx, logp_p, logp_i = agent.act(obs)
            joint_obs = np.concatenate([obs, obs])  # both agents see the same store state here;
                                                      # swap for true per-agent partial obs if you extend this
            with torch.no_grad():
                jo_t = torch.as_tensor(joint_obs, dtype=torch.float32)
                v_p = float(agent.critic_p(jo_t)); v_i = float(agent.critic_i(jo_t))

            next_obs, (r_p, r_i), done, info = env.step(p_idx, i_idx)

            for k, v in zip(batch.keys(),
                             [obs, joint_obs, p_idx, i_idx, logp_p, logp_i, r_p, r_i, v_p, v_i, done]):
                batch[k].append(v)

            ep_reward += r_p + r_i
            ep_revenue += info["revenue"]; ep_waste += info["wastage"]; ep_stockout += info["stockout"]
            obs = next_obs

        agent.update(batch)
        history.append(dict(episode=ep, total_reward=ep_reward, revenue=ep_revenue,
                             wastage=ep_waste, stockout=ep_stockout))
        if ep % 50 == 0:
            print(f"ep {ep:4d}  reward {ep_reward:9.0f}  wastage {ep_waste:5.1f}  stockout {ep_stockout:5.1f}")

    return agent, history


if __name__ == "__main__":
    agent, history = train(n_episodes=800)
    import pandas as pd
    pd.DataFrame(history).to_csv("mappo_results.csv", index=False)
    print("Saved mappo_results.csv - compare this against results_two_agent.csv "
          "(tabular baseline) to show deep-RL MAPPO vs tabular independent Q-learning.")
