"""
MAPPO for the three-product store (milk, curd, bread sharing ONE shelf).
Same algorithm as mappo_numpy.py, with parameter sharing: one pricing network and one inventory network serve all three products
(each product is tagged with a one-hot id), and the centralised critics also see the stock of ALL products, so training can account
for the products competing for shelf space. Run:  python mappo_multi.py --seeds 4 --iters 120
"""
import argparse, json, os, time
import numpy as np, pandas as pd
import mappo_numpy as M
import retail_env_multi as RM
import agents_multi as A
from retail_env_multi import MultiStoreEnv, PRODUCTS, N, CAPACITY
from retail_env_v2 import PRICE_ACTIONS, INV_ACTIONS, REORDER_QTY, PRICE_MULTIPLIER

HERE = os.path.dirname(os.path.abspath(__file__)); HORIZON, REWARD_SCALE = 60, 0.01

def feat(s):
    k = s["product"]; P = PRODUCTS[k]; oh = np.zeros(N); oh[k] = 1.0
    return np.concatenate([[s["stock"] / 30.0, min(s["days_to_expiry"], 6) / 6.0, s["recent_demand"] / (1.5 * P["demand"]), s["seasonality"], s["shelf_used"] / CAPACITY], oh])

def pmask(s):
    P = PRODUCTS[s["product"]]
    return np.array([0.0 if (P["price"] * PRICE_MULTIPLIER[a] < P["cost"] and s["days_to_expiry"] > 1) else 1.0 for a in PRICE_ACTIONS])

def imask(s):
    room = max(CAPACITY - s["shelf_used"], 0)
    return np.array([1.0 if (a == "NO_REORDER" or REORDER_QTY[a] <= room) else 0.0 for a in INV_ACTIONS])


class MAPPOMulti:
    def __init__(self, seed=0, hidden=64, lr=1e-3, gamma=0.97, lam=0.95, clip=0.2, epochs=4, minibatch=256, ent=M._selected_entropy("MAPPO")):
        self.rng = np.random.default_rng(seed); r = self.rng
        self.actor_p = M.MLP([8, hidden, hidden, 3], r, 0.01); self.actor_i = M.MLP([11, hidden, hidden, 3], r, 0.01)
        self.crit_p = M.MLP([11, hidden, hidden, 1], r, 1.0); self.crit_i = M.MLP([14, hidden, hidden, 1], r, 1.0)   # pricing critic does not see the price choice
        self.lr, self.gamma, self.lam, self.clip, self.epochs, self.minibatch, self.ent = lr, gamma, lam, clip, epochs, minibatch, ent

    def act(self, states, k, greedy=False):
        s = states[k]; x = feat(s)[None]; mp = pmask(s)
        pp = M.masked_probs(self.actor_p.forward(x)[0], mp)[0]; a_p = int(np.argmax(pp)) if greedy else int(self.rng.choice(3, p=pp))
        xi = np.concatenate([x[0], np.eye(3)[a_p]])[None]; mi = imask(s)
        pi = M.masked_probs(self.actor_i.forward(xi)[0], mi)[0]; a_i = int(np.argmax(pi)) if greedy else int(self.rng.choice(3, p=pi))
        if greedy: return a_p, a_i
        stk = [st["stock"] / 30.0 for st in states]; xc = np.concatenate([xi[0], stk])[None]; xcp = np.concatenate([x[0], stk])[None]   # critic inputs include every product's stock
        return dict(xp=x[0], mp=mp, ap=a_p, lpp=float(np.log(pp[a_p] + 1e-12)), xi=xi[0], mi=mi, ai=a_i, lpi=float(np.log(pi[a_i] + 1e-12)),
                    xc=xc[0], xcp=xcp[0], vp=float(self.crit_p.forward(xcp)[0][0, 0]), vi=float(self.crit_i.forward(xc)[0][0, 0]))

    def _gae(self, r, v):
        T = len(r); adv = np.zeros(T); g = 0.0
        for t in reversed(range(T)):
            nv = 0.0 if t == T - 1 else v[t + 1]; g = (r[t] + self.gamma * nv - v[t]) + self.gamma * self.lam * g; adv[t] = g
        return adv, adv + np.array(v)

    def update(self, trajs):
        keys = ["xp", "mp", "ap", "lpp", "xi", "mi", "ai", "lpi", "xc", "xcp"]; cols = {k: [] for k in keys}; A_p, R_p, A_i, R_i = [], [], [], []
        for tr in trajs:
            for k in keys: cols[k] += [st[k] for st in tr["steps"]]
            a1, r1 = self._gae(tr["rp"], [st["vp"] for st in tr["steps"]]); a2, r2 = self._gae(tr["ri"], [st["vi"] for st in tr["steps"]])
            A_p.append(a1); R_p.append(r1); A_i.append(a2); R_i.append(r2)
        D = {k: np.array(v) for k, v in cols.items()}; A_p, R_p, A_i, R_i = map(np.concatenate, (A_p, R_p, A_i, R_i))
        A_p = (A_p - A_p.mean()) / (A_p.std() + 1e-8); A_i = (A_i - A_i.mean()) / (A_i.std() + 1e-8); n = len(A_p)
        for _ in range(self.epochs):
            idx = self.rng.permutation(n)
            for lo in range(0, n, self.minibatch):
                b = idx[lo:lo + self.minibatch]
                _, gW, gb = M.actor_loss_and_grads(self.actor_p, D["xp"][b], D["mp"][b], D["ap"][b], D["lpp"][b], A_p[b], self.clip, self.ent); self.actor_p.adam(gW, gb, self.lr)
                _, gW, gb = M.actor_loss_and_grads(self.actor_i, D["xi"][b], D["mi"][b], D["ai"][b], D["lpi"][b], A_i[b], self.clip, self.ent); self.actor_i.adam(gW, gb, self.lr)
                _, gW, gb = M.critic_loss_and_grads(self.crit_p, D["xcp"][b], R_p[b]); self.crit_p.adam(gW, gb, self.lr)
                _, gW, gb = M.critic_loss_and_grads(self.crit_i, D["xc"][b], R_i[b]); self.crit_i.adam(gW, gb, self.lr)

    def policy(self):
        def f(states):
            out = []
            for k in range(N):
                a_p, a_i = self.act(states, k, greedy=True); out.append((PRICE_ACTIONS[a_p], INV_ACTIONS[a_i]))
            return out
        return f


def rollout(agent, seed, it, n_episodes):
    trajs, profits = [], []
    for j in range(n_episodes):
        env = MultiStoreEnv(HORIZON, seed=seed * 1_000_000 + it * 1000 + j); states = env.reset()
        T = [dict(steps=[], rp=[], ri=[]) for _ in range(N)]; prof = 0.0
        for _ in range(HORIZON):
            ds = [agent.act(states, k) for k in range(N)]
            states, rewards, _, infos = env.step([(PRICE_ACTIONS[d["ap"]], INV_ACTIONS[d["ai"]]) for d in ds])
            for k in range(N):
                T[k]["steps"].append(ds[k]); T[k]["rp"].append(rewards[k][0] * REWARD_SCALE); T[k]["ri"].append(rewards[k][1] * REWARD_SCALE); prof += infos[k]["profit"]
        trajs += T; profits.append(prof)
    return trajs, float(np.mean(profits))

def train(seed=0, iterations=120, episodes_per_iter=8):
    agent = MAPPOMulti(seed); curve = []
    for it in range(iterations):
        trajs, mp_ = rollout(agent, seed, it, episodes_per_iter); agent.update(trajs); curve.append(mp_)
    return agent, curve

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--seeds", type=int, default=4); ap.add_argument("--iters", type=int, default=120); ap.add_argument("--out", default="results_multi_mappo.csv"); a = ap.parse_args()
    targets = json.load(open(os.path.join(HERE, "store3_tuned_targets.json")))["targets"]; rows = []
    ev = lambda pol: A.evaluate(pol, n=60)
    for name, pol in (("Original rule", A.policy_original), ("Tuned order-up-to rule", A.policy_tuned(targets))):
        d = ev(pol); rows.append(dict(method=name, seed="-", profit=d.profit.mean(), wasted=d.wasted.mean(), unmet=d.unmet.mean(), cuts=d.cuts.mean()))
    print("rules:", [(r["method"], round(r["profit"])) for r in rows], flush=True)
    for sd in range(a.seeds):
        t0 = time.time(); ag, curve = train(seed=700 + sd, iterations=a.iters); d = ev(ag.policy())
        rows.append(dict(method=f"MAPPO (shared networks, shared-shelf critic, {a.iters} iterations)", seed=sd, profit=d.profit.mean(), wasted=d.wasted.mean(), unmet=d.unmet.mean(), cuts=d.cuts.mean()))
        print(f"seed {sd}: training profit {curve[0]:,.0f} -> {curve[-1]:,.0f}; fresh-episode profit {d.profit.mean():,.0f} ({time.time()-t0:.0f}s)", flush=True)
        pd.DataFrame(rows).to_csv(os.path.join(HERE, a.out), index=False)
