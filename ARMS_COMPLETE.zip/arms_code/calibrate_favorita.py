"""
Learn the SHAPE of real grocery demand from the Corporacion Favorita data and feed it to the simulator.

What it measures (for perishable items in one store):
  - weekly pattern     : demand multiplier for Monday..Sunday (average = 1)
  - variability        : variance / mean of daily sales (a Poisson process has 1.0; real sales are usually higher)
  - promotion lift     : average sales on promotion days / non-promotion days
  - promotion share    : fraction of days an item is on promotion

What it does NOT give us (be honest about this):
  - the effect of a PRICE change. Favorita has no price column; 'onpromotion' is only a flag.
    So the simulator's price-response stays an assumption. The promotion lift is a rough sanity check only.
  - absolute volume. The simulator keeps its own average (12 a day); only the weekly shape is taken from the data.

Supported files (put them in one folder, e.g. C:\\Users\\you\\Downloads\\favorita):
  A) Kaggle "Corporacion Favorita Grocery Sales Forecasting":  train.csv + items.csv (has a 'perishable' column)
  B) Kaggle "Store Sales - Time Series Forecasting":           train.csv (has 'family' and 'sales' columns)

Usage:
    python calibrate_favorita.py --data-dir "C:\\path\\to\\favorita"
    python calibrate_favorita.py --data-dir ... --store 44 --top-items 20 --max-rows 20000000   # quicker trial
    python calibrate_favorita.py --data-dir ... --family DAIRY                                 # format B
Output: demand_profile.json  (the app and demo load it automatically if present)
"""
import os
BASE = os.path.dirname(os.path.abspath(__file__))
import argparse
import json
import sys
import numpy as np
import pandas as pd


def to_flag(series):
    """onpromotion appears as True/False text, blanks, or integer counts depending on the file version."""
    text = series.astype(str).str.strip().str.lower()
    mapped = text.map({"true": 1, "false": 0, "nan": 0, "none": 0, "": 0})
    numeric = pd.to_numeric(text, errors="coerce")
    return (mapped.fillna(numeric).fillna(0) > 0)


def read_filtered(train_path, usecols, keep, max_rows, chunk_rows=2_000_000):
    parts, seen = [], 0
    for chunk in pd.read_csv(train_path, usecols=usecols, chunksize=chunk_rows, low_memory=False):
        seen += len(chunk)
        sub = keep(chunk)
        if len(sub):
            parts.append(sub)
        print(f"  read {seen:,} rows, kept {sum(len(p) for p in parts):,}", end="\r", flush=True)
        if max_rows and seen >= max_rows:
            break
    print()
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame(columns=usecols)


def series_metrics(daily):
    """daily: DataFrame with columns date, sales, promo (one row per day, gaps already filled with 0)."""
    daily = daily.copy()
    daily["dow"] = daily["date"].dt.dayofweek          # 0 = Monday
    mean = daily["sales"].mean()
    if mean <= 0:
        return None
    dow_mean = daily.groupby("dow")["sales"].mean().reindex(range(7))
    if dow_mean.isna().any():
        return None
    weekday = (dow_mean / dow_mean.mean()).to_numpy()
    resid = daily["sales"] - daily["dow"].map(dow_mean)
    dispersion = float(resid.var(ddof=1) / mean)
    promo = daily["promo"].astype(bool)
    # promotion lift uses only days that have a sales record: zero-filled gaps carry no promo flag,
    # so counting them as 'no promotion' would inflate the lift
    obs = daily["observed"].astype(bool)
    lift = np.nan
    if (promo & obs).sum() >= 10 and (~promo & obs).sum() >= 10 and daily.loc[~promo & obs, "sales"].mean() > 0:
        lift = float(daily.loc[promo & obs, "sales"].mean() / daily.loc[~promo & obs, "sales"].mean())
    return dict(weekday=weekday, dispersion=dispersion, lift=lift, promo_share=float(promo.mean()), mean=float(mean))


def fill_days(df):
    """Reindex to the full date range between first and last record; absent days count as zero sales."""
    full = pd.date_range(df["date"].min(), df["date"].max(), freq="D")
    out = df.set_index("date").reindex(full)
    out["observed"] = out["sales"].notna()                       # True = a sales record exists for that day
    out["sales"] = out["sales"].fillna(0).clip(lower=0)      # returns are negative; treat as 0
    out["promo"] = out["promo"].fillna(False)
    out = out.rename_axis("date").reset_index()
    return out


def main():
    ap = argparse.ArgumentParser(description="Calibrate the simulator's demand shape from Favorita data")
    ap.add_argument("--data-dir", required=True)
    ap.add_argument("--store", type=int, default=44, help="store_nbr to use (default 44)")
    ap.add_argument("--top-items", type=int, default=20, help="how many best-selling perishable items to average")
    ap.add_argument("--family", default=None, help="restrict to one product family, e.g. DAIRY")
    ap.add_argument("--max-rows", type=int, default=0, help="stop after this many rows of train.csv (quick trial)")
    ap.add_argument("--out", default=os.path.join(BASE, "demand_profile.json"))
    a = ap.parse_args()

    train_path = os.path.join(a.data_dir, "train.csv")
    items_path = os.path.join(a.data_dir, "items.csv")
    if not os.path.exists(train_path):
        sys.exit(f"Cannot find {train_path}. Check --data-dir (the folder that contains train.csv).")
    header = list(pd.read_csv(train_path, nrows=1).columns)
    print("train.csv columns:", header)

    series = []     # list of per-item (or per-family) daily DataFrames

    if "unit_sales" in header:                                   # ---- format A: item level
        if not os.path.exists(items_path):
            sys.exit("Format A needs items.csv next to train.csv (it has the 'perishable' flag).")
        items = pd.read_csv(items_path)
        print("items.csv columns:", list(items.columns))
        if "perishable" not in items.columns:
            sys.exit("items.csv has no 'perishable' column.")
        sel = items[items["perishable"] == 1]
        if a.family:
            sel = sel[sel["family"].str.upper() == a.family.upper()]
        keep_items = set(sel["item_nbr"].astype(int))
        print(f"{len(keep_items):,} perishable items" + (f" in family {a.family}" if a.family else ""))
        cols = [c for c in ["date", "store_nbr", "item_nbr", "unit_sales", "onpromotion"] if c in header]
        df = read_filtered(train_path, cols,
                           lambda c: c[(c["store_nbr"] == a.store) & (c["item_nbr"].isin(keep_items))], a.max_rows)
        if df.empty:
            sys.exit(f"No rows for store {a.store}. Try another --store, or drop --max-rows limits.")
        df["date"] = pd.to_datetime(df["date"])
        df["promo"] = to_flag(df["onpromotion"]) if "onpromotion" in df else False
        df = df.rename(columns={"unit_sales": "sales"})
        top = df.groupby("item_nbr")["date"].nunique().sort_values(ascending=False).head(a.top_items).index
        for item in top:
            g = df[df["item_nbr"] == item].groupby("date").agg(sales=("sales", "sum"), promo=("promo", "max")).reset_index()
            series.append(fill_days(g))
        source = "Favorita item-level (train.csv + items.csv)"
    elif "sales" in header and "family" in header:               # ---- format B: family level
        fams = [a.family] if a.family else None
        cols = [c for c in ["date", "store_nbr", "family", "sales", "onpromotion"] if c in header]
        df = read_filtered(train_path, cols,
                           lambda c: c[(c["store_nbr"] == a.store) & (c["family"].isin(fams) if fams else True)], a.max_rows)
        if df.empty:
            sys.exit(f"No rows for store {a.store}" + (f" and family {a.family}" if a.family else "") + ".")
        df["date"] = pd.to_datetime(df["date"])
        df["promo"] = to_flag(df["onpromotion"]) if "onpromotion" in df else False
        perishable_fams = ["DAIRY", "BREAD/BAKERY", "PRODUCE", "EGGS", "DELI", "POULTRY", "MEATS", "PREPARED FOODS", "SEAFOOD"]
        use = [a.family] if a.family else [f for f in perishable_fams if f in set(df["family"])]
        for fam in use:
            g = df[df["family"] == fam].groupby("date").agg(sales=("sales", "sum"), promo=("promo", "max")).reset_index()
            if len(g) >= 60:
                series.append(fill_days(g))
        source = "Store Sales (family-level; each family is one series)"
    else:
        sys.exit("Unrecognised train.csv. Expected 'unit_sales' (format A) or 'sales' + 'family' (format B).")

    metrics = [m for m in (series_metrics(s) for s in series) if m]
    if not metrics:
        sys.exit("Not enough data to compute a weekly pattern (need at least a few weeks per series).")

    weekday = np.mean([m["weekday"] for m in metrics], axis=0)
    weekday = weekday / weekday.mean()
    lifts = [m["lift"] for m in metrics if not np.isnan(m["lift"])]
    profile = {
        "source": source, "store": a.store, "n_series": len(metrics),
        "weekday_mult": [round(float(x), 4) for x in weekday],           # Monday .. Sunday
        "dispersion_index_median": round(float(np.median([m["dispersion"] for m in metrics])), 2),
        "promo_lift_median": round(float(np.median(lifts)), 3) if lifts else None,
        "promo_day_share_median": round(float(np.median([m["promo_share"] for m in metrics])), 3),
        "note": ("Only the weekly SHAPE is used by the simulator. Dispersion above 1 means real demand is noisier "
                 "than the simulator's Poisson draws. Promotion lift is confounded and does not identify "
                 "price elasticity."),
    }
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(profile, f, indent=2)

    names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    print("\n=== demand profile (store %d, %d series) ===" % (a.store, len(metrics)))
    print("weekly pattern :", "  ".join(f"{n} {v:.2f}" for n, v in zip(names, profile["weekday_mult"])))
    print("variance/mean  :", profile["dispersion_index_median"], "(simulator assumes 1.0)")
    print("promo lift     :", profile["promo_lift_median"], "x on promotion days (not a price elasticity)")
    print("promo day share:", profile["promo_day_share_median"])
    print("saved ->", a.out)


if __name__ == "__main__":
    main()
