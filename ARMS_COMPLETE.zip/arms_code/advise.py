"""TOMORROW'S ADVICE: a decision-support tool for a shopkeeper.
Type what you see in the shop; get a recommended price and order quantity, the reason, and safety checks.
Example:  python advise.py --stock 18 --expiry 2 --demand 11
          python advise.py --stock 30 --expiry 4 --demand 6 --weekend"""
import argparse, numpy as np
import app_core as C, mappo_numpy as M
from retail_env_v2 import BASE_PRICE, PRICE_MULTIPLIER, REORDER_QTY, UNIT_COST, MAX_STOCK

ap = argparse.ArgumentParser()
ap.add_argument("--stock", type=int, required=True, help="packets on the shelf now")
ap.add_argument("--expiry", type=int, required=True, help="days left for the OLDEST packets (1 to 4)")
ap.add_argument("--demand", type=float, default=12.0, help="average packets sold per day over the last few days")
ap.add_argument("--shelf", type=int, default=4, help="shelf life of this product in days")
ap.add_argument("--weekend", action="store_true", help="tomorrow is a weekend day")
a = ap.parse_args()

s = dict(stock=a.stock, days_to_expiry=a.expiry, demand_ema=a.demand, recent_demand=a.demand,
         expiring=a.stock if a.expiry <= 1 else 0, seasonality=1.15 if a.weekend else 1.0)
agent = C.get_mappo() if hasattr(C, "get_mappo") else M.MAPPO.load("mappo_weights/seed6.npz", 6)
mp = agent.policy()
rule_p, rule_i, *_ = C.SS_RULE(s)
ml_p, ml_i, *_ = mp(s)

# confidence of the learned agent (probability it gives its chosen reorder)
x = M.features(s)[None]
pp = M.masked_probs(agent.actor_p.forward(x)[0], M.price_mask(s))[0]; a_p = int(np.argmax(pp))
xi = np.concatenate([x[0], np.eye(3)[a_p]])[None]
pi = M.masked_probs(agent.actor_i.forward(xi)[0], M.inv_mask(s))[0]

changed = a.demand < 0.75 * 12.0 or a.shelf < 4
mode = "CONDITIONS HAVE CHANGED -> using the learned agent" if changed else "NORMAL CONDITIONS -> using the proven (s,S) rule"
price_a, inv_a = (ml_p, ml_i) if changed else (rule_p, rule_i)
price = BASE_PRICE * PRICE_MULTIPLIER[price_a]; qty = REORDER_QTY[inv_a]

print("=" * 66); print("TOMORROW'S ADVICE (simulated store; numbers are assumptions)"); print("=" * 66)
print(f"You told me : {a.stock} packets on the shelf, oldest has {a.expiry} day(s) left, selling about {a.demand:g} a day"
      f"{', weekend' if a.weekend else ''}, shelf life {a.shelf} days")
print(f"Mode        : {mode}")
print(f"\nRECOMMENDATION:  price Rs {price:.1f}   |   order {qty} packets\n")
print("Why:")
if qty == 0: print(f"  - You have {a.stock} packets, enough to cover tomorrow, so ordering now would only add cost and risk spoilage.")
else: print(f"  - Stock ({a.stock}) is low; ordering {qty} now avoids empty shelves. Each order has a fixed Rs 40 cost, so we order a full batch instead of small amounts.")
if price < BASE_PRICE: print(f"  - The oldest packets expire in {a.expiry} day(s); a discount sells them before they are wasted.")
else: print("  - Regular price: a discount would cut the profit per packet from Rs 15 to about Rs 7.5, so it only pays when packets are about to expire.")
print("\nSafety checks:")
print(f"  - Price is {'above' if price >= UNIT_COST else 'BELOW'} the unit cost of Rs {UNIT_COST}" + ("" if price >= UNIT_COST else " (allowed only because stock expires within a day)"))
print(f"  - Shelf after ordering: {min(a.stock + qty, MAX_STOCK)} of {MAX_STOCK} packets" + ("  (order trimmed to fit)" if a.stock + qty > MAX_STOCK else ""))
print("\nSecond opinions:")
print(f"  - Tuned (s,S) rule     : price Rs {BASE_PRICE*PRICE_MULTIPLIER[rule_p]:.1f}, order {REORDER_QTY[rule_i]}")
print(f"  - Learned MAPPO agent  : price Rs {BASE_PRICE*PRICE_MULTIPLIER[ml_p]:.1f}, order {REORDER_QTY[ml_i]}  (confidence in its reorder choice: {pi.max():.0%})")
print("\nThis is advice, not an order: you decide. It is trained on a simulator, so check it against your own judgement.")
