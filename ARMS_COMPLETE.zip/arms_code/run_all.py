"""
Runs the whole project in order and builds ARMS_report.html at the end.

    python run_all.py            # everything (about 20-25 minutes)
    python run_all.py --quick    # skips the slowest steps and reuses the saved results (about 8-10 minutes)

If one step fails, the others still run, and a summary at the end tells you which one failed.
"""
import os
BASE = os.path.dirname(os.path.abspath(__file__))
import subprocess
import sys
import time

QUICK = "--quick" in sys.argv
# (label, command, slow?)
STEPS = [
    ("v1: train rule-based, single-agent and two-agent Q-learning", ["train.py"], False),
    ("v1: learning-curve chart", ["make_results.py"], False),
    ("v1: neural (NFQ) agents", ["train_nfq.py"], True),
    ("v1: five-method comparison", ["make_results_full.py"], False),
    ("v1: eight-seed significance test", ["multi_seed_eval.py"], True),
    ("v1: perfect-foresight upper bound", ["oracle_bound.py"], True),
    ("v2: real profit costs, guardrails, fallback", ["train_v2.py"], False),
    ("v2: five-seed check", ["multi_seed_v2.py"], True),
    ("v4: tuned no-learning baseline", ["tune_baseline.py"], False),
    ("v6: tuned (s,S) baseline", ["tune_sS.py"], False),
    ("v6: MAPPO, 15 training seeds (slow)", ["mappo_numpy.py", "--seeds", "15", "--out", "mappo_results_all.csv"], True),
    ("v6: MAPPO re-test on 300 new episodes", ["mappo_validate.py"], False),
    ("v6: MAPPO stress test", ["mappo_stress.py"], False),
    ("v4: stress test", ["demo_cli.py", "--stress"], False),
    ("v4: can RL adapt to changing demand?", ["adaptive_experiment.py"], False),
    ("v4: second attempt with a richer state", ["rich_state_experiment.py"], False),
    ("v5: three-product store with a shared shelf", ["multi_experiment.py"], True),
    ("report", ["make_report.py"], False),
]

env = dict(os.environ, PYTHONWARNINGS="ignore")
results = []
t_all = time.time()
for label, cmd, slow in STEPS:
    if QUICK and slow:
        print(f"\n--- SKIPPED (quick mode, saved results reused): {label}", flush=True)
        results.append((label, "skipped"))
        continue
    print(f"\n=== {label}  ->  python {' '.join(cmd)}", flush=True)
    t0 = time.time()
    rc = subprocess.run([sys.executable] + cmd, cwd=BASE, env=env).returncode
    status = "ok" if rc == 0 else f"FAILED (exit {rc})"
    results.append((label, f"{status}, {time.time() - t0:.0f}s"))

print("\n" + "=" * 70 + "\nSUMMARY")
for label, status in results:
    print(f"  {status:22s} {label}")
print(f"Total time: {(time.time() - t_all) / 60:.1f} minutes")
report = os.path.join(BASE, "ARMS_report.html")
if os.path.exists(report):
    print("Report:", report)
    try:
        os.startfile(report)          # opens in the browser on Windows
    except Exception:
        pass
