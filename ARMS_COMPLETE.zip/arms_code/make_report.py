"""
Builds ARMS_report.html: a single, self-contained results report (open in any browser; Ctrl+P to save as PDF).
All numbers are read from the result files saved by the other scripts, or recomputed from them.

    python make_report.py
"""
import os
BASE = os.path.dirname(os.path.abspath(__file__))
import base64
import datetime
import html
import io
import json
import re
import textwrap
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats
import retail_env_v2 as E
import retail_env_multi as RM

plt.rcParams.update({
    "font.size": 9.5, "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.alpha": 0.25, "axes.titlesize": 10.5, "axes.titleweight": "bold",
    "legend.frameon": False, "figure.dpi": 100,
})
C_ORIG, C_SINGLE, C_TWO, C_GUARD, C_TUNED = "#9aa5b1", "#8fb0dc", "#3e6fb0", "#1f3a5f", "#d9822b"


def p(name):
    return os.path.join(BASE, name)


def csv(name, **kw):
    return pd.read_csv(p(name), **kw) if os.path.exists(p(name)) else None


def esc(x):
    return html.escape(str(x))


def clean(s):
    return " ".join(str(s).split())


COUNT = {"table": 0, "figure": 0}


# ------------------------------------------------------------------ building blocks
def fmt(v, d=0):
    if isinstance(v, (bool, np.bool_)):
        return esc(v)
    if isinstance(v, (int, np.integer)):
        return f"{int(v):,}"
    if isinstance(v, (float, np.floating)):
        return "-" if np.isnan(v) else f"{v:,.{d}f}"
    return esc(v)


def table(df, caption, dec=0, bold=None, note=None):
    """df: first column = row label. dec: int or {column: int}. bold: 'row' | 'col' | None (bold the maximum)."""
    COUNT["table"] += 1
    cols = list(df.columns)
    decs = dec if isinstance(dec, dict) else {c: dec for c in cols}
    is_num = lambda v: isinstance(v, (int, float, np.integer, np.floating)) and not isinstance(v, (bool, np.bool_))
    numeric_cols = [c for c in cols[1:] if df[c].map(is_num).all()]
    best = set()
    if bold == "row":
        for i in range(len(df)):
            vals = {c: df.iloc[i][c] for c in numeric_cols}
            if vals:
                m = max(vals.values())
                best |= {(i, c) for c, v in vals.items() if v == m}
    elif bold == "col":
        for c in numeric_cols:
            m = df[c].max()
            best |= {(i, c) for i in range(len(df)) if df.iloc[i][c] == m}
    numlike = re.compile(r"^[\s\-+\u20b9\d.,%]*$")
    text_cols = {c for c in cols[1:] if not df[c].map(lambda v: is_num(v) or bool(numlike.match(str(v)))).all()}
    head = "".join(f"<th class='{'l' if c in text_cols else ''}'>{esc(c)}</th>" for c in cols)
    body = ""
    for i in range(len(df)):
        cells = ""
        for c in cols:
            txt = fmt(df.iloc[i][c], decs.get(c, 0))
            txt = f"<b>{txt}</b>" if (i, c) in best else txt
            cells += f"<td class='{'l' if c in text_cols else ''}'>{txt}</td>"
        body += f"<tr>{cells}</tr>"
    out = (f"<div class='wrap'><table class='data'><caption>Table {COUNT['table']}. {esc(caption)}</caption>"
           f"<thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>")
    if note:
        out += f"<p class='note'>{note}</p>"
    return out


def figure(fig, caption, width=100):
    COUNT["figure"] += 1
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=170, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    b64 = base64.b64encode(buf.getvalue()).decode()
    return (f"<figure><img alt='Figure {COUNT['figure']}' style='width:{width}%' src='data:image/png;base64,{b64}'>"
            f"<figcaption>Figure {COUNT['figure']}. {esc(caption)}</figcaption></figure>")


def money(x):
    return f"\u20b9{x:,.0f}"


# ------------------------------------------------------------------ data
METHOD_ORDER = ["Rule-based", "Single-Agent RL", "Two-Agent RL", "Two-Agent RL + guardrails",
                "Two-Agent RL + guardrails + fallback", "Tuned order-up-to rule (no learning)",
                "Tuned (s,S) rule (no learning)", "MAPPO (neural policy)"]
SHORT = {"Rule-based": "Original rule", "Single-Agent RL": "Single-agent", "Two-Agent RL": "Two-agent",
         "Two-Agent RL + guardrails": "Two-agent + guardrails", "Two-Agent RL + guardrails + fallback": "+ fallback",
         "Tuned order-up-to rule (no learning)": "Tuned order-up-to", "Tuned (s,S) rule (no learning)": "Tuned (s,S) rule",
         "MAPPO (neural policy)": "MAPPO"}

v1 = csv("metrics_summary_full.csv", index_col=0)
seeds1 = csv("multi_seed_results.csv")
oracle = csv("results_oracle.csv")
v2 = csv("v2_results_table.csv")
seeds2 = csv("multi_seed_v2_results.csv")
sweep = csv("v2_fallback_sweep.csv")
grid = csv("tuned_baseline_grid.csv")
stress = csv("stress_test_results.csv")
adapt = csv("rich_state_means.csv", index_col=0)
if adapt is None:
    adapt = csv("adaptive_experiment_means.csv", index_col=0)
mp_all = csv("mappo_results_all.csv")
mp_val = csv("mappo_validation.csv")
mp_beh = csv("mappo_behaviour.csv")
mp_stress = csv("mappo_stress.csv")
mp_curve = csv("mappo_curve_seed0.csv")
ss_sum = csv("sS_summary.csv")
ss_profit = None
if ss_sum is not None:
    ss_profit = float(ss_sum[ss_sum["rule"] == "Tuned (s,S) rule"]["test_100_seeds"].iloc[0])
st3 = csv("store3_results.csv")
st3_seeds = csv("store3_seed_results.csv")
st3_team = csv("store3_team_seed_results.csv")
st3_cap = csv("store3_capacity_results.csv")
profile = None
if os.path.exists(p("demand_profile.json")):
    with open(p("demand_profile.json"), encoding="utf-8") as f:
        profile = json.load(f)

# performance of the tuned rule on the same fresh test seeds used for the other methods
tuned_profit = None
if grid is not None:
    try:
        import app_core as C
        import train_v2 as T
        tuned_profit = float(T.evaluate(lambda s: C.TUNED_RULE(s))["profit"].mean())
    except Exception:
        tuned_profit = None

orig_profit = guard_profit = None
if v2 is not None:
    row = v2.set_index("Method")["Profit (Rs/episode)"]
    orig_profit = float(row.get("Rule-based", np.nan))
    guard_profit = float(row.get("Two-Agent Q-learning + guardrails", np.nan))

# ------------------------------------------------------------------ summary numbers
findings = []
if seeds1 is not None:
    t1 = stats.ttest_rel(seeds1["two_agent"], seeds1["single_agent"])
    wins1 = int((seeds1["two_agent"] > seeds1["single_agent"]).sum())
    findings.append(f"Under a revenue-based reward, two cooperating agents (pricing, then reordering) outperformed a single "
                    f"agent controlling both decisions in {wins1} of {len(seeds1)} independent training runs "
                    f"(mean {seeds1['two_agent'].mean():,.0f} vs {seeds1['single_agent'].mean():,.0f}; paired t-test p = {t1.pvalue:.5f}).")
if seeds2 is not None:
    pv = [stats.ttest_rel(seeds2["two_agent"], seeds2["single"]).pvalue,
          stats.ttest_rel(seeds2["two_agent_guarded"], seeds2["two_agent"]).pvalue,
          stats.ttest_rel(seeds2["two_agent_guarded"], seeds2["single"]).pvalue]
    findings.append(f"Under a profit-based reward that charges purchase, holding and ordering costs, the learning methods did not differ "
                    f"reliably from one another over {len(seeds2)} training runs (paired p-values {min(pv):.2f} to {max(pv):.2f}). "
                    f"Safety guardrails reduced variability across runs (standard deviation {money(seeds2['two_agent_guarded'].std(ddof=1))} "
                    f"versus {money(seeds2['single'].std(ddof=1))} and {money(seeds2['two_agent'].std(ddof=1))}).")
if tuned_profit is not None and orig_profit is not None:
    ss_txt = f" and an (s,S) rule that orders a full batch when stock is low ({money(ss_profit)})" if ss_profit else ""
    findings.append(f"Two tuned classical rules without learning were used as baselines: an order-up-to rule ({money(tuned_profit)} per 60-day episode)"
                    f"{ss_txt}. The original rule earned {money(orig_profit)} and the best tabular reinforcement-learning agent {money(guard_profit)} in a single run "
                    f"({money(seeds2['two_agent_guarded'].mean()) if seeds2 is not None else 'n/a'} averaged over {len(seeds2) if seeds2 is not None else 0} runs).")
if mp_all is not None and tuned_profit is not None:
    xm = mp_all["profit"]
    pm = stats.ttest_1samp(xm, tuned_profit).pvalue
    extra = ""
    if mp_stress is not None and ss_profit is not None:
        ssd = mp_stress[mp_stress.method == "Tuned (s,S) rule"].set_index("scenario")["profit"]
        mm = mp_stress[mp_stress.method == "MAPPO"]
        allwin = sum(int((mm[mm.scenario == sc]["profit"] > ssd[sc]).all()) for sc in ssd.index)
        pos = int(sum(mm[mm.scenario == sc]["profit"].mean() > 0 for sc in ssd.index))
        neg_ss = int(sum(ssd[sc] < 0 for sc in ssd.index))
        extra = (f" When conditions changed it beat the (s,S) rule in {allwin} of {len(ssd)} stress scenarios in every one of its "
                 f"{mm['seed'].nunique()} saved training runs; its average profit was positive in {pos} of {len(ssd)} scenarios, against "
                 f"{len(ssd) - neg_ss} of {len(ssd)} for the (s,S) rule.")
    findings.append(f"MAPPO, a multi-agent policy-gradient method with centralised critics, averaged {money(xm.mean())} over {len(xm)} training seeds, above the order-up-to rule "
                    f"in {int((xm > tuned_profit).sum())} of {len(xm)} seeds (p = {pm:.4f}). It learned to order in full batches rather than often in small amounts, "
                    f"but stayed below the tuned (s,S) rule in normal conditions.{extra}")
if st3 is not None and st3_seeds is not None:
    t3 = st3.set_index("Method")["Profit (Rs/episode)"]
    findings.append(f"In a three-product store with a shared shelf and substitution between products, the tuned order-up-to rule again earned the most "
                    f"({money(t3['Tuned order-up-to rule'])} per episode, against {money(t3['RL (per-product agents)'])} for the RL agents); "
                    f"the RL agents were below it in every one of {len(st3_seeds)} training runs.")
if adapt is not None:
    findings.append("Training the tabular agents across several demand levels, and giving them a richer state, did not allow them to "
                    "outperform a rule tuned over the same demand levels.")

parts = []

# ------------------------------------------------------------------ header + summary
parts.append(f"""
<header>
<div class='kicker'>Results report</div>
<h1>Coordinated Reinforcement Learning for Retail Pricing and Inventory Management</h1>
<div class='sub'>Simulation study of a perishable product &nbsp;|&nbsp; {datetime.date.today().strftime('%d %B %Y')}</div>
</header>
<div class='summary'><h3>Summary of findings</h3><ol>{''.join(f'<li>{x}</li>' for x in findings)}</ol></div>
""")

# ------------------------------------------------------------------ 1 setup
env_rows = pd.DataFrame([
    ["Product", "One perishable item (milk packet)"],
    ["Selling price (regular)", f"\u20b9{E.BASE_PRICE:.0f}"],
    ["Purchase cost", f"\u20b9{E.UNIT_COST:.0f} per unit"],
    ["Shelf life", f"{E.SHELF_LIFE_DAYS} days"],
    ["Daily demand", f"Poisson with mean {E.BASE_DEMAND:.0f} units; weekend multiplier {E.WEEKDAY_MULT[5]:.2f}"],
    ["Price response", "Demand rises 15% at a moderate discount (15% off) and 30% at clearance (35% off); assumed"],
    ["Holding cost", f"\u20b9{E.HOLD_COST} per unit per day"],
    ["Fixed ordering cost", f"\u20b9{E.ORDER_FIXED:.0f} per order"],
    ["Stock-out penalty", f"\u20b9{E.LAMBDA_S:.0f} per unit of unmet demand (lost margin plus goodwill)"],
    ["Shelf capacity", f"{E.MAX_STOCK} units"],
    ["Episode length", "60 days; one pricing decision and one reorder decision per day"],
], columns=["Parameter", "Value"])
method_rows = pd.DataFrame([
    ["Original rule", "Fixed thresholds for discounting and reordering."],
    ["Tuned order-up-to rule", "Orders the largest quantity that keeps stock at or below a target; discount thresholds chosen by grid search on separate seeds. No learning."],
    ["Tuned (s,S) rule", "Orders a full batch (25 units) when stock is at or below a threshold, otherwise nothing; threshold and discount rule chosen by grid search on separate seeds. No learning."],
    ["Single-agent RL", "One Q-learning agent choosing price and reorder jointly (9 combined actions)."],
    ["Two-agent RL", "Two Q-learning agents. The pricing agent acts first; the inventory agent observes its choice."],
    ["Two-agent RL + guardrails", "As above, trained under a price floor (no sale below cost unless stock expires within a day) and a reorder cap at shelf capacity."],
    ["+ fallback", "Defers to the original rule when the agent's action values are nearly tied."],
    ["MAPPO", "Multi-agent PPO written in NumPy: a pricing policy and an inventory policy (which sees the price choice), trained with centralised value functions and guardrails as action masks. It also receives a smoothed demand estimate and the number of units expiring today."],
    ["Neural fitted Q-iteration (NFQ)", "Single- and two-agent versions with a neural-network action-value function (Section 2 only)."],
], columns=["Method", "Description"])
parts.append("<h2>1. Experimental setup</h2>"
             "<p>Pricing and reordering decisions for a single perishable product were simulated in a store environment. "
             "A pricing agent selects one of three price tiers (regular, moderate discount, clearance); an inventory agent then selects a "
             "reorder size (none, 10 or 25 units). Each agent receives its own reward: the pricing agent is rewarded for margin and penalised for "
             "expired stock; the inventory agent is penalised for holding, ordering and stock-outs. Section 2 uses an earlier, revenue-based reward "
             "(revenue less penalties for wastage, stock-outs and excess stock); Sections 3 onward use the profit-based reward described in the table below.</p>"
             + table(env_rows, "Simulation parameters (all values are assumptions of the simulation)")
             + table(method_rows, "Methods compared")
             + "<p>Learned policies were evaluated greedily on random seeds not used in training. Where stated, results are repeated over independent "
               "training runs (seeds), and methods are compared with paired t-tests across those runs.</p>")

# ------------------------------------------------------------------ 2 (v1) coordination
s = "<h2>2. Coordination of pricing and inventory decisions (revenue-based reward)</h2>"
if v1 is not None:
    t = v1.copy()
    t.columns = ["Original rule", "Single-agent Q-learning", "Two-agent Q-learning", "Single-agent NFQ", "Two-agent NFQ"]
    t = t.reset_index().rename(columns={t.index.name or "index": "Metric", "index": "Metric"})
    t.columns = ["Metric"] + list(t.columns[1:])
    s += table(t, "Mean performance per episode after training")
    curves = []
    for fname, label, color, style in [("results_single_agent.csv", "Single-agent Q-learning", C_SINGLE, "--"),
                                       ("results_two_agent.csv", "Two-agent Q-learning", C_TWO, "--"),
                                       ("results_single_nfq.csv", "Single-agent NFQ", "#5b8bd0", "-"),
                                       ("results_two_nfq.csv", "Two-agent NFQ", C_GUARD, "-")]:
        d = csv(fname)
        if d is not None:
            curves.append((d, label, color, style))
    rule_d = csv("results_rule_based.csv")
    if curves:
        fig, ax = plt.subplots(1, 3, figsize=(11, 3.4))
        for j, (col, title, logy) in enumerate([("total_reward", "Total reward per episode", False),
                                                ("stockout", "Stock-out units per episode", False),
                                                ("wastage", "Wasted units per episode", True)]):
            for d, label, color, style in curves:
                ax[j].plot(d[col].rolling(25, min_periods=1).mean(), label=label, color=color, linestyle=style, lw=1.5)
            if rule_d is not None:
                ax[j].axhline(rule_d[col].mean(), color="#6b8e23", ls=":", lw=1.4, label="Original rule")
            ax[j].set_title(title)
            ax[j].set_xlabel("Training episode")
            if logy:
                ax[j].set_yscale("symlog", linthresh=1)
            ax[j].set_ylim(bottom=0)
        h, l = ax[0].get_legend_handles_labels()
        fig.legend(h, l, loc="lower center", ncol=5, fontsize=8, bbox_to_anchor=(0.5, -0.07))
        fig.tight_layout()
        s += figure(fig, "Learning curves (25-episode moving average). The single-agent neural method became unstable, "
                         "with wastage rising sharply, while the two-agent versions remained stable.", width=100)
    s += ("<p>Splitting the decision between two agents was more stable than a single agent choosing over the nine combined actions, "
          "in both the table-based and the neural implementations. This comparison is between learning formulations; it does not compare "
          "learning with a well-tuned classical rule (see Section 4).</p>")
if seeds1 is not None:
    wins1 = int((seeds1["two_agent"] > seeds1["single_agent"]).sum())
    tt = stats.ttest_rel(seeds1["two_agent"], seeds1["single_agent"])
    fig, ax = plt.subplots(figsize=(5.2, 3.3))
    for _, r in seeds1.iterrows():
        ax.plot([0, 1], [r["single_agent"], r["two_agent"]], color="#9aa5b1", lw=1, marker="o", ms=4)
    ax.plot([0, 1], [seeds1["single_agent"].mean(), seeds1["two_agent"].mean()], color=C_GUARD, lw=2.6, marker="o", ms=6, label="Mean")
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["Single-agent", "Two-agent"])
    ax.set_xlim(-0.3, 1.3)
    ax.set_ylabel("Mean reward (final 100 episodes)")
    ax.legend()
    fig.tight_layout()
    s += figure(fig, f"Result of each of {len(seeds1)} independent training runs (grey) and their mean (blue). "
                     f"The two-agent method was higher in {wins1} of {len(seeds1)} runs.", width=52)
    s += (f"<p>Across {len(seeds1)} independent training runs the two-agent method achieved a mean of {seeds1['two_agent'].mean():,.0f} "
          f"against {seeds1['single_agent'].mean():,.0f} for the single agent (standard deviations {seeds1['two_agent'].std(ddof=1):,.0f} and "
          f"{seeds1['single_agent'].std(ddof=1):,.0f}); paired t-test p = {tt.pvalue:.5f}.</p>")
if oracle is not None:
    s += (f"<p>For reference, a policy with perfect foresight of the next two days' demand, which no real agent can match, averaged "
          f"{oracle['total_reward'].mean():,.0f} reward under the same reward.</p>")
parts.append(s)

# ------------------------------------------------------------------ 4 (v2) profit
s = "<h2>3. Profit-based reward</h2>"
s += ("<p>The reward was then changed to reflect real costs: margin on sales, the purchase cost of expired stock, holding cost, a fixed cost "
      "per order, and a stock-out penalty. Learned policies were deployed greedily on fresh seeds.</p>")
if v2 is not None:
    t = v2.copy()
    t["Method"] = t["Method"].replace({"Rule-based": "Original rule", "Single-Agent Q-learning": "Single-agent Q-learning",
                                       "Two-Agent Q-learning (no guardrails)": "Two-agent Q-learning",
                                       "Two-Agent Q-learning + guardrails": "Two-agent Q-learning + guardrails"})
    t = t[["Method", "Profit (Rs/episode)", "Wastage (units)", "Stock-out (units)", "Fill rate", "Days over shelf capacity", "Guardrail interventions"]]
    t.columns = ["Method", "Profit (\u20b9/episode)", "Wasted units", "Unmet demand (units)", "Fill rate", "Days over capacity", "Guardrail interventions"]
    s += table(t, "Single training run, evaluated on 100 fresh episodes",
               dec={"Wasted units": 1, "Unmet demand (units)": 1, "Days over capacity": 1, "Guardrail interventions": 1})
if seeds2 is not None:
    summ = pd.DataFrame({
        "Method": ["Single-agent", "Two-agent", "Two-agent + guardrails"],
        "Mean profit (\u20b9)": [seeds2["single"].mean(), seeds2["two_agent"].mean(), seeds2["two_agent_guarded"].mean()],
        "Std. dev. across runs": [seeds2["single"].std(ddof=1), seeds2["two_agent"].std(ddof=1), seeds2["two_agent_guarded"].std(ddof=1)],
        "Lowest run": [seeds2["single"].min(), seeds2["two_agent"].min(), seeds2["two_agent_guarded"].min()],
        "Highest run": [seeds2["single"].max(), seeds2["two_agent"].max(), seeds2["two_agent_guarded"].max()],
    })
    s += ("<p>A single run can be misleading, so the three learning methods were retrained from "
          f"{len(seeds2)} different seeds.</p>")
    s += table(summ, f"Mean profit per episode across {len(seeds2)} independent training runs")
    fig, ax = plt.subplots(figsize=(7.2, 3.6))
    for k, (col, lab, color) in enumerate([("single", "Single-agent", C_SINGLE), ("two_agent", "Two-agent", C_TWO),
                                           ("two_agent_guarded", "Two-agent + guardrails", C_GUARD)]):
        ax.scatter(np.full(len(seeds2), k) + np.linspace(-0.08, 0.08, len(seeds2)), seeds2[col], color=color, s=34, zorder=3)
        ax.hlines(seeds2[col].mean(), k - 0.25, k + 0.25, color=color, lw=2.5)
    if orig_profit:
        ax.axhline(orig_profit, color=C_ORIG, ls="--", lw=1.4, label=f"Original rule ({money(orig_profit)})")
    if tuned_profit:
        ax.axhline(tuned_profit, color=C_TUNED, ls="--", lw=1.6, label=f"Tuned rule ({money(tuned_profit)})")
    ax.set_xticks([0, 1, 2])
    ax.set_xticklabels(["Single-agent", "Two-agent", "Two-agent + guardrails"])
    ax.set_ylabel("Profit per episode (\u20b9)")
    ax.legend(loc="lower right")
    fig.tight_layout()
    s += figure(fig, "Profit of each independent training run (dots) and the mean (bar), against the two classical rules.", width=68)
    p1 = stats.ttest_rel(seeds2["two_agent"], seeds2["single"]).pvalue
    p2 = stats.ttest_rel(seeds2["two_agent_guarded"], seeds2["two_agent"]).pvalue
    s += (f"<p>Differences between the learning methods were not statistically significant (two-agent vs single-agent p = {p1:.2f}; "
          f"guardrails vs none p = {p2:.2f}). Guardrails narrowed the spread between runs and raised the lowest run; with "
          f"{len(seeds2)} runs this is suggestive rather than conclusive.</p>")
if sweep is not None:
    t = sweep.copy()
    t.columns = ["Confidence threshold", "Profit (\u20b9/episode)", "Decisions handled by fallback rule", "Unmet demand (units)", "Wasted units"]
    s += table(t, "Effect of the low-confidence fallback threshold (guardrail-trained two-agent policy)",
               dec={"Unmet demand (units)": 1, "Wasted units": 1},
               note="A higher threshold hands more decisions to the original rule; at full hand-over the result equals the original rule, which confirms the mechanism.")
parts.append(s)

# ------------------------------------------------------------------ 5 tuned baseline
s = "<h2>4. Classical baselines</h2>"
if grid is not None:
    top = grid.sort_values("tuning_profit", ascending=False).head(5).copy()
    top = top[["target", "clear_exp", "clear_stock", "mod_exp", "tuning_profit"]]
    top.columns = ["Order-up-to target (units)", "Clearance when days left \u2264", "Clearance when stock >", "Moderate discount when days left \u2264", "Tuning profit (\u20b9)"]
    b = grid.sort_values("tuning_profit", ascending=False).iloc[0]
    s += (f"<p>An order-up-to rule, a standard inventory policy, was tuned by grid search over {len(grid)} parameter settings using separate "
          "tuning seeds, and then evaluated on the same fresh seeds as every other method.</p>")
    s += table(top, "Five best parameter settings found (ties are identical in profit)", dec={"Tuning profit (\u20b9)": 0})
    if tuned_profit is not None:
        s += (f"<p>The best setting orders up to {int(b['target'])} units, uses no clearance tier and applies a moderate discount when one day remains. "
              f"On fresh seeds it earned {money(tuned_profit)} per episode, against {money(orig_profit)} for the original rule and "
              f"{money(guard_profit)} for the best learning agent (a single training run; the multi-seed mean for that method was "
              f"{money(seeds2['two_agent_guarded'].mean()) if seeds2 is not None else 'n/a'}). Comparisons in earlier sections that used the original rule "
              "as the reference therefore understate how strong a simple, well-tuned policy is.</p>")
if ss_sum is not None:
    t = ss_sum.copy()
    _g = csv("tuned_sS_grid.csv")
    if _g is not None:
        _b = _g.iloc[0]
        _qty = 25 if "FULL" in str(_b["order"]) else 10
        _disc = "no discounting" if int(_b["mod_exp"]) <= 0 else f"moderate discount when {int(_b['mod_exp'])} day(s) or fewer remain"
        t.loc[t["rule"] == "Tuned (s,S) rule", "setting"] = f"order {_qty} units when stock is {int(_b['s'])} or below; {_disc}"
    t.columns = ["Rule", "Setting", "100 test episodes (\u20b9)", "300 new episodes (\u20b9)"]
    t["Rule"] = t["Rule"].replace({"Tuned order-up-to rule": "Tuned order-up-to rule"})
    s += ("<p>Because every order carries a fixed cost, a second classical rule was tuned: an (s,S) rule, which orders a full batch when stock falls to a "
          "threshold and otherwise orders nothing. Ordering less often in larger batches is the standard answer to a fixed ordering cost.</p>")
    s += table(t, "Tuned classical rules (profit per episode; the second set of episodes was not used for any tuning)")
    if ss_profit and tuned_profit:
        s += (f"<p>The (s,S) rule earned {money(ss_profit)}, {ss_profit / tuned_profit * 100 - 100:.0f}% more than the order-up-to rule, and is the strongest "
              "classical baseline in this report.</p>")
parts.append(s)

# ------------------------------------------------------------------ 5 MAPPO
s = "<h2>5. Multi-agent policy-gradient learning (MAPPO)</h2>"
s += ("<p>The tabular learners read a coarse table of states. To test a stronger learner, MAPPO (multi-agent proximal policy optimisation) was implemented in NumPy: "
      "a pricing policy and an inventory policy, each a small neural network, trained with the clipped PPO objective and generalised advantage estimation. "
      "During training each policy is guided by a value function that sees both agents' information (the store state and the pricing choice); at run time each policy "
      "uses only its own inputs. The guardrails of Section 3 are applied as action masks, so the policies learn inside the allowed set. MAPPO also receives a smoothed "
      "demand estimate and the number of units expiring today, which the rules and the tabular agents do not use. One setting was used for every run, with no tuning, and the "
      "hand-written gradients were verified numerically.</p>")
if mp_all is not None and tuned_profit is not None:
    xm = mp_all["profit"]
    tt = stats.ttest_1samp(xm, tuned_profit)
    rows_ = [["Training seeds", f"{len(xm)}"], ["Mean profit per episode", money(xm.mean())],
             ["Standard deviation across seeds", money(xm.std(ddof=1))],
             ["Lowest and highest seed", f"{money(xm.min())} and {money(xm.max())}"],
             ["Seeds above the tuned order-up-to rule", f"{int((xm > tuned_profit).sum())} of {len(xm)} (p = {tt.pvalue:.4f})"]]
    if ss_profit:
        rows_.append(["Seeds above the tuned (s,S) rule", f"{int((xm > ss_profit).sum())} of {len(xm)}"])
    s += table(pd.DataFrame(rows_, columns=["Measure", "Value"]), "MAPPO profit per episode over independent training runs (100 fresh test episodes each)")
    fig, ax = plt.subplots(figsize=(7.6, 3.5))
    ax.scatter(mp_all["seed"], xm, color=C_TWO, s=38, zorder=3, label="MAPPO, one point per training seed")
    for val, lab, col in [(orig_profit, "Original rule", C_ORIG), (tuned_profit, "Tuned order-up-to rule", C_TUNED), (ss_profit, "Tuned (s,S) rule", C_GUARD)]:
        if val:
            ax.axhline(val, color=col, ls="--", lw=1.5, label=f"{lab} ({money(val)})")
    ax.set_xlabel("Training seed"); ax.set_ylabel("Profit per episode (\u20b9)")
    ax.legend(fontsize=8, loc="upper center", bbox_to_anchor=(0.5, -0.2), ncol=2)
    fig.tight_layout()
    s += figure(fig, "MAPPO profit by training seed against the classical rules.", width=74)
if mp_val is not None and tuned_profit is not None:
    mv = mp_val[mp_val.method == "MAPPO"]["profit"]
    rows_ = [[r.method, f"{r.profit:,.0f}"] for r in mp_val[mp_val.method != "MAPPO"].itertuples()]
    rows_ += [[f"MAPPO (mean of {len(mv)} saved agents)", f"{mv.mean():,.0f}"], ["MAPPO, lowest and highest saved agent", f"{mv.min():,.0f} and {mv.max():,.0f}"]]
    s += table(pd.DataFrame(rows_, columns=["Method", "Profit per episode (\u20b9)"]),
               "Independent re-test on 300 new episodes that were not used for training or tuning")
if mp_beh is not None:
    bh = mp_beh.copy()
    bh.columns = ["Method", "Regular price", "Moderate discount", "Clearance", "No order", "Small order (10)", "Full order (25)"]
    bh["Method"] = bh["Method"].replace({"MAPPO (seed 6)": "MAPPO (one saved agent)"})
    s += table(bh, "Share of decisions (%) in the 300 new episodes", dec=1)
    m_row = mp_beh[mp_beh["method"].str.startswith("MAPPO")].iloc[0]
    u_row = mp_beh[mp_beh["method"] == "Tuned order-up-to rule"].iloc[0]
    s_row = mp_beh[mp_beh["method"] == "Tuned (s,S) rule"].iloc[0]
    s += (f"<p>MAPPO placed an order on about {100 - m_row['no_order']:.0f}% of days, almost always as a full batch, whereas the order-up-to rule ordered on about "
          f"{100 - u_row['no_order']:.0f}% of days, mostly in small amounts. Because each order carries a fixed cost, ordering less often in larger batches is cheaper. "
          f"The tuned (s,S) rule orders a full batch on {s_row['full_order']:.0f}% of days. MAPPO therefore learned the structure of the classical solution from experience alone, "
          "but did not match the tuned rule's profit.</p>")
if mp_curve is not None:
    fig, ax = plt.subplots(figsize=(6.8, 3.0))
    ax.plot(mp_curve["iteration"], mp_curve["mean_training_profit"], color=C_TWO, lw=1.6)
    ax.set_xlabel("Training iteration (16 episodes each)"); ax.set_ylabel("Mean training profit (\u20b9)")
    fig.tight_layout()
    s += figure(fig, "Training curve for one seed (actions sampled from the policy). Profit rises within about 25 iterations and then drifts down, while the greedy policy used "
                     "in evaluation earned the same \u20b97,911 after 100 and after 300 iterations; the cause of the drift was not investigated.", width=66)
parts.append(s)

# ------------------------------------------------------------------ 6 stress
s = "<h2>6. Robustness to changing conditions</h2>"
if stress is not None:
    scen = list(dict.fromkeys(stress["Scenario"]))
    s += ("<p>All methods were built for a mean demand of 12 units and a 4-day shelf life, and none was retrained or re-tuned for the scenarios below.</p>")

    def piv(col):
        t = stress.pivot(index="Scenario", columns="Method", values=col)[METHOD_ORDER].loc[scen]
        t.columns = [SHORT[c] for c in t.columns]
        t.index = [clean(i) for i in t.index]
        return t.reset_index().rename(columns={"index": "Scenario"})
    pp = piv("Profit (Rs)")
    s += table(pp, "Mean profit per episode (\u20b9) by scenario, 15 episodes each (one trained agent per learning method); the highest value in each row is in bold", bold="row")
    fig, ax = plt.subplots(figsize=(10.5, 4.0))
    show = ["Original rule", "Two-agent + guardrails", "Tuned order-up-to", "Tuned (s,S) rule", "MAPPO"]
    colors = [C_ORIG, C_TWO, C_TUNED, C_GUARD, "#2e9e6b"]
    w = 0.16
    xs = np.arange(len(pp))
    for k, (m, c) in enumerate(zip(show, colors)):
        ax.bar(xs + (k - 2) * w, pp[m], w, label=m, color=c)
    ax.axhline(0, color="#333", lw=0.8)
    ax.set_xticks(xs)
    ax.set_xticklabels([textwrap.fill(x, 22) for x in pp["Scenario"]], fontsize=7.5)
    ax.set_ylabel("Mean profit per episode (\u20b9)")
    ax.legend(ncol=5, fontsize=8, loc="upper center", bbox_to_anchor=(0.5, 1.14))
    fig.tight_layout()
    s += figure(fig, "Profit by scenario (selected methods; the single-agent, two-agent and fallback variants are in the table).")
    s += table(piv("Wasted"), "Mean wasted units per episode by scenario", dec=1)
if mp_stress is not None:
    scen2 = list(dict.fromkeys(mp_stress["scenario"]))
    ssd = mp_stress[mp_stress.method == "Tuned (s,S) rule"].set_index("scenario")["profit"]
    oud = mp_stress[mp_stress.method == "Tuned order-up-to rule"].set_index("scenario")["profit"]
    ord_ = mp_stress[mp_stress.method == "Original rule"].set_index("scenario")["profit"]
    mm = mp_stress[mp_stress.method == "MAPPO"]
    rows_ = []
    for sc in scen2:
        v = mm[mm.scenario == sc]["profit"]
        rows_.append([sc, ord_[sc], oud[sc], ssd[sc], v.mean(), v.std(ddof=1), f"{int((v > ssd[sc]).sum())} of {len(v)}"])
    t = pd.DataFrame(rows_, columns=["Scenario", "Original rule", "Tuned order-up-to", "Tuned (s,S) rule", "MAPPO mean", "MAPPO std. dev.", "MAPPO seeds above (s,S)"])
    s += ("<p>The learned policy was then tested with all ten saved MAPPO agents (20 episodes per scenario) against the rules:</p>")
    s += table(t, "Mean profit per episode (\u20b9); MAPPO averaged over its saved training seeds")
    win_sc = [sc for sc in scen2 if (mm[mm.scenario == sc]["profit"] > ssd[sc]).all()]
    lose_sc = [sc for sc in scen2 if (mm[mm.scenario == sc]["profit"] <= ssd[sc]).all()]
    neg_ss = [sc for sc in scen2 if ssd[sc] < 0]
    neg_mp = [sc for sc in scen2 if mm[mm.scenario == sc]["profit"].mean() < 0]
    s += (f"<p>MAPPO beat the (s,S) rule in every saved seed in {len(win_sc)} of {len(scen2)} scenarios ({'; '.join(w_.split(' (')[0].lower() for w_ in win_sc)}), and the (s,S) rule won "
          f"the other {len(lose_sc)} in every seed. On average the (s,S) rule made a loss in {len(neg_ss)} {'scenario' if len(neg_ss) == 1 else 'scenarios'}, and MAPPO in {len(neg_mp)}. The original rule was best when demand fell by 40%. "
          "MAPPO's inputs include a smoothed demand estimate and the units expiring, which the rules do not use, so this robustness cannot be attributed to learning alone.</p>")
parts.append(s)

# ------------------------------------------------------------------ 7 adaptive
s = "<h2>7. Adaptation to changing demand</h2>"
if adapt is not None:
    s += ("<p>Fixed rules cannot react when demand changes, whereas a learning agent observes recent demand. To test whether learning can exploit this, "
          "tabular Q-learning agents were trained on a mixture of demand levels (7, 12 and 18 units) and compared with a rule tuned on the same mixture, over 5 training seeds. "
          "A second attempt gave the agent a richer state (a smoothed demand estimate and the number of units expiring that day). "
          "Because the second attempt followed the first, the pair should be read as two tries rather than one pre-planned test.</p>")
    t = adapt.copy()
    t.index = [clean(i) for i in t.index]
    ren = {"Original rule": "Original rule", "Rule tuned at 12": "Rule tuned at demand 12", "Rule tuned on mix": "Rule tuned on demand mix",
           "RL fixed-train": "RL trained at demand 12", "RL adaptive-train": "RL trained across levels",
           "RL adaptive, RICH state": "RL across levels, richer state"}
    t = t.rename(columns=ren)
    mean_row = t.mean().to_frame().T
    mean_row.index = ["Mean over scenarios"]
    t2 = pd.concat([t, mean_row]).reset_index().rename(columns={"index": "Scenario"})
    s += table(t2, "Mean profit per episode (\u20b9); the highest value in each row is in bold", bold="row")
    fig, ax = plt.subplots(figsize=(7.4, 3.3))
    means = t.mean().sort_values()
    cols_ = [C_TUNED if "Rule tuned" in n else (C_ORIG if n == "Original rule" else C_TWO) for n in means.index]
    ax.barh(means.index, means.values, color=cols_)
    for y, v in enumerate(means.values):
        ax.text(v + 40, y, f"{v:,.0f}", va="center", fontsize=8)
    ax.set_xlabel("Mean profit over the eight scenarios (\u20b9)")
    ax.grid(axis="y", alpha=0)
    fig.tight_layout()
    s += figure(fig, "Mean profit over the eight scenarios. Classical rules (orange, grey) against learning agents (blue).", width=72)
    s += ("<p>On average over the scenarios, neither adaptive variant outperformed the rule tuned on the same demand levels, and the best method "
          "varies by scenario. Both adaptive variants earned a negative profit at the lowest demand level; Section 6 shows that policies built for "
          "demand 12 waste stock when demand falls.</p>")
parts.append(s)


# ------------------------------------------------------------------ 7 three-product store
s = "<h2>8. Several products sharing one shelf</h2>"
if st3 is not None:
    prod = pd.DataFrame([[P["name"], f"\u20b9{P['price']:.0f}", f"\u20b9{P['cost']:.0f}", P["shelf"], P["demand"]] for P in RM.PRODUCTS],
                        columns=["Product", "Price", "Purchase cost", "Shelf life (days)", "Mean daily demand"])
    s += (f"<p>The single-product setting favours simple rules, so a three-product store was tested, in which products compete for limited space. "
          f"Milk, curd and bread share a shelf of {RM.CAPACITY} units. When a product is sold out, {int(RM.SPILL*100)}% of the customers who wanted it "
          "try the next product. Orders that do not fit on the shelf are cut, and priority for scarce space rotates daily. Each product has its own "
          "pricing and inventory agent; the agents share nothing except the shelf, which they observe as how full it is.</p>")
    s += table(prod, "Products in the store (assumed values)", dec={"Mean daily demand": 0})
    t = st3.copy()
    t = t[["Method", "Profit (Rs/episode)", "Milk profit", "Curd profit", "Bread profit", "Wasted units", "Unmet demand (units)", "Shelf use", "Orders cut by shelf limit"]]
    t.columns = ["Method", "Profit (\u20b9/episode)", "Milk", "Curd", "Bread", "Wasted units", "Unmet demand (units)", "Shelf use (%)", "Orders cut by shelf"]
    s += table(t, "Mean per 60-day episode over 100 fresh episodes (all methods see the same random demand)",
               dec={"Wasted units": 1, "Unmet demand (units)": 1, "Shelf use (%)": 0, "Orders cut by shelf": 1})
if st3_seeds is not None and st3 is not None:
    tp = float(st3.set_index("Method").loc["Tuned order-up-to rule", "Profit (Rs/episode)"])
    r_ind = st3_seeds["rl_profit"]
    line = (f"<p>Training the RL agents from {len(r_ind)} different seeds gave a mean of {money(r_ind.mean())} (standard deviation {money(r_ind.std(ddof=1))}), "
            f"below the tuned rule's {money(tp)} in {int((r_ind < tp).sum())} of {len(r_ind)} runs.")
    if st3_team is not None:
        r_t = st3_team["rl_profit"]
        line += (f" A cooperative variant in which every agent is rewarded with the whole store's score did worse still "
                 f"(mean {money(r_t.mean())}).")
    s += line + "</p>"
if st3_cap is not None:
    pv = st3_cap.pivot(index="Shelf capacity", columns="Method", values="Profit (Rs/episode)")[["Original rule", "Tuned order-up-to rule", "RL (per-product agents)"]]
    pv.columns = ["Original rule", "Tuned rule", "RL (per-product agents)"]
    pv = pv.reset_index()
    pv["Shelf capacity"] = pv["Shelf capacity"].astype(str) + " units"
    s += table(pv, "Mean profit per episode (\u20b9) by shelf capacity; rule targets re-tuned and RL retrained at each capacity", bold="row")
    fig, ax = plt.subplots(figsize=(7.4, 3.4))
    xs = np.arange(len(pv)); w = 0.26
    for k, (m, c) in enumerate([("Original rule", C_ORIG), ("Tuned rule", C_TUNED), ("RL (per-product agents)", C_TWO)]):
        ax.bar(xs + (k - 1) * w, pv[m], w, label=m, color=c)
    ax.set_xticks(xs); ax.set_xticklabels(pv["Shelf capacity"])
    ax.set_ylabel("Mean profit per episode (\u20b9)")
    ax.legend(ncol=3, fontsize=8, loc="upper center", bbox_to_anchor=(0.5, 1.14))
    fig.tight_layout()
    s += figure(fig, "Profit by shelf capacity in the three-product store.", width=72)
    s += ("<p>The tuned rule earned the most at every capacity. The RL agents earned least at a capacity of 60 units, where, in the main comparison, "
          "many of their orders had to be cut to fit the shelf. The agents observe how full the shelf is, but each agent's reward counts only its own product, "
          "so no agent is rewarded for leaving space to the others; a shared team reward did not fix this in the tabular setting tested here.</p>")
parts.append(s)

# ------------------------------------------------------------------ 8 data
s = "<h2>9. Demand calibration with real data</h2>"
if profile:
    names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    wk = pd.DataFrame([profile["weekday_mult"]], columns=names)
    wk.insert(0, "Source", "Measured")
    s += (f"<p>Source: {esc(profile['source'])}, store {profile['store']}, {profile['n_series']} product series. "
          "The weekly demand pattern was measured from perishable products' daily sales.</p>")
    s += table(wk, "Demand multiplier by day of week (average = 1)", dec={n: 2 for n in names})
    s += (f"<p>The variance-to-mean ratio of daily sales was {profile['dispersion_index_median']} (the simulation assumes 1.0, "
          f"so real demand is more variable than simulated). Sales on promotion days were {profile['promo_lift_median']} times those on other days; "
          "this is confounded and is not a price elasticity.</p>")
else:
    s += ("<p>Demand in all experiments follows an assumed process (mean 12 units per day, a 15% weekend uplift, and Poisson variation). "
          "The weekly pattern and variability are to be calibrated against the Corporaci\u00f3n Favorita Grocery Sales data. That dataset has no price "
          "variable, so the response of demand to price will remain an assumption.</p>")
parts.append(s)

# ------------------------------------------------------------------ 10 extensions after the mid-point
try:
    import features_core as FC
    ext = "<h2>10. Extensions added after the mid-point</h2>"
    ext += ("<p>The additions below go beyond the learning experiments above. All shop data in this section is <b>simulated</b> "
            "(one month of bills generated by <code>make_shop_data.py</code>, with known settings), and customer responses to offers are <b>assumed</b>; "
            "nothing here is measured on a real shop.</p>")
    h = csv("hybrid_results.csv")
    if h is not None:
        ext += ("<h3>10.1 Drift-aware controller</h3><p>Use the tuned (s,S) rule while demand looks normal, and hand over to the learned MAPPO agent when smoothed demand "
                "falls more than 25% below normal or the shelf life is shorter than 4 days. The switch was designed after seeing the first six scenarios, "
                "so the four new scenarios are the fair check.</p>")
        for name, grp in h.groupby("scenario_set", sort=False):
            d = grp[["scenario", "tuned_sS_rule", "MAPPO", "drift_aware_hybrid"]].copy()
            d.columns = ["Scenario", "Tuned (s,S) rule", "MAPPO", "Drift-aware hybrid"]
            avg = pd.DataFrame([["Average", d.iloc[:, 1].mean(), d.iloc[:, 2].mean(), d.iloc[:, 3].mean()]], columns=d.columns)
            ext += table(pd.concat([d, avg], ignore_index=True), f"Average profit per 60-day episode (Rs): {name.lower()}", dec=0)
        ext += ("<p>The hybrid has the highest average in both sets, but not in every row (for example, at demand &minus;25% MAPPO alone earns more). "
                "The thresholds were not tuned, 5 saved agents and 8 episodes per cell were used, and in a real shop sales would under-measure demand when shelves are empty.</p>")
    mo = csv("money_saved_report.csv")
    if mo is not None:
        piv = mo.pivot(index="situation", columns="method", values="profit_per_month").reset_index()
        piv = piv[["situation", "Original rule", "Tuned (s,S) rule", "MAPPO", "Drift-aware hybrid"]]
        piv.columns = ["Situation", "Original rule", "Tuned (s,S) rule", "MAPPO", "Drift-aware hybrid"]
        ext += "<h3>10.2 Money saved</h3>" + table(piv, "Profit per month for one product (Rs), simulator; a month is half of a 60-day run", dec=0)
        ext += ("<p>In the quiet shop the original rule is ahead of MAPPO and the hybrid; the hybrid is still far better than the tuned (s,S) rule there, which loses money.</p>")
    shop = FC.load_shop()
    if shop is not None:
        sales_df, stock_df = shop; m = FC.shop_summary(sales_df, stock_df); wp = FC.weekly_pattern(sales_df)
        wk = float(wp.iloc[5:7, 0].mean())
        ext += ("<h3>10.3 Learning from shop data</h3>"
                f"<p>The simulated month has {m['rows']:,} bill lines ({m['bills']:,} bills over {m['days']} days, seven products). "
                f"A calibration tool (<code>calibrate_from_sales.py</code>) measures the weekly pattern, demand variability, baskets and waste. "
                f"It recovered the weekend multiplier as {wk:.2f} (true value 1.15). Waste was {m['waste_share']:.1%} of perishable units handled (Rs {m['waste_cost']:,.0f} at cost); "
                f"the average bill was Rs {m['avg_bill']:.0f}. With real billing data in the same columns, the same tool would replace the assumed demand numbers.</p>")
        tbl, left, _ = FC.offer_results(T=100, q=0.3, accept35=0.10, days=1500)
        off = tbl.reset_index()[["Policy", "Rs per month", "Waste avoided per day (units)"]]
        ext += ("<h3>10.4 Near-expiry offer</h3><p>Units that would expire in the evening are left alone, discounted, or given free to a customer whose bill reaches a threshold. "
                "Customer responses are assumed (30% of customers just below the threshold add items; 10% of evening bills accept a 35% discount).</p>")
        ext += table(off, "Near-expiry offer versus plain discounts (simulator, assumed responses)", dec={"Rs per month": 0, "Waste avoided per day (units)": 2})
        ext += ("<p>With these assumptions the free-with-bill offer avoids more waste than a discount but earns less cash. It would match the discount in cash only if few customers "
                "would accept the discount. That response must be measured in a pilot with randomised offer days.</p>")
        cs = FC.cross_sell(sales_df, "Curd cup")[["Suggest", "Bought together (lift)", "Margin per unit (Rs)", "Why"]]
        ext += ("<h3>10.5 Shopkeeper tools</h3><p>The app has a <b>Tomorrow's advice</b> tab (price and order for one product, with reasons, safety checks and a second opinion) and a "
                "<b>Shop assistant</b> tab that checks each perishable product, flags stock likely to expire, proposes a price, an offer and add-on products to suggest. "
                "For milk the advice follows the drift-aware controller (the tuned (s,S) rule in normal conditions, the trained MAPPO agent when conditions change); the other products use a transparent rule of thumb (about two days of demand), which is not a trained agent. "
                "Example cross-sell suggestions for curd:</p>")
        ext += table(cs, "Add-ons to suggest with curd (from the simulated bills)", dec={"Bought together (lift)": 2, "Margin per unit (Rs)": 1})
    # ---- research extensions (v3 simulator): all numbers come from the saved result files
    def ms(g):
        g = pd.Series(g).astype(float); m = g.mean(); sd = g.std(ddof=1) if len(g) > 1 else float("nan")
        return f"{m:,.0f}" + (f" \u00b1 {sd:,.0f}" if sd == sd else "")
    ab = csv("results_ablation.csv")
    if ab is not None:
        order = ["Tuned (s,S) rule", "Adaptive (s,S) rule, uses smoothed demand", "MAPPO inputs: basic", "MAPPO inputs: extras", "MAPPO inputs: age"]
        t = ab.groupby(["method", "scenario"]).profit.apply(ms).unstack("scenario"); t = t.reindex([o for o in order if o in t.index]).reset_index().rename(columns={"method": "Method"})
        ext += ("<h3>10.6 Learning or extra inputs? Does stock-by-age help?</h3><p>MAPPO was trained only in the normal shop (12 a day, 4-day shelf life) and tested in three shops. "
                "<i>basic</i> inputs: stock, days left, last demand, weekday. <i>extras</i>: plus smoothed demand and units expiring today (what the earlier MAPPO saw). <i>age</i>: plus units by days left. "
                "The adaptive rule receives the same smoothed-demand input as MAPPO.</p>")
        ext += table(t, "Profit per 60-day episode (Rs); MAPPO is mean \u00b1 standard deviation over 5 training seeds", dec=0)
        ext += ("<p>Adding stock-by-age did <b>not</b> help: the agents earned the same in the normal shop and less in the quiet and short-shelf shops. With 2.5 times longer training (300 iterations, 3 seeds) "
                "the stock-by-age agents were worse again (normal 8,104 vs 8,653; quiet 1,046 vs 2,214; short shelf 1,871 vs 5,991). A rule given the same smoothed-demand input earned 3,383 in the quiet shop, "
                "more than MAPPO (2,516 with the input, 2,159 without), so there the input, not learning, explains the robustness. With a 2-day shelf life neither rule copes (1 and 521) while MAPPO earns about 5,300 to 6,100, "
                "a case where learning matters. The five MAPPO agents with the original inputs ended with identical decisions (checked on 150 states), so a spread of zero understates the real uncertainty and no p-values are quoted.</p>")
    de = csv("results_delays.csv")
    if de is not None:
        t = de.groupby("method").agg(profit=("profit", ms), wasted=("wasted", "mean"), unmet=("unmet", "mean")).round(1).reset_index()
        t.columns = ["Method", "Profit (Rs)", "Wasted units", "Unmet units"]
        ext += ("<h3>10.7 Random supplier delays</h3><p>Orders arrive on time 60% of the time, one day late 30%, two days late 10%. Rules were re-tuned for the delays. <i>pipe</i> = plus units on order; <i>full</i> = stock-by-age and units on order.</p>")
        ext += table(t, "Supplier delays: profit per 60-day episode (MAPPO: mean \u00b1 sd over 5 seeds)", dec={"Wasted units": 1, "Unmet units": 1})
        ext += ("<p>The best method was a rule that counts the units already on order (stock plus units on order, 8,132), ahead of the stock-only rule (7,171) and of every MAPPO variant. "
                "Seeing the units on order helped MAPPO a little (6,675 without, 6,834 with, 7,167 with stock-by-age as well; only the last difference passed a simple test, p = 0.018). "
                "With 300 iterations the delay agents scored lower (5,734 and 5,979), so MAPPO has not caught the classical rule here.</p>")
    pc, pw = csv("results_pricing.csv"), csv("results_pricing_waste.csv")
    if pc is not None:
        t = pc.groupby(["method", "elasticity"]).profit.apply(ms).unstack("elasticity").reset_index().rename(columns={"method": "Method"}); t.columns = ["Method"] + [f"Elasticity {c}" for c in t.columns[1:]]
        ext += ("<h3>10.8 Pricing with a measured price response and finer discounts</h3><p>Five discount levels (0, 10, 20, 30, 40%); demand = base \u00d7 price<sup>\u2212elasticity</sup>. "
                "The price response was measured from a simulated 90-day price test (elasticity 2.0, interval about 1.7 to 2.3). With a 30% margin, a discount raises profit on normal stock only if the elasticity exceeds about 3.3.</p>")
        ext += table(t, "Profit per 60-day episode (Rs), normal shop", dec=0)
        ext += ("<p>The agents almost never discounted (0 to 0.2 days per episode) and a manual markdown rule lost money (7,578 to 7,794 vs 8,826), because efficient ordering wastes only about 2.5 units an episode, "
                "leaving almost nothing for a discount to rescue.</p>")
    if pw is not None:
        t = pw.groupby("method").agg(profit=("profit", ms), discount_days=("discount_days", "mean"), wasted=("wasted", "mean")).round(1).reset_index(); t.columns = ["Method", "Profit (Rs)", "Discount days", "Wasted units"]
        ext += table(t, "Quiet shop (7 a day, elasticity 2.0), where a lot of stock expires", dec={"Discount days": 1, "Wasted units": 1})
        ext += ("<p>Here the pricing agent discounted on about 30 days and earned Rs 407 more than the same agent forced to regular price, but a re-tuned reorder rule earned more than either. "
                "Pricing acts as a clean-up for poor ordering; the better fix is the ordering.</p>")
    mm, ml = csv("results_multi_mappo.csv"), csv("results_multi_mappo_long.csv")
    if mm is not None:
        t = mm.groupby("method").agg(profit=("profit", ms), wasted=("wasted", "mean"), unmet=("unmet", "mean")).round(1).reset_index(); t.columns = ["Method", "Profit (Rs)", "Wasted units", "Unmet units"]
        ext += ("<h3>10.9 MAPPO in the three-product store</h3><p>One pricing network and one inventory network are shared by milk, curd and bread (each product has a one-hot tag); the centralised critics see the stock of all three products.</p>")
        ext += table(t, "Three-product shared-shelf store, 60 fresh episodes", dec={"Wasted units": 1, "Unmet units": 1})
        ext += ("<p>MAPPO earned about Rs 11,550, above the earlier per-product Q-learning (Rs 9,063) and the original rule (Rs 11,425), but below the tuned order-up-to rule (Rs 13,914).")
        if ml is not None:
            lm = ml[ml.method.str.startswith("MAPPO")].profit.round(0).astype(int).tolist()
            ext += f" With 300 iterations the two seeds scored {lm[0]:,} and {lm[1]:,}: one held and one collapsed, so the number of training iterations needs a validation check."
        ext += "</p>"
    ob = csv("results_offer_bandit.csv")
    if ob is not None:
        eg = ob[(ob.waste_value == 0) & (ob.learner == "epsilon-greedy")][["world", "best_arm", "share_of_last_30_days_on_best", "regret_vs_best_Rs"]].copy()
        rd = ob[(ob.waste_value == 0) & (ob.learner == "random arms (no learning)")][["world", "regret_vs_best_Rs"]].rename(columns={"regret_vs_best_Rs": "random"})
        eg = eg.merge(rd, on="world"); eg.columns = ["Hidden customer behaviour", "Best offer", "Share of last 30 evenings on the best offer", "Money lost vs the best (Rs, learner)", "Money lost (Rs, random offers)"]
        ext += ("<h3>10.10 Learning the offer</h3><p>Six offers (none, 15% off, 35% off, free unit with a bill of Rs 75, 100 or 150) are tried on different evenings and an epsilon-greedy learner (a one-step reinforcement-learning problem) "
                "shifts to the best one, without knowing how customers respond. Four simulated worlds with different hidden behaviour; 90 evenings, averaged over 60 runs.</p>")
        ext += table(eg, "Offer learner (waste has no value): 17% would be chance", dec=0)
        ext += ("<p>The learner found the best offer far more often than chance in three worlds. Where nobody responds, all offers are almost equal and there is nothing to learn. UCB did worse than epsilon-greedy in these tests.</p>")
    se = csv("results_sensitivity.csv")
    if se is not None:
        t = se.groupby(["method", "scenario"]).profit.apply(ms).unstack("scenario").reset_index().rename(columns={"method": "Setting changed"})
        ext += "<h3>10.11 Sensitivity to MAPPO's settings</h3>" + table(t, "Profit per 60-day episode (Rs), 3 seeds, 100 iterations, one setting changed at a time", dec=0)
        ext += ("<p>Results did not change for a smaller learning rate or a discount factor of 0.99, and changed little for 0.90. A larger clip range (0.3) lowered profit in all three shops, "
                "and a larger learning rate (3e-3) lowered it with a short shelf life.</p>")
    parts.append(ext)
except Exception as exc:                                    # never block the rest of the report
    print("Section 10 skipped:", exc)

# ------------------------------------------------------------------ 9 limitations, 10 conclusion
parts.append("""
<h2>11. Limitations</h2>
<ul>
<li>MAPPO results depend on how long it trains: with more inputs, 300 iterations scored lower than 120, and one of two 3-product runs collapsed. No validation-based stopping was used.</li>
<li>The extension experiments use 3 to 5 training seeds per setting; some agents converge to identical decisions, so spreads understate uncertainty. The stock-by-age, delay and pricing results are negative or mixed and are reported as such.</li>
<li>All shop data, the price test and the customer responses to offers are simulated; the offer learner and calibration tools are demonstrated, not validated on a real shop.</li>
<li>All results come from a simulated store. Demand, costs and the response of demand to price are assumptions, not measured store data.</li>
<li>The tabular learners and neural fitted Q-iteration were tested on one product (and tabular Q-learning on the three-product store). The two-agent tabular learners
are independent learners with sequential action conditioning rather than centralised-critic methods.</li>
<li>MAPPO was implemented in NumPy and trained with a single setting, without tuning. It receives a smoothed demand estimate and the number of units expiring, which the
rules and tabular agents do not, so its advantage over the order-up-to rule, and its robustness, cannot be attributed to learning alone. It was not tested in the three-product store.</li>
<li>Variability between training runs is large for the tabular methods. Conclusions rest on 5 to 15 independent runs per method, and the stress tests use 15 to 20 episodes per cell.</li>
<li>The adaptation experiments cover two designs of tabular agents and do not rule out better state representations or algorithms.</li>
</ul>
<h2>12. Conclusion</h2>
<p>Under a revenue-based reward, coordinating pricing and reordering through two cooperating agents outperformed a single agent controlling both decisions in every training run.
Under a profit-based reward that charges purchase, holding and ordering costs, the tabular learning methods did not reliably differ from one another and did not beat a tuned
classical rule. MAPPO did better: averaged over 15 training seeds it beat the tuned order-up-to rule in 14, by learning to order in large batches, which is the idea behind (s,S) policies.
A classical (s,S) rule tuned by grid search was still the best method in normal conditions. When conditions changed, MAPPO was the more robust of the two in several scenarios,
although it receives inputs the rules do not use. In a three-product store with a shared shelf, tabular per-product learning again fell below the tuned rule at every capacity tested.
Calibrating the simulation with real sales data, testing MAPPO in the multi-product store and separating the effect of its extra inputs from the effect of learning are the main next steps.</p>
""")

CSS = """
*{box-sizing:border-box}
body{font-family:'Segoe UI',Calibri,Arial,sans-serif;color:#1f2933;line-height:1.6;margin:0;background:#fff;font-size:15px}
.page{max-width:980px;margin:0 auto;padding:44px 40px 70px}
header{border-bottom:3px solid #1f3a5f;padding-bottom:16px;margin-bottom:24px}
.kicker{text-transform:uppercase;letter-spacing:.12em;font-size:12px;color:#52606d;font-weight:600}
h1{font-size:27px;line-height:1.25;margin:6px 0 6px;color:#1f3a5f}
.sub{color:#52606d;font-size:14px}
h2{font-size:19px;color:#1f3a5f;margin:38px 0 10px;border-bottom:1px solid #d9e2ec;padding-bottom:6px}
h3{font-size:15px;margin:0 0 6px;color:#1f3a5f}
p{margin:8px 0}
.summary{background:#f5f7fa;border-left:4px solid #1f3a5f;padding:14px 22px 8px;border-radius:2px}
.summary ol{margin:6px 0 10px;padding-left:20px}
.summary li{margin:6px 0}
.wrap{overflow-x:auto;margin:14px 0 6px}
table.data{border-collapse:collapse;width:100%;font-size:13px}
table.data caption{caption-side:top;text-align:left;font-weight:600;font-size:13px;color:#323f4b;padding:0 0 6px}
table.data th{background:#eef2f7;border-top:1px solid #9aa5b1;border-bottom:1px solid #9aa5b1;padding:7px 9px;text-align:right;font-weight:600;vertical-align:bottom}
table.data td{padding:6px 9px;border-bottom:1px solid #e4e7eb;text-align:right;vertical-align:top}
table.data th:first-child,table.data td:first-child,table.data .l{text-align:left}
table.data tbody tr:last-child td{border-bottom:1px solid #9aa5b1}
.note{font-size:12.5px;color:#52606d;margin:4px 0 12px}
figure{margin:18px 0;text-align:center}
figure img{max-width:100%;height:auto}
figcaption{font-size:12.5px;color:#52606d;text-align:left;margin-top:6px}
ul{padding-left:22px} li{margin:6px 0}
@media print{
  body{font-size:11.5pt} .page{padding:0;max-width:none}
  h2{page-break-after:avoid} figure,table.data,.summary{page-break-inside:avoid}
  @page{size:A4;margin:16mm}
}
"""
page = (f"<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1'>"
        f"<title>Coordinated Reinforcement Learning for Retail Pricing and Inventory: Results Report</title><style>{CSS}</style></head>"
        f"<body><div class='page'>{''.join(parts)}</div></body></html>")
with open(p("ARMS_report.html"), "w", encoding="utf-8") as f:
    f.write(page)
print("Saved", p("ARMS_report.html"))
