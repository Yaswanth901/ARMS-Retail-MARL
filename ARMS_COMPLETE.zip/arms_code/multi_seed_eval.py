"""
Multi-seed statistical validation.
A single training run proves nothing - it could be a lucky seed. This reruns
Single-Agent and Two-Agent tabular Q-learning across N independent seeds and
reports mean +/- std, plus a paired significance test (since both methods are
evaluated on the SAME seeds, a paired test is the correct choice, not an
unpaired one).
"""
import os
BASE = os.path.dirname(os.path.abspath(__file__))  # save/load next to this script, works on any OS
import numpy as np
import pandas as pd
from scipy import stats
from retail_env import RetailEnv
from agents import SingleAgentQLearner, TwoAgentQLearner, discretize

N_SEEDS = 8
N_EPISODES = 800   # fewer than the single-run 1500, since we now repeat it 8x - keeps total compute reasonable
HORIZON = 60


def train_single(seed):
    agent = SingleAgentQLearner()
    np.random.seed(seed)
    last_rewards = []
    for ep in range(N_EPISODES):
        env = RetailEnv(horizon=HORIZON, seed=seed * 10000 + ep)
        s = env.reset()
        ep_reward = 0
        for _ in range(HORIZON):
            s_disc = discretize(s)
            idx, (price_a, inv_a) = agent.act(s)
            s_next, (rp, ri), done, info = env.step(price_a, inv_a)
            agent.update(s_disc, idx, rp + ri, discretize(s_next), done)
            s = s_next
            ep_reward += rp + ri
        agent.decay()
        if ep >= N_EPISODES - 100:
            last_rewards.append(ep_reward)
    return np.mean(last_rewards)


def train_two(seed):
    agent = TwoAgentQLearner()
    np.random.seed(seed)
    last_rewards = []
    for ep in range(N_EPISODES):
        env = RetailEnv(horizon=HORIZON, seed=seed * 10000 + ep)
        s = env.reset()
        ep_reward = 0
        for _ in range(HORIZON):
            (s_disc, p_idx, i_idx), (price_a, inv_a) = agent.act(s)
            s_next, (rp, ri), done, info = env.step(price_a, inv_a)
            agent.update(s_disc, p_idx, i_idx, rp, ri, discretize(s_next), done)
            s = s_next
            ep_reward += rp + ri
        agent.decay()
        if ep >= N_EPISODES - 100:
            last_rewards.append(ep_reward)
    return np.mean(last_rewards)


if __name__ == "__main__":
    single_means, two_means = [], []
    for seed in range(N_SEEDS):
        sm = train_single(seed)
        tm = train_two(seed)
        single_means.append(sm)
        two_means.append(tm)
        print(f"seed {seed}: single-agent={sm:9.0f}   two-agent={tm:9.0f}   diff={tm-sm:+8.0f}")

    single_means, two_means = np.array(single_means), np.array(two_means)
    t_stat, p_value = stats.ttest_rel(two_means, single_means)

    print(f"\n=== Across {N_SEEDS} independent seeds ===")
    print(f"Single-Agent:  {single_means.mean():9.0f}  +/- {single_means.std():7.0f}")
    print(f"Two-Agent:     {two_means.mean():9.0f}  +/- {two_means.std():7.0f}")
    print(f"Mean improvement: {(two_means.mean()/single_means.mean()-1)*100:+.1f}%")
    print(f"Paired t-test:  t={t_stat:.3f}, p={p_value:.5f}")
    print(f"Statistically significant at alpha=0.05: {'YES' if p_value < 0.05 else 'NO'}")

    pd.DataFrame({"seed": range(N_SEEDS), "single_agent": single_means, "two_agent": two_means}) \
        .to_csv(os.path.join(BASE, "multi_seed_results.csv"), index=False)
