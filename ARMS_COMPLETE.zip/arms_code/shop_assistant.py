"""SHOP ASSISTANT: checks every perishable product on the shelf and gives a daily action list:
reorder advice, a price for stock that will probably expire, a bundle offer, and which products to suggest with it.
Reads current_stock.csv (product,stock,days_left) and the shop's bills.   Run:  python shop_assistant.py
Own file:  python shop_assistant.py --file my_stock.csv"""
import argparse, pandas as pd
import features_core as F
ap = argparse.ArgumentParser(); ap.add_argument("--file", default="current_stock.csv"); a = ap.parse_args()
cur = pd.read_csv(a.file); plans = F.shop_plan(list(zip(cur["product"], cur["stock"], cur["days_left"])))
print("=" * 78); print("SHOP ASSISTANT: today's action list (simulated shop data; advice, not orders)"); print("=" * 78)
rows = []
for p in plans:
    print(f"\n{p['product'].upper()}: {p['stock']} on the shelf, oldest has {p['days_left']} day(s) left; normally sells about {p['mean_daily']} a day")
    print(f"  Likely to sell before expiry : about {p['expected_sales']:.0f}  ->  at risk of expiring: {p['at_risk']} units")
    print(f"  REORDER                      : {p['order']} units   ({p['method']})")
    print(f"  PRICE                        : Rs {p['price']:.1f}   ({p['discount_note']})")
    cs = p["cross_sell"]
    print(f"  SUGGEST WITH IT ({cs.iloc[0]['Why']}): " + ", ".join(f"{r['Suggest']} (lift {r['Bought together (lift)']}, Rs {r['Margin per unit (Rs)']}/unit)" for _, r in cs.iterrows()))
    if p["offer"]: print("  OFFER                        : " + p["offer"]["text"])
    rows.append(dict(product=p["product"], stock=p["stock"], days_left=p["days_left"], at_risk=p["at_risk"], reorder=p["order"], price=p["price"], suggest=cs.iloc[0]["Suggest"]))
pd.DataFrame(rows).to_csv("daily_plan.csv", index=False)
print("\nSaved daily_plan.csv. All numbers come from the simulated shop data; customer response to offers is assumed.")
