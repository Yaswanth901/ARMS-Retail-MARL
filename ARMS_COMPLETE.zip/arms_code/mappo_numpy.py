"""
MAPPO (multi-agent PPO with a centralised critic, trained centrally and executed decentrally)
for the pricing + inventory store, written in plain NumPy (no deep-learning library needed).

  - Two ACTORS (policies): the pricing actor sees the store state; the inventory actor sees the store state
    plus the pricing agent's choice. At run time each actor uses only its own inputs (decentralised execution).
  - Two CENTRALISED CRITICS (value functions): during training each critic sees the store state AND the pricing
    agent's action, i.e. information a single actor does not have (centralised training).
  - PPO clipped objective, GAE advantages, entropy bonus, Adam, gradient clipping.
  - Safety: the guardrails of guardrails.py are applied as ACTION MASKS (no below-cost price unless stock expires
    within a day; no order that would overfill the shelf), so the policy learns inside the allowed set.
  - Same profit economics, same fresh test seeds (900000+) and same evaluation as every other method.

The neural networks and their gradients are hand-written; run `python mappo_numpy.py --check` to verify the
gradients numerically against finite differences.

    python mappo_numpy.py                    # train 5 seeds and compare with the other methods (about 8-10 minutes)
    python mappo_numpy.py --seeds 1 --iterations 100     # quick trial
    python mappo_numpy.py --check            # gradient check only
"""
import os
BASE = os.path.dirname(os.path.abspath(__file__))
import argparse
import time
import numpy as np
import pandas as pd
import retail_env_v2 as E
from retail_env_v2 import (RetailEnvV2, PRICE_ACTIONS, INV_ACTIONS, PRICE_MULTIPLIER, REORDER_QTY,
                           BASE_PRICE, UNIT_COST, MAX_STOCK)

HORIZON = 60
REWARD_SCALE = 0.01          # rewards are in the hundreds; scaling keeps the critics well-conditioned


# ------------------------------------------------------------------ inputs and masks
def features(s):
    return np.array([s["stock"] / 45.0, min(s["days_to_expiry"], 4) / 4.0, s["demand_ema"] / 20.0,
                     s["expiring"] / 25.0, s["seasonality"], s["recent_demand"] / 25.0])


def price_mask(s):
    m = np.ones(3)
    for j, a in enumerate(PRICE_ACTIONS):
        if BASE_PRICE * PRICE_MULTIPLIER[a] < UNIT_COST and s["days_to_expiry"] > 1:
            m[j] = 0.0
    return m


def inv_mask(s):
    room = max(MAX_STOCK - s["stock"], 0)
    return np.array([1.0 if (a == "NO_REORDER" or REORDER_QTY[a] <= room) else 0.0 for a in INV_ACTIONS])


# ------------------------------------------------------------------ tiny neural network with manual backprop
# entropy bonus selected on validation episodes (select_entropy.py); falls back to 0.01 if the selection file is missing
def _selected_entropy(key):
    import json, os
    try: return float(json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "hp_selection.json")))[key])
    except Exception: return 0.01

class MLP:
    def __init__(self, sizes, rng, out_gain):
        self.W, self.b = [], []
        for i in range(len(sizes) - 1):
            gain = out_gain if i == len(sizes) - 2 else np.sqrt(2.0)
            self.W.append(rng.normal(0, gain / np.sqrt(sizes[i]), (sizes[i], sizes[i + 1])))
            self.b.append(np.zeros(sizes[i + 1]))
        self.mW = [np.zeros_like(w) for w in self.W]; self.vW = [np.zeros_like(w) for w in self.W]
        self.mb = [np.zeros_like(b) for b in self.b]; self.vb = [np.zeros_like(b) for b in self.b]
        self.t = 0

    def forward(self, x):
        acts, h = [x], x
        for i in range(len(self.W) - 1):
            h = np.tanh(h @ self.W[i] + self.b[i])
            acts.append(h)
        return h @ self.W[-1] + self.b[-1], acts

    def backward(self, acts, dout):
        gW, gb = [None] * len(self.W), [None] * len(self.W)
        d = dout
        for i in range(len(self.W) - 1, -1, -1):
            gW[i] = acts[i].T @ d
            gb[i] = d.sum(0)
            if i > 0:
                d = (d @ self.W[i].T) * (1.0 - acts[i] ** 2)
        return gW, gb

    def adam(self, gW, gb, lr, max_norm=0.5):
        norm = np.sqrt(sum((g ** 2).sum() for g in gW) + sum((g ** 2).sum() for g in gb))
        scale = min(1.0, max_norm / (norm + 1e-8))
        self.t += 1
        b1, b2 = 0.9, 0.999
        for i in range(len(self.W)):
            for p_, g_, m_, v_ in ((self.W, gW, self.mW, self.vW), (self.b, gb, self.mb, self.vb)):
                g = g_[i] * scale
                m_[i] = b1 * m_[i] + (1 - b1) * g
                v_[i] = b2 * v_[i] + (1 - b2) * g * g
                p_[i] -= lr * (m_[i] / (1 - b1 ** self.t)) / (np.sqrt(v_[i] / (1 - b2 ** self.t)) + 1e-8)


def masked_probs(logits, mask):
    z = logits + (mask - 1.0) * 1e9
    z = z - z.max(axis=-1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=-1, keepdims=True)


def actor_loss_and_grads(net, x, mask, a, old_logp, adv, clip=0.2, ent=0.01):
    B = len(x)
    logits, acts = net.forward(x)
    p = masked_probs(logits, mask)
    logp_all = np.log(p + 1e-12)
    logp = logp_all[np.arange(B), a]
    ratio = np.exp(logp - old_logp)
    surr = np.minimum(ratio * adv, np.clip(ratio, 1 - clip, 1 + clip) * adv)
    H = -(p * logp_all).sum(1)
    loss = -surr.mean() - ent * H.mean()
    active = np.where(adv >= 0, ratio < 1 + clip, ratio > 1 - clip)       # is the unclipped term the minimum?
    dlogp = -(np.where(active, adv, 0.0) * ratio) / B
    onehot = np.zeros_like(p)
    onehot[np.arange(B), a] = 1.0
    dlogits = dlogp[:, None] * (onehot - p)
    dlogits += -ent * (-p * (logp_all + H[:, None])) / B                  # entropy bonus gradient
    gW, gb = net.backward(acts, dlogits)
    return loss, gW, gb


def critic_loss_and_grads(net, x, ret, vf=0.5):
    B = len(x)
    v, acts = net.forward(x)
    err = v[:, 0] - ret
    loss = vf * 0.5 * (err ** 2).mean()
    gW, gb = net.backward(acts, (vf * err / B)[:, None])
    return loss, gW, gb


# ------------------------------------------------------------------ the MAPPO learner
class MAPPO:
    def __init__(self, seed=0, hidden=64, lr=1e-3, gamma=0.97, lam=0.95, clip=0.2, epochs=4, minibatch=256, ent=None):
        ent = _selected_entropy("MAPPO") if ent is None else ent
        self.rng = np.random.default_rng(seed)
        r = self.rng
        self.actor_p = MLP([6, hidden, hidden, 3], r, 0.01)       # pricing policy: store state
        self.actor_i = MLP([9, hidden, hidden, 3], r, 0.01)       # inventory policy: store state + price choice
        self.crit_p = MLP([6, hidden, hidden, 1], r, 1.0)         # pricing critic: state only (a baseline must not depend on the pricing agent's own action)
        self.crit_i = MLP([9, hidden, hidden, 1], r, 1.0)
        self.lr, self.gamma, self.lam, self.clip = lr, gamma, lam, clip
        self.epochs, self.minibatch, self.ent = epochs, minibatch, ent

    # one decision step; greedy=True for deployment
    def act(self, s, greedy=False):
        x = features(s)[None]
        mp = price_mask(s)
        pp = masked_probs(self.actor_p.forward(x)[0], mp)[0]
        a_p = int(np.argmax(pp)) if greedy else int(self.rng.choice(3, p=pp))
        onehot = np.zeros(3); onehot[a_p] = 1.0
        xi = np.concatenate([x[0], onehot])[None]
        mi = inv_mask(s)
        pi = masked_probs(self.actor_i.forward(xi)[0], mi)[0]
        a_i = int(np.argmax(pi)) if greedy else int(self.rng.choice(3, p=pi))
        if greedy:
            return a_p, a_i
        joint = xi                                                  # centralised critic input
        vp = float(self.crit_p.forward(x)[0][0, 0]); vi = float(self.crit_i.forward(joint)[0][0, 0])
        return dict(xp=x[0], mp=mp, ap=a_p, lpp=float(np.log(pp[a_p] + 1e-12)),
                    xi=xi[0], mi=mi, ai=a_i, lpi=float(np.log(pi[a_i] + 1e-12)), vp=vp, vi=vi)

    def _gae(self, r, v, last_v=0.0):
        T = len(r)
        adv = np.zeros(T)
        g = 0.0
        for t in reversed(range(T)):
            nv = last_v if t == T - 1 else v[t + 1]
            delta = r[t] + self.gamma * nv - v[t]
            g = delta + self.gamma * self.lam * g
            adv[t] = g
        return adv, adv + np.array(v)

    def update(self, episodes):
        keys = ["xp", "mp", "ap", "lpp", "xi", "mi", "ai", "lpi"]
        cols = {k: [] for k in keys}
        advp, retp, advi, reti = [], [], [], []
        for ep in episodes:                                         # advantages per episode
            for k in keys:
                cols[k] += [st[k] for st in ep["steps"]]
            ap_, rp_ = self._gae(ep["rp"], [st["vp"] for st in ep["steps"]])
            ai_, ri_ = self._gae(ep["ri"], [st["vi"] for st in ep["steps"]])
            advp.append(ap_); retp.append(rp_); advi.append(ai_); reti.append(ri_)
        D = {k: np.array(v) for k, v in cols.items()}
        advp, retp, advi, reti = map(np.concatenate, (advp, retp, advi, reti))
        advp = (advp - advp.mean()) / (advp.std() + 1e-8)
        advi = (advi - advi.mean()) / (advi.std() + 1e-8)
        n = len(advp)
        for _ in range(self.epochs):
            idx = self.rng.permutation(n)
            for lo in range(0, n, self.minibatch):
                b = idx[lo:lo + self.minibatch]
                _, gW, gb = actor_loss_and_grads(self.actor_p, D["xp"][b], D["mp"][b], D["ap"][b], D["lpp"][b], advp[b], self.clip, self.ent)
                self.actor_p.adam(gW, gb, self.lr)
                _, gW, gb = actor_loss_and_grads(self.actor_i, D["xi"][b], D["mi"][b], D["ai"][b], D["lpi"][b], advi[b], self.clip, self.ent)
                self.actor_i.adam(gW, gb, self.lr)
                _, gW, gb = critic_loss_and_grads(self.crit_p, D["xp"][b], retp[b])
                self.crit_p.adam(gW, gb, self.lr)
                _, gW, gb = critic_loss_and_grads(self.crit_i, D["xi"][b], reti[b])
                self.crit_i.adam(gW, gb, self.lr)

    def save(self, path):
        arrays = {}
        for name, net in (("actor_p", self.actor_p), ("actor_i", self.actor_i), ("crit_p", self.crit_p), ("crit_i", self.crit_i)):
            for i, (w, b) in enumerate(zip(net.W, net.b)):
                arrays[f"{name}_W{i}"], arrays[f"{name}_b{i}"] = w, b
        np.savez(path, **arrays)

    @staticmethod
    def load(path, seed=0):
        agent = MAPPO(seed)
        z = np.load(path)
        for name, net in (("actor_p", agent.actor_p), ("actor_i", agent.actor_i), ("crit_p", agent.crit_p), ("crit_i", agent.crit_i)):
            for i in range(len(net.W)):
                net.W[i], net.b[i] = z[f"{name}_W{i}"], z[f"{name}_b{i}"]
        return agent

    def policy(self):
        """For evaluation with train_v2.evaluate: state -> (price_action, inventory_action, 0)."""
        def f(s):
            a_p, a_i = self.act(s, greedy=True)
            return PRICE_ACTIONS[a_p], INV_ACTIONS[a_i], 0
        return f


def rollout(agent, seed, it, n_episodes):
    episodes, profits = [], []
    for j in range(n_episodes):
        env = RetailEnvV2(HORIZON, seed=seed * 1_000_000 + it * 1000 + j)
        s = env.reset()
        steps, rp, ri, prof = [], [], [], 0.0
        for _ in range(HORIZON):
            d = agent.act(s)
            s, (r_p, r_i), _, info = env.step(PRICE_ACTIONS[d["ap"]], INV_ACTIONS[d["ai"]])
            steps.append(d); rp.append(r_p * REWARD_SCALE); ri.append(r_i * REWARD_SCALE); prof += info["profit"]
        episodes.append(dict(steps=steps, rp=rp, ri=ri)); profits.append(prof)
    return episodes, float(np.mean(profits))


def train(seed=0, iterations=300, episodes_per_iter=16, verbose=False):
    agent = MAPPO(seed)
    curve = []
    for it in range(iterations):
        episodes, mean_profit = rollout(agent, seed, it, episodes_per_iter)
        agent.update(episodes)
        curve.append(mean_profit)
        if verbose and (it % 25 == 0 or it == iterations - 1):
            print(f"    iteration {it:3d}  mean training profit {mean_profit:7.0f}", flush=True)
    return agent, curve


# ------------------------------------------------------------------ gradient check
def gradient_check():
    rng = np.random.default_rng(0)
    B = 12
    x = rng.normal(size=(B, 9))
    mask = (rng.random((B, 3)) > 0.2).astype(float); mask[:, 0] = 1.0
    net = MLP([9, 8, 8, 3], rng, 0.5)
    p = masked_probs(net.forward(x)[0], mask)
    a = np.array([rng.choice(3, p=pi) for pi in p])
    old = np.log(p[np.arange(B), a] + 1e-12) + rng.normal(0, 0.01, B)    # ratio near 1: inside the clip range
    adv = rng.normal(size=B)

    def loss_fn():
        return actor_loss_and_grads(net, x, mask, a, old, adv)[0]
    _, gW, gb = actor_loss_and_grads(net, x, mask, a, old, adv)
    worst = 0.0
    for i in range(len(net.W)):
        for idx in [(0, 0), (1, 1), (net.W[i].shape[0] - 1, net.W[i].shape[1] - 1)]:
            orig = net.W[i][idx]
            net.W[i][idx] = orig + 1e-6; lp = loss_fn()
            net.W[i][idx] = orig - 1e-6; lm = loss_fn()
            net.W[i][idx] = orig
            num = (lp - lm) / 2e-6
            worst = max(worst, abs(num - gW[i][idx]) / (abs(num) + abs(gW[i][idx]) + 1e-9))
    cnet = MLP([9, 8, 8, 1], rng, 1.0)
    ret = rng.normal(size=B)
    closs = lambda: critic_loss_and_grads(cnet, x, ret)[0]
    _, cW, cb = critic_loss_and_grads(cnet, x, ret)
    cworst = 0.0
    for i in range(len(cnet.W)):
        idx = (0, 0)
        orig = cnet.W[i][idx]
        cnet.W[i][idx] = orig + 1e-6; lp = closs()
        cnet.W[i][idx] = orig - 1e-6; lm = closs()
        cnet.W[i][idx] = orig
        num = (lp - lm) / 2e-6
        cworst = max(cworst, abs(num - cW[i][idx]) / (abs(num) + abs(cW[i][idx]) + 1e-9))
    print(f"gradient check: actor worst relative error {worst:.2e}, critic worst relative error {cworst:.2e} "
          f"(values below 1e-4 mean the hand-written gradients are correct)")
    return worst < 1e-4 and cworst < 1e-4


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="MAPPO in NumPy")
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--seed-start", type=int, default=0)
    ap.add_argument("--out", default="mappo_results.csv")
    ap.add_argument("--iterations", type=int, default=300)
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    ok = gradient_check()
    if a.check:
        raise SystemExit(0 if ok else 1)

    import train_v2 as T
    import app_core as C
    rows, curve0 = [], None
    os.makedirs(os.path.join(BASE, "mappo_weights"), exist_ok=True)
    for sd in range(a.seed_start, a.seed_start + a.seeds):
        t0 = time.time()
        print(f"seed {sd}: training MAPPO ({a.iterations} iterations x 16 episodes)...", flush=True)
        agent, curve = train(sd, a.iterations, verbose=(sd == 0))
        agent.save(os.path.join(BASE, "mappo_weights", f"seed{sd}.npz"))
        ev = T.evaluate(agent.policy(), n=100)
        rows.append(dict(seed=sd, profit=ev["profit"].mean(), wasted=ev["wastage"].mean(), unmet=ev["stockout"].mean()))
        if sd == 0:
            curve0 = curve
            pd.DataFrame({"iteration": range(len(curve)), "mean_training_profit": curve}).to_csv(os.path.join(BASE, "mappo_curve_seed0.csv"), index=False)
        print(f"  evaluated on 100 fresh episodes: profit {rows[-1]['profit']:.0f} ({time.time() - t0:.0f}s)", flush=True)
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(BASE, a.out), index=False)
    tuned = T.evaluate(lambda s: C.TUNED_RULE(s))["profit"].mean()
    orig = T.evaluate(T.rule_policy)["profit"].mean()
    print(f"\nMAPPO over {len(df)} seeds: mean {df.profit.mean():.0f} +/- {df.profit.std(ddof=1) if len(df) > 1 else 0:.0f} "
          f"| tuned rule {tuned:.0f} | original rule {orig:.0f} | MAPPO above tuned rule in {(df.profit > tuned).sum()}/{len(df)} seeds")
