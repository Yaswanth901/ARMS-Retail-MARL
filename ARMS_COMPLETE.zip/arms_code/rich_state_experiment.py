"""
Does a richer state (smoothed demand + units expiring) let adaptive-trained RL beat tuned fixed rules?
Reuses the scenarios, test random numbers and rule results of adaptive_experiment.py, so every column
is directly comparable. Run adaptive_experiment.py first.

NOTE ON HONESTY: this is the SECOND thing tried after the first adaptive-training attempt failed.
The richer state was motivated by two weaknesses found beforehand (noisy 'recent demand', and the
agent being unable to see expiring units), not picked by looking at test results. Still, report it
as 'second attempt', not as a clean one-shot test.

    python rich_state_experiment.py
"""
import os
BASE = os.path.dirname(os.path.abspath(__file__))
import numpy as np
import pandas as pd
import retail_env_v2 as E
from retail_env_v2 import RetailEnvV2, PRICE_ACTIONS, INV_ACTIONS
from agents_rich import TwoAgentRich, discretize_rich
from guardrails import apply_guardrails
import app_core as C
import adaptive_experiment as A


def train_rich(episodes, seed, regimes):
    np.random.seed(seed)
    rng = np.random.default_rng(seed)
    agent = TwoAgentRich()
    for ep in range(episodes):
        demand = float(rng.choice(regimes))
        with C.scenario(demand, None):
            env = RetailEnvV2(A.HORIZON, seed=seed * 100000 + ep)
            s = env.reset()
            for _ in range(A.HORIZON):
                (s_disc, p_idx, i_idx), (p, i) = agent.act(s)
                p, i, _ = apply_guardrails(s, p, i)
                p_idx, i_idx = PRICE_ACTIONS.index(p), INV_ACTIONS.index(i)
                s_next, (rp, ri), done, _ = env.step(p, i)
                agent.update(s_disc, p_idx, i_idx, rp, ri, discretize_rich(s_next), done)
                s = s_next
        agent.decay()
    agent.eps = 0.0
    return agent


if __name__ == "__main__":
    prev = pd.read_csv(os.path.join(BASE, "adaptive_experiment_raw.csv"))
    rows = []
    for seed in range(A.N_SEEDS):
        print(f"seed {seed}: training rich-state adaptive agent...", flush=True)
        agent = train_rich(A.EPISODES_ADAPTIVE, seed, A.REGIMES)
        for sc_name, d, sh, shocks in A.SCENARIOS:
            rows.append(dict(seed=seed, method="RL adaptive, RICH state", scenario=sc_name,
                             profit=A.scenario_profit(A.rl_policy(agent), d, sh, shocks)))
    new = pd.DataFrame(rows)
    df = pd.concat([prev, new], ignore_index=True)
    df.to_csv(os.path.join(BASE, "rich_state_raw.csv"), index=False)

    order = ["Original rule", "Rule tuned at 12", "Rule tuned on mix", "RL fixed-train",
             "RL adaptive-train", "RL adaptive, RICH state"]
    scen_order = [s[0] for s in A.SCENARIOS]
    mean_tbl = df.groupby(["scenario", "method"])["profit"].mean().unstack()[order].loc[scen_order].round(0)
    mean_tbl.to_csv(os.path.join(BASE, "rich_state_means.csv"))
    pd.set_option("display.width", 280)
    pd.set_option("display.max_columns", 20)
    print("\nMEAN PROFIT (Rs per 60-day episode; RL = mean over %d training seeds)" % A.N_SEEDS)
    print(mean_tbl.to_string())
    print("\nMean over all 8 scenarios:")
    print(mean_tbl.mean().round(0).to_string())

    rule_mix = df[df.method == "Rule tuned on mix"].set_index("scenario")["profit"]
    rich = df[df.method == "RL adaptive, RICH state"]
    print("\nTRAINING SEEDS (of %d) where the RICH-state agent beats 'Rule tuned on mix':" % A.N_SEEDS)
    for sc in scen_order:
        print(f"  {sc:34s} {int((rich[rich.scenario == sc]['profit'] > rule_mix[sc]).sum())}/{A.N_SEEDS}")
    print("\nSTD across training seeds, rich-state agent:")
    print(rich.groupby("scenario")["profit"].std().loc[scen_order].round(0).to_string())
