"""
Learners, rules and evaluation for the three-product store.

RL: each product gets its OWN pair of Q-learning agents (pricing, then inventory), as in the single-product
study. The only thing the products share is the shelf, which each agent sees as 'how full is the shelf'.
Rules: the original thresholds, and an order-up-to rule with one target per product, tuned by grid search.
"""
import numpy as np
import pandas as pd
from agents import TwoAgentQLearner, rule_based_policy
import json
import retail_env_multi as M
from retail_env_multi import (MultiStoreEnv, MultiTraceRNG, PRODUCTS, N,
                              PRICE_ACTIONS, INV_ACTIONS, REORDER_QTY)

HORIZON = 60


# ------------------------------------------------------------------ RL
def make_disc(k):
    mean = PRODUCTS[k]["demand"]

    def disc(state):
        sb = 0 if state["stock"] < 0.8 * mean else (1 if state["stock"] < 2.0 * mean else 2)
        eb = min(state["days_to_expiry"], 3)
        db = 0 if state["recent_demand"] < 0.75 * mean else (1 if state["recent_demand"] < 1.33 * mean else 2)
        u = state["shelf_used"] / M.CAPACITY
        ub = 0 if u < 0.5 else (1 if u < 0.8 else 2)
        return (sb, eb, db, ub)
    return disc


class TwoAgentMulti(TwoAgentQLearner):
    def __init__(self, k, **kw):
        super().__init__(**kw)
        self.disc = make_disc(k)

    def act(self, state):
        s = self.disc(state)
        if np.random.rand() < self.eps:
            p_idx = np.random.randint(len(PRICE_ACTIONS))
        else:
            p_idx = int(np.argmax(self._rowp(s)))
        if np.random.rand() < self.eps:
            i_idx = np.random.randint(len(INV_ACTIONS))
        else:
            i_idx = int(np.argmax(self._rowi(s, p_idx)))
        return (s, p_idx, i_idx), (PRICE_ACTIONS[p_idx], INV_ACTIONS[i_idx])


def train_multi(seed=42, episodes=1500, team_reward=False):
    np.random.seed(seed)
    agents = [TwoAgentMulti(k) for k in range(N)]
    for ep in range(episodes):
        env = MultiStoreEnv(HORIZON, seed=seed * 100000 + ep)
        states = env.reset()
        for _ in range(HORIZON):
            acts = [agents[k].act(states[k]) for k in range(N)]
            nxt, rewards, done, infos = env.step([a[1] for a in acts])
            team_p = sum(r[0] for r in rewards)                       # whole-store scores, used when team_reward=True
            team_i = sum(r[1] for r in rewards)
            for k in range(N):
                (s, p_idx, _), (_, _) = acts[k]
                i_exec = INV_ACTIONS.index(infos[k]["inv_exec"])      # learn from the order that actually happened
                rp, ri = (team_p, team_i) if team_reward else rewards[k]
                agents[k].update(s, p_idx, i_exec, rp, ri, agents[k].disc(nxt[k]), done)
            states = nxt
        for a in agents:
            a.decay()
    for a in agents:
        a.eps = 0.0
    return agents


# ------------------------------------------------------------------ policies: states -> [(price, inventory)] per product
def policy_original(states):
    return [rule_based_policy(s) for s in states]


def policy_tuned(targets, mod_exp=1):
    def f(states):
        out = []
        for k, s in enumerate(states):
            fits = [i for i in INV_ACTIONS if s["stock"] + REORDER_QTY[i] <= targets[k]]
            price = "MODERATE_DISCOUNT" if s["days_to_expiry"] <= mod_exp else "REGULAR_PRICE"
            out.append((price, fits[-1] if fits else "NO_REORDER"))
        return out
    return f


def policy_rl(agents):
    def f(states):
        outs = []
        for k, s in enumerate(states):
            old = agents[k].eps
            agents[k].eps = 0.0
            outs.append(agents[k].act(s)[1])
            agents[k].eps = old
        return outs
    return f


# ------------------------------------------------------------------ evaluation (same random numbers for every method)
def run_episode(policy, uniforms, horizon=HORIZON, shocks=None, seed=None):
    # uniforms given -> common random numbers (same demand for every method); otherwise ordinary random numbers
    env = MultiStoreEnv(horizon, rng=MultiTraceRNG(uniforms, shocks)) if uniforms is not None else MultiStoreEnv(horizon, seed=seed)
    states = env.reset()
    rows = []
    for d in range(horizon):
        acts = policy(states)
        nxt, _, _, infos = env.step(acts)
        for k, inf in enumerate(infos):
            rows.append(dict(day=d + 1, product=inf["product"], stock_start=states[k]["stock"],
                             expiry=states[k]["days_to_expiry"], price_tier=acts[k][0], reorder=inf["inv_exec"],
                             demand=inf["demand"], sold=inf["units_sold"], wasted=inf["wasted"], unmet=inf["unmet"],
                             profit=inf["profit"], cut=inf["cut"], shelf_used=inf["shelf_used"]))
        states = nxt
    return pd.DataFrame(rows)


def evaluate(policy, n=100, seed0=900000, horizon=HORIZON, shocks=None, crn=True):
    out = []
    for k in range(n):
        u = np.random.default_rng(seed0 + k).random((horizon, N)) if crn else None
        df = run_episode(policy, u, horizon, shocks, seed=seed0 + k)
        row = dict(profit=df["profit"].sum(), wasted=df["wasted"].sum(), unmet=df["unmet"].sum(),
                   cuts=df["cut"].sum(), shelf_use=df.groupby("day")["shelf_used"].first().mean() / M.CAPACITY)
        for name, g in df.groupby("product"):
            row[f"profit_{name}"] = g["profit"].sum()
        out.append(row)
    return pd.DataFrame(out)


# ------------------------------------------------------------------ save / load trained agents
def _to_list(k):
    return [_to_list(x) for x in k] if isinstance(k, (tuple, list)) else int(k)


def _to_tuple(k):
    return tuple(_to_tuple(x) for x in k) if isinstance(k, list) else k


def save_agents(agents, path):
    data = [{"Qp": [[_to_list(k), [float(x) for x in v]] for k, v in a.Qp.items()],
             "Qi": [[_to_list(k), [float(x) for x in v]] for k, v in a.Qi.items()]} for a in agents]
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f)


def load_agents(path):
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    agents = []
    for k, d in enumerate(data):
        a = TwoAgentMulti(k)
        a.Qp = {_to_tuple(key): np.array(v, dtype=float) for key, v in d["Qp"]}
        a.Qi = {_to_tuple(key): np.array(v, dtype=float) for key, v in d["Qi"]}
        a.eps = 0.0
        agents.append(a)
    return agents
