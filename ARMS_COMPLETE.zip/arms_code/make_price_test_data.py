"""Creates a SIMULATED 90-day price test for one product: each day a random discount (0, 10, 20 or 30%) is tried, and the units sold are recorded.
The true price response (elasticity 2.0) is saved separately so estimate_price_response.py can be checked against it.
Run:  python make_price_test_data.py"""
import json, numpy as np, pandas as pd
from datetime import date, timedelta
rng = np.random.default_rng(77); TRUE_ELASTICITY, BASE, PRICE = 2.0, 12.0, 50.0
WEEK = [1.0, 1.0, 1.0, 1.0, 1.0, 1.15, 1.15]; rows = []
for d in range(90):
    day = date(2026, 6, 1) + timedelta(days=d); disc = float(rng.choice([0.0, 0.10, 0.20, 0.30])); mult = 1 - disc
    units = int(rng.poisson(BASE * WEEK[day.weekday()] * mult ** (-TRUE_ELASTICITY)))
    rows.append(dict(date=day.isoformat(), weekday=day.strftime("%a"), discount=disc, price=PRICE * mult, units_sold=units))
pd.DataFrame(rows).to_csv("SIMULATED_price_test.csv", index=False)
json.dump(dict(true_elasticity=TRUE_ELASTICITY, note="SIMULATED price test: random daily discount, Poisson sales, no stock-outs"), open("price_test_truth.json", "w"), indent=2)
print(f"SIMULATED price test written: {len(rows)} days, discounts tried: 0/10/20/30%; mean units sold {np.mean([r['units_sold'] for r in rows]):.1f} a day")
