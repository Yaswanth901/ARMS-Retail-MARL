"""Pages added to the app: Shop assistant, Offers, Research, About. Each page is wrapped by render() so one page's error never breaks the others."""
import json, os
import numpy as np, pandas as pd
import features_core as F

HERE = os.path.dirname(os.path.abspath(__file__))


def _ms(g):
    g = pd.Series(g).astype(float); m = g.mean(); s = g.std(ddof=1) if len(g) > 1 else float("nan")
    return f"{m:,.0f}" + (f" ± {s:,.0f}" if s == s else "")


def _need(st, name, cmd):
    df = F.read_csv_safe(name)
    if df is None: st.info(f"Results not found. Run  {cmd}")
    return df


# ------------------------------------------------------------------ shop assistant
def shop_assistant_tab(st):
    shop = F.load_shop()
    if shop is None:
        st.info("Shop data not found. Run  python make_shop_data.py"); return
    st.caption("Enter the shelf for each perishable product. Simulated shop data; customer response to offers is assumed.")
    rows, defaults = [], {"Milk packet": (34, 1), "Curd cup": (16, 2), "Bread": (20, 3)}
    cols = st.columns(3)
    for col, (product, (d_stock, d_days)) in zip(cols, defaults.items()):
        col.markdown("**" + product + "**")
        stock = col.number_input("On the shelf", min_value=0, max_value=200, value=d_stock, key="sa_s_" + product)
        days = col.number_input("Days left (oldest)", min_value=1, max_value=6, value=d_days, key="sa_d_" + product)
        rows.append((product, stock, days))
    for p in F.shop_plan(rows):
        st.markdown("#### " + p["product"])
        k = st.columns(5)
        k[0].metric("On the shelf", p["stock"]); k[1].metric("Sells per day", p["mean_daily"]); k[2].metric("Likely to expire", p["at_risk"])
        k[3].metric("Reorder", p["order"]); k[4].metric("Price (Rs)", f"{p['price']:.1f}")
        cs = p["cross_sell"]
        st.write("Suggest with it: " + ", ".join(f"{r['Suggest']} (Rs {r['Margin per unit (Rs)']:.0f} margin)" for _, r in cs.iterrows()) + f"   [{cs.iloc[0]['Why']}]")
        if p["offer"]: st.info(p["offer"]["text"])
    with st.expander("Single-product advice with reasons and safety checks"):
        c1, c2, c3, c4 = st.columns(4)
        stock = c1.number_input("Packets on the shelf", min_value=0, max_value=45, value=18, key="ad_stock")
        expiry = c2.number_input("Days left (oldest)", min_value=1, max_value=6, value=2, key="ad_exp")
        demand = c3.number_input("Sold per day (recent)", min_value=1.0, max_value=40.0, value=11.0, key="ad_dem")
        shelf = c4.number_input("Shelf life (days)", min_value=1, max_value=7, value=4, key="ad_shelf")
        weekend = st.checkbox("Tomorrow is a weekend day", value=False, key="ad_wk")
        a = F.advice(stock, expiry, demand, shelf, weekend)
        st.success(f"Price Rs {a['price']:.1f}  |  order {a['qty']} packets   ({a['mode']})")
        st.markdown("\n".join("- " + w for w in a["why"] + a["safety"]))
        d1, d2 = st.columns(2)
        d1.metric("Tuned (s,S) rule", f"Rs {a['rule'][0]:.1f} / order {a['rule'][1]}")
        d2.metric("Learned MAPPO agent", f"Rs {a['learned'][0]:.1f} / order {a['learned'][1]}", f"confidence {a['learned'][2]:.0%}")


# ------------------------------------------------------------------ offers
def offers_tab(st):
    import offer_bandit as OB
    shop = F.load_shop()
    if shop is None:
        st.info("Shop data not found. Run  python make_shop_data.py"); return
    sales, stock = shop; m = F.shop_summary(sales, stock)
    st.caption("One simulated month of bills. Customer responses below are assumptions that a real pilot would measure.")
    k = st.columns(4)
    k[0].metric("Bill lines", f"{m['rows']:,}"); k[1].metric("Bills", f"{m['bills']:,}"); k[2].metric("Average bill", f"Rs {m['avg_bill']:.0f}")
    k[3].metric("Expired stock", f"{m['waste_share']:.1%}", f"Rs {m['waste_cost']:,.0f} at cost")
    st.bar_chart(F.weekly_pattern(sales))
    st.markdown("#### Near-expiry offer: free packet with a bigger bill, or a discount?")
    c1, c2, c3 = st.columns(3)
    t = c1.slider("Bill size for the free packet (Rs)", min_value=50, max_value=200, value=100, step=25)
    q = c2.slider("Customers just below it who add items", min_value=0.0, max_value=0.6, value=0.3, step=0.05)
    acc = c3.slider("Evening bills that accept 35% off", min_value=0.02, max_value=0.2, value=0.10, step=0.01)
    if st.button("Compare offers"):
        table, left, _ = F.offer_results(T=t, q=q, accept35=acc); st.dataframe(table)
    st.markdown("#### Let the system learn the best offer")
    st.caption("Without knowing how customers respond, the learner tries offers on different evenings and settles on the best one (90 days, averaged over 20 runs).")
    worlds = list(OB.WORLDS)
    w = st.selectbox("Hidden customer behaviour", worlds, index=3)
    wv = st.number_input("Value of each unit saved from waste (Rs)", min_value=0.0, max_value=50.0, value=0.0, step=5.0)
    if st.button("Run the learner"):
        a15, a35, qq = OB.WORLDS[w]; world = OB.OfferWorld(a15, a35, qq)
        best, true, share, regret, dist = OB.run(world, OB.EpsGreedy, wv, days=90, runs=20)
        st.write(f"Best offer in this world: **{OB.ARMS[best]}**. The learner used it on {share:.0%} of the last 30 evenings (random choice would be 17%).")
        st.bar_chart(pd.Series(dist, index=OB.ARMS, name="Share of the last 30 evenings"))


# ------------------------------------------------------------------ research
def research_tab(st):
    st.caption("Saved results from the simulator. Mean ± standard deviation over training seeds; profit in Rs per 60-day episode.")
    h = F.read_csv_safe("hybrid_results.csv"); mo = F.read_csv_safe("money_saved_report.csv")
    st.markdown("#### 1. Drift-aware controller: the rule normally, the learned agent when conditions change")
    if h is None: st.info("Run  python hybrid_test.py")
    else:
        for name, grp in h.groupby("scenario_set", sort=False):
            g = grp.set_index("scenario")[["tuned_sS_rule", "MAPPO", "drift_aware_hybrid"]]; g.columns = ["Tuned (s,S) rule", "MAPPO", "Drift-aware hybrid"]
            g.loc["Average"] = g.mean(); st.markdown("*" + name + "*"); st.dataframe(g.round(0).astype(int))
    if mo is not None:
        with st.expander("Money saved (Rs per month, one product)"):
            st.dataframe(mo.pivot(index="situation", columns="method", values="profit_per_month"))
    st.markdown("#### 2. Learning or extra inputs? Does stock-by-age help?")
    ab = _need(st, "results_ablation.csv", "python experiments_v3.py ablation")
    if ab is not None:
        order = ["Tuned (s,S) rule", "Adaptive (s,S) rule, uses smoothed demand", "MAPPO inputs: basic", "MAPPO inputs: extras", "MAPPO inputs: age"]
        t = ab.groupby(["method", "scenario"]).profit.apply(_ms).unstack("scenario"); st.dataframe(t.reindex([o for o in order if o in t.index]))
        st.caption("basic = stock, days left, last demand, weekday. extras = + smoothed demand and units expiring. age = + units by days left.")
    lg = F.read_csv_safe("results_longer.csv")
    if lg is not None:
        with st.expander("Same comparison with 2.5x longer training (300 iterations, 3 seeds)"):
            st.dataframe(lg.groupby(["experiment", "scenario", "method"]).profit.apply(_ms))
    st.markdown("#### 3. Random supplier delays")
    de = _need(st, "results_delays.csv", "python experiments_v3.py delays")
    if de is not None:
        t = de.groupby("method").agg(profit=("profit", _ms), wasted=("wasted", "mean"), unmet=("unmet", "mean")).round(1); st.dataframe(t)
        st.caption("Orders arrive on time 60%, one day late 30%, two days late 10%. The rules were re-tuned for delays.")
    st.markdown("#### 4. Pricing with a measured price response and finer discounts")
    p = os.path.join(HERE, "price_response.json")
    if os.path.exists(p):
        pr = json.load(open(p)); st.metric("Measured elasticity (simulated 90-day price test)", f"{pr['elasticity']:.2f}", f"90% interval {pr['ci_low']:.2f} to {pr['ci_high']:.2f}")
    pc = _need(st, "results_pricing.csv", "python experiments_v3.py pricing")
    if pc is not None:
        st.dataframe(pc.groupby(["method", "elasticity"]).profit.apply(_ms).unstack("elasticity"))
        st.caption("Days per episode on which a discount was used:")
        st.dataframe(pc.groupby(["method", "elasticity"]).discount_days.mean().unstack("elasticity").round(1))
    pw = F.read_csv_safe("results_pricing_waste.csv")
    if pw is not None:
        st.markdown("*In a quiet shop where a lot of stock expires (7 a day)*")
        st.dataframe(pw.groupby("method").agg(profit=("profit", _ms), discount_days=("discount_days", "mean"), wasted=("wasted", "mean")).round(1))
    st.markdown("#### 5. Three products sharing one shelf")
    mm = _need(st, "results_multi_mappo.csv", "python mappo_multi.py")
    if mm is not None:
        t = mm.groupby("method").agg(profit=("profit", _ms), wasted=("wasted", "mean"), unmet=("unmet", "mean")).round(1); st.dataframe(t)
    ml = F.read_csv_safe("results_multi_mappo_long.csv")
    if ml is not None:
        with st.expander("Same with longer training (300 iterations)"):
            st.dataframe(ml[ml.method.str.startswith("MAPPO")][["method", "seed", "profit", "wasted", "unmet"]].round(0))
    st.markdown("#### 6. Sensitivity to MAPPO's settings")
    se = _need(st, "results_sensitivity.csv", "python experiments_v3.py sensitivity --seeds 3 --iters 100")
    if se is not None:
        st.dataframe(se.groupby(["method", "scenario"]).profit.apply(_ms).unstack("scenario"))


# ------------------------------------------------------------------ about
def about_tab(st, agents, policy_table):
    st.markdown("""
- **Idea:** each day a pricing agent picks a price, then an inventory agent sees it and picks a reorder size. Each agent has its own reward (profit parts).
- **Methods:** rules (original, tuned order-up-to, tuned (s,S)), Q-learning (one or two agents, with guardrails and a fallback), neural fitted Q-iteration, MAPPO.
- **Honest results:** the tuned (s,S) rule is best in normal conditions; MAPPO is more robust when demand or shelf life changes; learned pricing adds little with the assumed price response.
- **Data:** the simulator's demand and the shop data are simulated; nothing here is a real shop. A pilot would replace the assumptions.
- **Safety:** guardrails block below-cost prices and overfull shelves; the fallback hands unclear decisions to a simple rule.
""")
    with st.expander("What the Q-learning agent chose for each stock level and days left"):
        which = st.radio("Policy", ["Trained with guardrails", "Trained without guardrails"], horizontal=True)
        st.dataframe(policy_table(agents["two_g"] if which.startswith("Trained with") else agents["two"]))


PAGES = [("shop_assistant", shop_assistant_tab), ("offers", offers_tab), ("research", research_tab)]

def render(st, tab_list):
    """tab_list: the three tab containers for Shop assistant, Offers, Research."""
    for tab, (label, fn) in zip(tab_list, PAGES):
        with tab:
            try: fn(st)
            except Exception as e: st.error(f"The {label.replace('_', ' ')} page hit a problem: {e}")
