"""
A stronger classical baseline: an (s,S)-type rule, tuned by grid search.

When every order costs a fixed amount, the classical answer is to order rarely but in big batches:
  - if stock <= s: order the chosen batch size; otherwise order nothing
  - moderate discount when days left <= mod_exp, otherwise regular price
Parameters are chosen on separate tuning seeds (500000+); results are measured on the same fresh test seeds as every
other method (900000+) and on a larger independent set (2,000,000+).

    python tune_sS.py
"""
import os
BASE = os.path.dirname(os.path.abspath(__file__))
import itertools
import pandas as pd
from retail_env_v2 import RetailEnvV2


def make_sS(s_thr, order_action, mod_exp=0):
    def policy(state):
        inv = order_action if state["stock"] <= s_thr else "NO_REORDER"
        price = "MODERATE_DISCOUNT" if state["days_to_expiry"] <= mod_exp else "REGULAR_PRICE"
        return price, inv, 0
    return policy


def mean_profit(policy, seed0, n):
    total = 0.0
    for k in range(n):
        env = RetailEnvV2(60, seed=seed0 + k)
        s = env.reset()
        for _ in range(60):
            p, i, _ = policy(s)
            s, _, _, info = env.step(p, i)
            total += info["profit"]
    return total / n


if __name__ == "__main__":
    import train_v2 as T
    import app_core as C
    rows = []
    for thr, q, me in itertools.product(range(0, 41, 2), ["SMALL_REORDER", "FULL_REORDER"], [0, 1, 2]):
        rows.append(dict(s=thr, order=q, mod_exp=me, tuning_profit=mean_profit(make_sS(thr, q, me), 500000, 40)))
    g = pd.DataFrame(rows).sort_values("tuning_profit", ascending=False)
    g.to_csv(os.path.join(BASE, "tuned_sS_grid.csv"), index=False)
    best = g.iloc[0]
    pol = make_sS(int(best.s), best.order, int(best.mod_exp))
    t100 = T.evaluate(pol)["profit"].mean()
    t300 = mean_profit(pol, 2_000_000, 300)
    o100 = T.evaluate(lambda s: C.TUNED_RULE(s))["profit"].mean()
    o300 = mean_profit(lambda s: C.TUNED_RULE(s), 2_000_000, 300)
    out = pd.DataFrame([
        dict(rule="Tuned order-up-to rule", setting="order up to 42 units", test_100_seeds=o100, test_300_new_seeds=o300),
        dict(rule="Tuned (s,S) rule", setting=f"order {best.order} when stock <= {int(best.s)}; moderate discount when days left <= {int(best.mod_exp)}",
             test_100_seeds=t100, test_300_new_seeds=t300)])
    out.to_csv(os.path.join(BASE, "sS_summary.csv"), index=False)
    print(f"Searched {len(g)} settings. Best: s={int(best.s)}, order={best.order}, mod_exp={int(best.mod_exp)}")
    print(out.round(0).to_string(index=False))
