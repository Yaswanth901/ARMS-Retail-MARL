@echo off
cd /d "%~dp0"
python demo_cli.py %*
pause
