"""
Stress test of the 10 saved MAPPO agents (seeds 5-14) against the classical rules, in the same six scenarios as the
stress test. Nobody is retrained or re-tuned for the scenarios. 20 episodes per cell, same random demand for everyone.

    python mappo_stress.py
"""
import os
BASE = os.path.dirname(os.path.abspath(__file__))
import numpy as np
import pandas as pd
import app_core as C
import mappo_numpy as M

N_EP = 20
SEED0 = 555000


def cell(method, name, demand, shelf, shocks):
    out = []
    with C.scenario(demand, shelf):
        for k in range(N_EP):
            u = np.random.default_rng(SEED0 + k).random(60)
            out.append(C.run_episode(method, {}, u, 60, shocks)["Profit (Rs)"].sum())
    return float(np.mean(out))


if __name__ == "__main__":
    rows = []
    for name, demand, shelf, shocks in C.STRESS_SCENARIOS:
        name = " ".join(name.split())
        for label, method in [("Original rule", C.METHODS[0]), ("Tuned order-up-to rule", C.METHODS[5]), ("Tuned (s,S) rule", C.METHODS[6])]:
            rows.append(dict(scenario=name, method=label, seed="", profit=cell(method, name, demand, shelf, shocks)))
    for sd in range(5, 15):
        C._MAPPO[6] = M.MAPPO.load(os.path.join(BASE, "mappo_weights", f"seed{sd}.npz"), sd)   # run_episode reads MAPPO via get_mappo()
        for name, demand, shelf, shocks in C.STRESS_SCENARIOS:
            rows.append(dict(scenario=" ".join(name.split()), method="MAPPO", seed=sd, profit=cell(C.METHODS[7], name, demand, shelf, shocks)))
    C._MAPPO.pop(6, None)
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(BASE, "mappo_stress.csv"), index=False)
    pd.set_option("display.width", 220)
    scen = list(dict.fromkeys(df.scenario))
    out = pd.DataFrame(index=scen)
    for m in ["Original rule", "Tuned order-up-to rule", "Tuned (s,S) rule"]:
        out[m] = df[df.method == m].set_index("scenario")["profit"].round(0)
    mp = df[df.method == "MAPPO"].groupby("scenario")["profit"]
    out["MAPPO mean"] = mp.mean().round(0); out["MAPPO std"] = mp.std().round(0)
    ss = df[df.method == "Tuned (s,S) rule"].set_index("scenario")["profit"]
    out["MAPPO seeds beating (s,S)"] = [int((df[(df.method == "MAPPO") & (df.scenario == s)]["profit"] > ss[s]).sum()) for s in scen]
    print(out.loc[scen].to_string())
