"""ARMS interactive app.  Start with:  python -m streamlit run app.py"""
import json
import os
import numpy as np
import pandas as pd
import streamlit as st
import app_core as C
import agents_multi as AM
import retail_env_multi as RM
import app_pages as PG

st.set_page_config(page_title="ARMS", layout="wide")
st.markdown("<style>.block-container{padding-top:1.4rem;max-width:1250px} h1{font-size:1.9rem} [data-testid=stMetricValue]{font-size:1.45rem}</style>",
            unsafe_allow_html=True)
st.title("ARMS: retail pricing and inventory with reinforcement learning")
st.caption("A simulated store selling a perishable product (cost Rs 35, price Rs 50, 4-day shelf life). Demand and customer responses are assumptions.")


@st.cache_resource
def load_saved_agents():
    return C.load_agents()


@st.cache_resource
def load_store():
    pa, pt = os.path.join(C.BASE, "trained_store3_agents.json"), os.path.join(C.BASE, "store3_tuned_targets.json")
    if not (os.path.exists(pa) and os.path.exists(pt)):
        return None
    with open(pt) as f:
        targets = json.load(f)["targets"]
    return AM.load_agents(pa), targets


agents = st.session_state.get("agents")
if agents is None:
    agents = load_saved_agents()
if agents is None:
    st.warning("No trained agents found. Train them now (about 2 minutes), or run `python train_for_app.py` and refresh.")
    if st.button("Train agents now"):
        with st.spinner("Training 3 agents..."):
            agents = C.train_agents(42, 1000)
            C.save_agents(agents)
        st.session_state["agents"] = agents
    if agents is None:
        st.stop()

# ------------------------------------------------------------------ sidebar
st.sidebar.header("Store")
base_demand = st.sidebar.slider("Average daily demand", 6, 24, 12)
shelf_life = st.sidebar.slider("Shelf life (days)", 2, 6, 4)
horizon = st.sidebar.slider("Days to simulate", 14, 60, 30)
demand_seed = st.sidebar.number_input("Random seed", 0, 100000, 7)
profile = C.load_profile()
weekday_mult = None
if profile is not None and st.sidebar.checkbox("Use the measured weekly pattern", value=False):
    weekday_mult = profile["weekday_mult"]
with st.sidebar.expander("Demand shock"):
    shock_on = st.checkbox("Inject a demand shock", value=False)
    shock_day = st.slider("Starts on day", 1, horizon, min(10, horizon))
    shock_len = st.slider("Lasts (days)", 1, 14, 5)
    shock_mult = st.slider("Demand multiplier", 0.3, 3.0, 2.0, 0.1)
with st.sidebar.expander("Safety and retraining"):
    gap = st.slider("Fallback confidence threshold", 0, 300, int(C.CONFIDENCE_GAP), help="Higher = more decisions go to the simple rule.")
    train_seed = st.number_input("Training seed", 0, 10000, 7)
    train_eps = st.slider("Training episodes", 300, 1500, 600, 100)
    if st.button("Retrain the Q-learning agents"):
        with st.spinner("Training 3 agents..."):
            agents = C.train_agents(int(train_seed), int(train_eps))
        st.session_state["agents"] = agents
        st.session_state.pop("batch", None)
        st.session_state.pop("stress", None)
        st.success(f"Using agents trained with seed {int(train_seed)}.")

shocks = C.make_shocks(shock_day if shock_on else 0, shock_len, shock_mult)
uniforms = np.random.default_rng(int(demand_seed)).random(horizon)

tabs = st.tabs(["Live replay", "Compare", "Stress test", "3 products", "Shop assistant", "Offers", "Research", "About"])

with C.scenario(base_demand, shelf_life, weekday_mult):

    # -------------------------------------------------------------- live replay
    with tabs[0]:
        method = st.selectbox("Who makes the decisions?", C.METHODS, index=3)
        df = C.run_episode(method, agents, uniforms, horizon, shocks, gap)
        day = st.slider("Day", 1, horizon, 1)
        row = df.iloc[day - 1]
        c = st.columns(5)
        c[0].metric("Stock at start of day", int(row["Stock"]))
        c[1].metric("Days to expiry", int(row["Days to expiry"]))
        c[2].metric("Price", f'{row["Price tier"]} (Rs {float(row["Price (Rs)"])})')
        c[3].metric("Reorder", str(row["Reorder"]))
        c[4].metric("Day's profit (Rs)", float(row["Profit (Rs)"]))
        d = st.columns(3)
        d[0].metric("Customers wanted", int(row["Demand"]))
        d[1].metric("Sold", int(row["Sold"]))
        d[2].metric("Wasted / unmet", f'{int(row["Wasted"])} / {int(row["Unmet"])}')
        st.info("Situation: " + str(row["Situation"]))
        if row["Guardrail"]:
            st.warning("Guardrail stepped in: " + str(row["Guardrail"]))
        if row["Fallback"]:
            st.warning("The agent was unsure, so the simple rule made this decision.")
        left, right = st.columns(2)
        left.markdown("**Cumulative profit (Rs)**")
        left.line_chart(df.set_index("Day")["Cumulative profit"])
        right.markdown("**Stock at start of day vs customer demand**")
        right.line_chart(df.set_index("Day")[["Stock", "Demand"]])
        with st.expander("Day-by-day table"):
            st.dataframe(df[["Day", "Stock", "Days to expiry", "Demand", "Price tier", "Reorder", "Sold", "Wasted", "Unmet",
                             "Profit (Rs)", "Guardrail"]].head(day))

    # -------------------------------------------------------------- compare
    with tabs[1]:
        st.caption("Every decision-maker faces the same random demand. One trace can favour any method; the averaged test below is fairer.")
        res = C.compare_methods(agents, uniforms, horizon, shocks, gap)
        st.dataframe(C.totals(res))
        st.line_chart(pd.DataFrame({m: dfm["Cumulative profit"].values for m, dfm in res.items()}, index=range(1, horizon + 1)))
        st.markdown("**Average over many episodes**")
        n = st.slider("Episodes (60 days each)", 10, 60, 30, 10)
        if st.button("Run the averaged test"):
            with st.spinner("Simulating..."):
                st.session_state["batch"] = C.batch_eval(agents, n, 60, shocks, gap)
        if "batch" in st.session_state:
            summary = C.summarize_batch(st.session_state["batch"])
            st.dataframe(summary)
            st.bar_chart(summary.set_index("Method")["Mean profit (Rs)"])

    # -------------------------------------------------------------- stress test
    with tabs[2]:
        st.caption("Every agent and rule was built for demand 12 and shelf life 4. Nobody is retrained for the scenarios.")
        n_stress = st.slider("Episodes per scenario", 5, 20, 10, 5)
        if st.button("Run the stress test"):
            with st.spinner("Running 6 scenarios x 8 methods..."):
                st.session_state["stress"] = C.stress_test(agents, n_stress, 60, gap)
        if "stress" in st.session_state:
            sdf = st.session_state["stress"]
            for title, col in (("Mean profit (Rs per 60-day episode)", None), ("Wasted units", "Wasted"), ("Unmet demand (units)", "Unmet")):
                st.markdown("**" + title + "**")
                st.dataframe(C.stress_pivot(sdf) if col is None else C.stress_pivot(sdf, col))

    # -------------------------------------------------------------- three products
    with tabs[3]:
        store = load_store()
        st.caption("Milk, curd and bread share one shelf (%d units); 30%% of customers of a sold-out product try the next one." % RM.CAPACITY)
        if store is None:
            st.warning("Store agents not found. Run `python multi_experiment.py`.")
        else:
            store_agents, store_targets = store
            pols = {"Original rule": AM.policy_original, "Tuned order-up-to rule": AM.policy_tuned(store_targets),
                    "Q-learning (per product)": AM.policy_rl(store_agents)}
            s_method = st.selectbox("Who runs the store?", list(pols), index=1, key="store_method")
            s_days = st.slider("Days to simulate", 14, 60, 30, key="store_days")
            u3 = np.random.default_rng(int(demand_seed)).random((s_days, RM.N))
            sdf = AM.run_episode(pols[s_method], u3, s_days, shocks)
            day3 = st.slider("Day", 1, s_days, 1, key="store_day")
            today = sdf[sdf["day"] == day3]
            for col, (_, r) in zip(st.columns(RM.N), today.iterrows()):
                col.markdown("**" + str(r["product"]) + "**")
                col.metric("Stock", int(r["stock_start"]))
                col.metric("Days to expiry", int(r["expiry"]))
                col.metric("Price", C.SHORT_PRICE[r["price_tier"]])
                col.metric("Reorder", C.SHORT_INV[r["reorder"]])
                col.caption("Sold %d of %d | wasted %d | unmet %d" % (r["sold"], r["demand"], r["wasted"], r["unmet"]))
            used = int(today["shelf_used"].iloc[0])
            st.write("Shelf after today's orders: %d of %d units" % (used, RM.CAPACITY))
            st.progress(min(used / RM.CAPACITY, 1.0))
            if int(today["cut"].sum()):
                st.warning("The shelf was full: some orders were cut to fit.")
            l3, r3 = st.columns(2)
            l3.markdown("**Stock at start of day**")
            l3.line_chart(sdf.pivot(index="day", columns="product", values="stock_start"))
            r3.markdown("**Cumulative profit (Rs)**")
            r3.line_chart(sdf.pivot(index="day", columns="product", values="profit").cumsum())
            rows = []
            for name, pol in pols.items():
                dd = AM.run_episode(pol, u3, s_days, shocks)
                rows.append({"Method": name, "Profit (Rs)": round(dd["profit"].sum()), "Wasted": int(dd["wasted"].sum()),
                             "Unmet": int(dd["unmet"].sum()), "Orders cut by shelf": int(dd["cut"].sum())})
            st.markdown("**Same demand, three methods**")
            st.dataframe(pd.DataFrame(rows))
            saved = os.path.join(C.BASE, "store3_results.csv")
            if os.path.exists(saved):
                with st.expander("Saved result: 100 fresh 60-day episodes"):
                    st.dataframe(pd.read_csv(saved).round(1))

    # -------------------------------------------------------------- about
    with tabs[7]:
        PG.about_tab(st, agents, C.policy_table)

# ------------------------------------------------------------------ pages that do not depend on the sidebar scenario
PG.render(st, [tabs[4], tabs[5], tabs[6]])
