"""
Adaptive-training experiment.

Question: fixed rules (even tuned ones) cannot react when demand changes. An RL agent sees recent
demand in its state, so if it is TRAINED across several demand levels it may learn to adapt.
Does it actually beat a fairly tuned fixed rule when conditions change?

Fair setup:
  - 'RL fixed-train'    : two-agent RL + guardrails, trained only at demand 12 (as before)
  - 'RL adaptive-train' : same learner, trained on a random mix of demand levels 7 / 12 / 18
  - 'Rule tuned at 12'  : tuned order-up-to rule (tune_baseline.py)
  - 'Rule tuned on mix' : the same rule family, tuned on the SAME mix of demand levels 7/12/18
  - 'Original rule'     : the first rule-based baseline
Tested on fresh random numbers in 8 scenarios, including levels the agent never trained on
(demand 9, 15), a shorter shelf life (2 days), and within-episode surges and slumps.
Repeated over several training seeds because single training runs are unreliable.

    python adaptive_experiment.py          (about 8-10 minutes)
"""
import os
BASE = os.path.dirname(os.path.abspath(__file__))
import itertools
import sys
import numpy as np
import pandas as pd
import retail_env_v2 as E
from retail_env_v2 import RetailEnvV2, PRICE_ACTIONS, INV_ACTIONS, REORDER_QTY
from agents import TwoAgentQLearner, discretize, rule_based_policy
from guardrails import apply_guardrails
import app_core as C
from tune_baseline import make_policy

HORIZON = 60
REGIMES = [7, 12, 18]
N_SEEDS = 5
EPISODES_FIXED = 800
EPISODES_ADAPTIVE = 1500
N_TEST = 20


def train_two_guarded(episodes, seed, regimes):
    """Two-agent Q-learning with guardrails; each episode uses a demand level drawn from `regimes`."""
    np.random.seed(seed)
    rng = np.random.default_rng(seed)
    agent = TwoAgentQLearner()
    for ep in range(episodes):
        demand = float(rng.choice(regimes))
        with C.scenario(demand, None):
            env = RetailEnvV2(HORIZON, seed=seed * 100000 + ep)
            s = env.reset()
            for _ in range(HORIZON):
                (s_disc, p_idx, i_idx), (p, i) = agent.act(s)
                p, i, _ = apply_guardrails(s, p, i)
                p_idx, i_idx = PRICE_ACTIONS.index(p), INV_ACTIONS.index(i)
                s_next, (rp, ri), done, _ = env.step(p, i)
                agent.update(s_disc, p_idx, i_idx, rp, ri, discretize(s_next), done)
                s = s_next
        agent.decay()
    agent.eps = 0.0
    return agent


def rl_policy(agent):
    def f(s):
        old = agent.eps
        agent.eps = 0.0
        out = agent.act(s)
        agent.eps = old
        p, i = out[1]
        p, i, _ = apply_guardrails(s, p, i)
        return p, i
    return f


def rule_policy(rule):
    return lambda s: rule(s)[:2]


def orig_rule(s):
    return rule_based_policy(s)


SCENARIOS = [
    ("Demand 7  (seen in training)", 7, 4, {}),
    ("Demand 9  (never seen)", 9, 4, {}),
    ("Demand 12 (seen)", 12, 4, {}),
    ("Demand 15 (never seen)", 15, 4, {}),
    ("Demand 18 (seen)", 18, 4, {}),
    ("Surge x2.5, days 10-14", 12, 4, C.make_shocks(10, 5, 2.5)),
    ("Slump x0.4, days 20-29", 12, 4, C.make_shocks(20, 10, 0.4)),
    ("Shelf life 2 days (never seen)", 12, 2, {}),
]


def scenario_profit(policy, demand, shelf, shocks, n=N_TEST, seed0=333000):
    total = 0.0
    with C.scenario(demand, shelf):
        for k in range(n):
            u = np.random.default_rng(seed0 + k).random(HORIZON)
            env = C.make_env(HORIZON, u, shocks)
            s = env.reset()
            for _ in range(HORIZON):
                p, i = policy(s)
                s, _, _, info = env.step(p, i)
                total += info["profit"]
    return total / n


def tune_on_mix():
    best, best_val = None, -1e18
    for target, ce, me in itertools.product(range(15, 46, 3), [0, 1], [1, 2]):
        pol = rule_policy(make_policy(target, ce, 5, me))
        val = np.mean([scenario_profit(pol, d, 4, {}, n=25, seed0=444000) for d in REGIMES])
        if val > best_val:
            best, best_val = (target, ce, 5, me), val
    return best


if __name__ == "__main__":
    print("Tuning a rule on the demand mix 7/12/18...", flush=True)
    mix_params = tune_on_mix()
    print("  best mix-tuned rule (target, clear_exp, clear_stock, mod_exp):", mix_params, flush=True)

    fixed_rules = {
        "Original rule": orig_rule,
        "Rule tuned at 12": rule_policy(C.TUNED_RULE),
        "Rule tuned on mix": rule_policy(make_policy(*mix_params)),
    }
    rows = []
    for name, pol in fixed_rules.items():
        for sc_name, d, sh, shocks in SCENARIOS:
            rows.append(dict(seed=-1, method=name, scenario=sc_name, profit=scenario_profit(pol, d, sh, shocks)))

    for seed in range(N_SEEDS):
        print(f"seed {seed}: training RL fixed-train and RL adaptive-train...", flush=True)
        fixed = train_two_guarded(EPISODES_FIXED, seed, [12])
        adaptive = train_two_guarded(EPISODES_ADAPTIVE, seed, REGIMES)
        for name, agent in [("RL fixed-train", fixed), ("RL adaptive-train", adaptive)]:
            for sc_name, d, sh, shocks in SCENARIOS:
                rows.append(dict(seed=seed, method=name, scenario=sc_name,
                                 profit=scenario_profit(rl_policy(agent), d, sh, shocks)))

    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(BASE, "adaptive_experiment_raw.csv"), index=False)
    order = ["Original rule", "Rule tuned at 12", "Rule tuned on mix", "RL fixed-train", "RL adaptive-train"]
    scen_order = [s[0] for s in SCENARIOS]

    mean_tbl = df.groupby(["scenario", "method"])["profit"].mean().unstack()[order].loc[scen_order].round(0)
    std_tbl = df[df.seed >= 0].groupby(["scenario", "method"])["profit"].std().unstack()[["RL fixed-train", "RL adaptive-train"]].loc[scen_order].round(0)
    mean_tbl.to_csv(os.path.join(BASE, "adaptive_experiment_means.csv"))
    pd.set_option("display.width", 250)
    print("\nMEAN PROFIT (Rs per 60-day episode; RL = mean over %d training seeds)" % N_SEEDS)
    print(mean_tbl.to_string())
    print("\nSTD ACROSS TRAINING SEEDS (RL only)")
    print(std_tbl.to_string())

    # seed-level wins: does adaptive RL beat the mix-tuned rule, scenario by scenario?
    print("\nTRAINING SEEDS (of %d) where RL adaptive-train beats 'Rule tuned on mix':" % N_SEEDS)
    rule_mix = df[(df.method == "Rule tuned on mix")].set_index("scenario")["profit"]
    ad = df[df.method == "RL adaptive-train"]
    for sc in scen_order:
        wins = int((ad[ad.scenario == sc]["profit"] > rule_mix[sc]).sum())
        print(f"  {sc:34s} {wins}/{N_SEEDS}")
    print("\nMean over all 8 scenarios:")
    print(mean_tbl.mean().round(0).to_string())
