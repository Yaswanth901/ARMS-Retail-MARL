(Short version: see START_HERE.md)

# How to Run This — Step by Step

## What's in here
Three real RL methods, two of which are already trained with saved results in
this zip (you don't *have* to rerun them), plus one that needs your own machine:

1. **Tabular Q-learning** (Rule-based / Single-Agent / Two-Agent) - already run, results included
2. **Neural Fitted Q-Iteration (NFQ)** (Single-Agent / Two-Agent) - already run, results included
3. **MAPPO (PyTorch, full deep-RL, CTDE)** - written, correct, but YOU need to run it (needs internet to install PyTorch, which this sandbox didn't have)

## Step 1 — Just want to see the results? Open these, no running needed:
- `learning_curves_full.png` - the main comparison chart, all 5 methods
- `metrics_summary_full.csv` - the numbers table (open in Excel/Sheets)
- `decision_log_sample.txt` - plain-English explanation of real trained decisions
- `README.md` - full write-up of what each result means

## Step 2 — Want to rerun the tabular + NFQ experiments yourself?
Needs only Python with numpy, pandas, scikit-learn, matplotlib (no internet needed):

```bash
pip install numpy pandas scikit-learn matplotlib --break-system-packages
cd arms_code

python train.py              # tabular: rule-based, single-agent, two-agent Q-learning
python make_results.py       # produces learning_curves.png + metrics_summary.csv

python train_nfq.py          # neural: single-agent NFQ, two-agent NFQ
python make_results_full.py  # combined 5-way comparison + learning_curves_full.png

python explain.py            # prints plain-English decisions from the trained policy
```
Takes about 2–5 minutes total on a normal laptop.

## Step 3 — Want the full MAPPO (PyTorch) version for your final submission?
This is the "real" deep-RL method your document names in Section 9.5. Easiest way — use Google Colab (free, no setup):

1. Go to **colab.research.google.com** → New Notebook
2. Upload `mappo_torch.py` (left sidebar → Files → upload)
3. In a cell, run:
   ```python
   !pip install torch numpy pandas matplotlib
   !python mappo_torch.py
   ```
4. It prints progress every 50 episodes and saves `mappo_results.csv` when done — download that file and compare it against `results_two_agent.csv` / `results_two_nfq.csv` in this zip for your final report.
5. Takes a few minutes on Colab's free CPU — no GPU needed for a problem this small.

If you'd rather run it on your own laptop instead of Colab:
```bash
pip install torch numpy pandas matplotlib
python mappo_torch.py
```

## Step 3b — Want to rerun the rigor additions (multi-seed stats + oracle)?
```bash
python multi_seed_eval.py   # ~2-3 min: 8 seeds x 2 methods, paired t-test
python oracle_bound.py      # ~2-3 min: 2-day lookahead oracle, 30 episodes
```

## Step 4 — Using this in your report/demo
- Use `learning_curves_full.png` as your main results figure.
- Use `metrics_summary_full.csv` as your results table (Section 12 format).
- Use a few lines from `decision_log_sample.txt` as a live example of the
  explainability layer (Section 7/13) — these are genuine model outputs, not
  made-up examples.
- Mention the single-agent-NFQ instability finding (in `README.md`) if asked
  about negative/unexpected results — it's a real, defensible finding your
  own Section 13 already said you'd report honestly either way.

## v2: real-profit economics and guardrails (optional, about 2-4 minutes each)
```
python train_v2.py        # one run: all methods on the same fresh seeds + fallback trade-off table
python multi_seed_v2.py   # 5 seeds with significance tests (the honest check)
```
Read the "v2" section at the bottom of README.md before presenting these numbers.

## v3: interactive app + PowerShell demo (same engine, two ways to see it)

One-time setup (adds Streamlit, the web-page library):
```
pip install -r requirements.txt
```

**A) In PowerShell only (no browser):**
```
python demo_cli.py                      # 14-day replay with a plain-English note for each day
python demo_cli.py --compare            # all 5 methods on the same demand
python demo_cli.py --batch 30           # 30 test episodes, mean and spread
python demo_cli.py --policy             # what the trained agent chooses
python demo_cli.py --spike-day 5 --spike-len 4 --spike-mult 2.5   # demand shock
python demo_cli.py --method rule        # rule | single | two | guarded | fallback
```

**B) The interactive app (opens in your browser):**
```
python -m streamlit run app.py
```
Use `python -m streamlit` (not just `streamlit`). On Windows the plain `streamlit` command is often not found.
Or double-click `run_app.bat` (installs libraries, then starts the app).
If Streamlit asks for an email, press Enter to skip.

The app and the demo load the trained agents from `trained_v2_agents.json`. To rebuild them (about 2 minutes):
```
python train_for_app.py
```

## v4: the new experiments (each takes about 1-3 minutes)
```
python tune_baseline.py            # tunes the strong no-learning rule (prints Rs 7,811)
python demo_cli.py --stress        # 6 harder scenarios x 6 methods
python adaptive_experiment.py      # can RL adapt to changing demand? (it does not)
python rich_state_experiment.py    # second attempt with a richer state (run the line above first)
python demo_cli.py --method tuned  # replay the tuned rule day by day
```
Then `python -m streamlit run app.py` has a new **Stress test** tab, and the tuned rule appears in every comparison.

## v5 additions
```
python run_all.py --quick                     # everything, reusing saved slow results, then builds ARMS_report.html
python make_report.py                         # rebuild the report from saved result files only
python calibrate_favorita.py --data-dir "C:\path\to\favorita"     # real-data weekly pattern -> demand_profile.json
python demo_cli.py --profile --batch 30       # test with the measured weekly pattern
```

## v6: three-product store
```
python demo_cli.py --store                     # milk, curd, bread on one shelf; tuned rule by default
python demo_cli.py --store --store-method rl   # rule | tuned | rl
python multi_experiment.py                     # tuning, training, 5-seed check, capacity test (about 3-5 minutes)
```
The app has a new "3-product store" tab. `run_all.py` runs the experiment (not in --quick mode, which reuses the saved results).

## v7: MAPPO and the (s,S) baseline
```
python mappo_numpy.py --check                # verify the hand-written gradients (seconds)
python tune_sS.py                            # tuned (s,S) baseline (about 1-2 minutes)
python mappo_numpy.py --seeds 15 --out mappo_results_all.csv    # train MAPPO, 15 seeds (about 25 minutes; run_all.py without --quick does this)
python mappo_validate.py                     # re-test the saved agents on 300 new episodes (about 2 minutes)
python mappo_stress.py                       # MAPPO vs the rules in the six stress scenarios (about 2 minutes)
python demo_cli.py --method mappo            # watch MAPPO run the store day by day
```
In the app, "MAPPO (neural policy)" and "Tuned (s,S) rule" are now choices in Live replay, Compare, Batch and Stress.
`python run_all.py --quick` reuses the saved MAPPO results; `python run_all.py` retrains everything.
