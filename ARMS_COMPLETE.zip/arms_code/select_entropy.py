"""Chooses the entropy bonus for the two PPO-based methods on VALIDATION episodes (seeds the agents never train or test on).
For each candidate value, 3 training seeds (100 to 102, different from the 5 evaluation seeds) are trained and scored on 40 validation episodes (seed 930000+).
   python select_entropy.py       writes hp_selection.csv and hp_selection.json"""
import json, os, numpy as np, pandas as pd
import baselines_rl as B, mappo_v3 as W
HERE = os.path.dirname(os.path.abspath(__file__)); rows = []
def val(pol):
    r = W.evaluate(pol, None, 40, 930000); return r["profit"] - 20.0 * r["unmet"]
for name, trainer in (("PPO (single agent)", B.train_ppo), ("MAPPO", B.train_mappo)):
    for ent in (0.01, 0.03, 0.1, 0.3):
        for sd in range(100, 103):
            if trainer is B.train_ppo:
                ag = B.PPOSingle(sd, ent=ent); eps_done = 0
                import numpy as _np
                for it in range(1920 // 16):
                    eps = []
                    for j in range(16):
                        env = B.RetailEnvV3(B.HORIZON, seed=sd * 1_000_000 + it * 1000 + j); s = env.reset(); steps, r = [], []
                        for _ in range(B.HORIZON):
                            d = ag.act(s); s, (rp, ri), _, _ = env.step(*divmod(d["a"], 3)); steps.append(d); r.append((rp + ri) * B.REWARD_SCALE)
                        eps.append(dict(steps=steps, r=r))
                    ag.update(eps)
                pol = ag.policy()
            else: pol = B.train_mappo(sd, 1920, 1920, lambda p: 0.0, ent=ent)[0].policy()
            rows.append(dict(method=name, entropy=ent, seed=sd, validation_return=val(pol))); print(name, ent, sd, round(rows[-1]["validation_return"]), flush=True)
df = pd.DataFrame(rows); df.to_csv(os.path.join(HERE, "hp_selection.csv"), index=False)
best = {m: float(df[df.method == m].groupby("entropy").validation_return.mean().idxmax()) for m in df.method.unique()}
json.dump(best, open(os.path.join(HERE, "hp_selection.json"), "w")); print("selected entropy:", best)
