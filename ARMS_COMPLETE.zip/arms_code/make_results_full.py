import os
BASE = os.path.dirname(os.path.abspath(__file__))  # save/load next to this script, works on any OS
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

rule = pd.read_csv(os.path.join(BASE, "results_rule_based.csv"))
single_q = pd.read_csv(os.path.join(BASE, "results_single_agent.csv"))
two_q = pd.read_csv(os.path.join(BASE, "results_two_agent.csv"))
single_nfq = pd.read_csv(os.path.join(BASE, "results_single_nfq.csv"))
two_nfq = pd.read_csv(os.path.join(BASE, "results_two_nfq.csv"))

def smooth(x, w=20):
    return pd.Series(x).rolling(w, min_periods=1).mean()

fig, axes = plt.subplots(1, 3, figsize=(16, 4.5))
series = [
    ("Single-Agent Q-learning (tabular)", single_q, "#6C8EBF", "--"),
    ("Two-Agent Q-learning (tabular)", two_q, "#B85450", "--"),
    ("Single-Agent NFQ (neural net)", single_nfq, "#4C72B0", "-"),
    ("Two-Agent NFQ (neural net, ours)", two_nfq, "#C0392B", "-"),
]

for label, df, color, style in series:
    axes[0].plot(smooth(df['total_reward']), label=label, color=color, linestyle=style, linewidth=1.6)
axes[0].axhline(rule['total_reward'].mean(), color='#82B366', linestyle=':', label='Rule-based')
axes[0].set_title('Total reward per episode'); axes[0].set_xlabel('Episode'); axes[0].legend(fontsize=7)

for label, df, color, style in series:
    axes[1].plot(smooth(df['stockout']), label=label, color=color, linestyle=style, linewidth=1.6)
axes[1].axhline(rule['stockout'].mean(), color='#82B366', linestyle=':', label='Rule-based')
axes[1].set_title('Stock-out units per episode'); axes[1].set_xlabel('Episode'); axes[1].legend(fontsize=7)

for label, df, color, style in series:
    axes[2].plot(smooth(df['wastage']), label=label, color=color, linestyle=style, linewidth=1.6)
axes[2].axhline(rule['wastage'].mean(), color='#82B366', linestyle=':', label='Rule-based')
axes[2].set_title('Wastage (expired units) per episode'); axes[2].set_xlabel('Episode')
axes[2].legend(fontsize=7); axes[2].set_yscale('symlog')

plt.tight_layout()
plt.savefig(os.path.join(BASE, "learning_curves_full.png"), dpi=200, facecolor='white')
plt.close()

def summarize(df, n_tail):
    d = df.tail(n_tail)
    fr = d['fill_rate'].mean()*100 if 'fill_rate' in d else (d['demand']-d['stockout']).sum()/max(d['demand'].sum(),1)*100
    return {
        'Cumulative reward': f"{d['total_reward'].mean():,.0f}",
        'Wastage (units/ep)': f"{d['wastage'].mean():.2f}",
        'Stock-outs (units/ep)': f"{d['stockout'].mean():.2f}",
        'Fill rate': f"{fr:.1f}%",
    }

table = pd.DataFrame({
    'Rule-based': summarize(rule, 200),
    'Single-Agent Q (tabular)': summarize(single_q, 100),
    'Two-Agent Q (tabular)': summarize(two_q, 100),
    'Single-Agent NFQ (neural)': summarize(single_nfq, 50),
    'Two-Agent NFQ (neural, ours)': summarize(two_nfq, 50),
})
table.to_csv(os.path.join(BASE, "metrics_summary_full.csv"))
print(table.to_string())
